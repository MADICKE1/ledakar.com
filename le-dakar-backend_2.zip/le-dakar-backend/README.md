# LE DAKAR — Backend

Backend API + admin dashboard for the LE DAKAR restaurant site: menu management,
catering & contact form intake, and online ordering with payment via Stripe.

Stack: **Node.js + Express**, **PostgreSQL** via **Prisma**, **JWT** admin auth,
**Stripe Checkout** for payments, optional **SMTP email** notifications. The admin
dashboard is a small static HTML/CSS/JS app served by this same server at `/admin`.

## 1. Prerequisites

- Node.js 18+
- A PostgreSQL database. Any of these work well for a small restaurant site:
  - [Supabase](https://supabase.com) (free tier)
  - [Neon](https://neon.tech) (free tier)
  - [Railway](https://railway.app)
  - A self-hosted Postgres instance
- A [Stripe](https://stripe.com) account (only needed for the online-ordering/payment
  feature — everything else works without it).

## 2. Setup

```bash
cd le-dakar-backend
npm install
cp .env.example .env
```

Open `.env` and fill in:

- `DATABASE_URL` — your Postgres connection string.
- `JWT_SECRET` — generate one with:
  `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` / `ADMIN_NAME` — the first admin account (created once by the seed script below). **Change the password after first login is not supported yet — pick a strong one now, or re-run the seed with a new password to reset it.**
- `FRONTEND_ORIGIN` — the public URL of the LE DAKAR website (used for CORS and for the Stripe success/cancel redirect URLs).
- `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` — only needed for online payment (see step 5).
- `SMTP_*` / `NOTIFY_EMAIL_TO` — optional; leave blank to disable email notifications.

## 3. Create the database schema

```bash
npx prisma migrate dev --name init
```

This creates all tables (`AdminUser`, `Category`, `MenuItem`, `CateringRequest`,
`ContactMessage`, `Order`, `OrderItem`) in your Postgres database.

## 4. Seed the admin account + the real LE DAKAR menu

```bash
npm run seed
```

This creates your admin login and populates the menu (Breakfast, Lunch, Fast Food,
Desserts, Beverages — matching what's on the live site today) so the dashboard and
API aren't empty on first run. Safe to re-run — it upserts rather than duplicating.

## 5. Run it

```bash
npm run dev      # with auto-reload (nodemon)
# or
npm start
```

- API base: `http://localhost:4000/api`
- Admin dashboard: `http://localhost:4000/admin` — log in with the `ADMIN_EMAIL` /
  `ADMIN_PASSWORD` you set in `.env`.

## 6. Stripe setup (online ordering)

1. Get your **secret key** from the Stripe dashboard → Developers → API keys, and put
   it in `STRIPE_SECRET_KEY`.
2. Create a webhook endpoint pointing at
   `https://your-backend-domain.com/api/webhooks/stripe`, subscribed to
   `checkout.session.completed` and `checkout.session.expired`. Copy its **signing
   secret** into `STRIPE_WEBHOOK_SECRET`.
3. While developing locally, use the Stripe CLI instead of a public webhook URL:
   ```bash
   stripe listen --forward-to localhost:4000/api/webhooks/stripe
   ```
   It prints a `whsec_...` value — use that as `STRIPE_WEBHOOK_SECRET` while testing.
4. Test card number for Stripe test mode: `4242 4242 4242 4242`, any future expiry,
   any CVC.

**Important:** this backend never touches raw card numbers — customers pay on a
Stripe-hosted Checkout page, which keeps you out of PCI-DSS scope. Do not add any
code that collects card details directly.

## 7. Connecting the frontend site

`le-dakar-site-live.html` (delivered alongside this backend) is already wired to
call this API — it fetches the menu from `/api/categories` + `/api/menu-items`,
posts real orders to `/api/orders` and redirects to the Stripe Checkout URL it
returns, and submits the Catering form to `/api/catering`. Nothing else to
build; just:

1. Open `le-dakar-site-live.html` and edit the `API_BASE` constant near the top
   of the `<script>` block (search for `LIVE BACKEND CONNECTION`) to your
   deployed backend's URL, e.g. `"https://api.ledakarbronx.com/api"`.
2. Deploy that HTML file as a static site (Netlify, Vercel, GitHub Pages, or
   this same host) on your real domain.
3. Set `FRONTEND_ORIGIN` in this backend's `.env` to that site's real URL, so
   CORS and the Stripe success/cancel redirect URLs work.
4. The footer's "🔑 Espace Staff" link resolves itself from `API_BASE` to
   `<your-backend>/admin` — no separate edit needed.

The Claude Artifact version of the site (menu/cart hard-coded, no backend
calls) stays exactly as it is today for the QR codes and public link already
in use — `le-dakar-site-live.html` is the separate, self-hosted version for
when you're ready to go live with real orders and payments.

If the project is migrated to the Next.js codebase instead, these same endpoints can
be called from `getServerSideProps`/route handlers or client components exactly the
same way — this backend is a separate service reachable over HTTP either way.

## 8. API reference

All request/response bodies are JSON. Admin-only routes require
`Authorization: Bearer <token>` (obtained from `POST /api/admin/login`).

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/api/health` | none | Uptime check |
| POST | `/api/admin/login` | none | `{ email, password }` → `{ token, admin }` |
| GET | `/api/admin/me` | admin | Verify current token |
| GET | `/api/categories` | none | List categories |
| POST | `/api/categories` | admin | Create category `{ name, sortOrder? }` |
| PUT | `/api/categories/:id` | admin | Update category |
| DELETE | `/api/categories/:id` | admin | Delete (fails if it still has items) |
| GET | `/api/menu-items` | none | List available items (`?includeUnavailable=true` for all) |
| GET | `/api/menu-items/:id` | none | Single item |
| POST | `/api/menu-items` | admin | Create `{ name, price, categoryId, description?, imageUrl?, featured?, available? }` |
| PUT | `/api/menu-items/:id` | admin | Partial update |
| DELETE | `/api/menu-items/:id` | admin | Delete (or mark unavailable if it has past orders) |
| POST | `/api/uploads` | admin | Upload a dish photo — `multipart/form-data` with one field `photo` (JPEG/PNG/WEBP/GIF, ≤5MB) → `{ url }`. Save that `url` into a menu item's `imageUrl`. Files are served back from `/uploads/<filename>`. The admin dashboard's "Photo" field already does this for you. |
| POST | `/api/catering` | none | Submit catering request `{ name, phone, email, eventDate, guestCount, eventType, company?, budget?, requestedDishes?, additionalInfo? }` |
| GET | `/api/catering` | admin | List requests (`?status=NEW`) |
| PATCH | `/api/catering/:id` | admin | `{ status }` — NEW/CONTACTED/CONFIRMED/COMPLETED/CANCELLED |
| POST | `/api/contact` | none | Submit contact message `{ name, email, message, phone? }` |
| GET | `/api/contact` | admin | List messages (`?status=NEW`) |
| PATCH | `/api/contact/:id` | admin | `{ status }` — NEW/READ/ARCHIVED |
| POST | `/api/orders` | none | Create order + Stripe Checkout session `{ customerName, customerEmail, customerPhone?, notes?, items: [{ menuItemId, quantity }] }` → `{ orderId, checkoutUrl }` |
| GET | `/api/orders/:id` | none | Order status (for a confirmation page) |
| GET | `/api/orders` | admin | List orders (`?status=PAID`) |
| PATCH | `/api/orders/:id` | admin | `{ status }` — PAID/PREPARING/READY/COMPLETED/CANCELLED |
| POST | `/api/webhooks/stripe` | Stripe signature | Stripe event receiver — do not call directly |

All public submission routes (`/api/catering`, `/api/contact`, `/api/orders`,
`/api/admin/login`) are rate-limited to slow down abuse/spam.

## 9. Deploying

Any Node host works (Railway, Render, Fly.io, a VPS, etc.):

1. Set all the `.env` variables as environment variables on the host.
2. Run `npx prisma migrate deploy` once against the production database.
3. Run `npm run seed` once to create the admin account (safe to re-run).
4. Start with `npm start`.
5. Point the Stripe webhook at the deployed URL (step 6 above).

## 10. Project structure

```
le-dakar-backend/
├── prisma/
│   ├── schema.prisma      # database models
│   └── seed.js            # admin account + real menu seed
├── public/admin/           # static admin dashboard (served at /admin)
│   ├── index.html          # login page
│   ├── dashboard.html      # menu / orders / catering / contact tabs
│   ├── css/style.css
│   └── js/{api,login,dashboard}.js
├── src/
│   ├── server.js           # Express app entrypoint
│   ├── db.js                # shared Prisma client
│   ├── middleware/{auth,errorHandler}.js
│   ├── utils/{jwt,mailer,stripe,asyncHandler}.js
│   └── routes/{adminAuth,categories,menuItems,catering,contact,orders,stripeWebhook}.js
├── .env.example
└── package.json
```
