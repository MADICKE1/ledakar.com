// Seeds: one admin account (from .env) + the real LE DAKAR menu (matching the live site).
// Run with: npm run seed
require("dotenv").config();
const bcrypt = require("bcryptjs");
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

const MENU = [
  {
    cat: "Breakfast",
    items: [
      { n: "Chawarma Beef", p: 12 },
      { n: "Chawarma Chicken", p: 12 },
      { n: "Tacos Chicken", p: 13 },
      { n: "Tacos Beef", p: 13 },
    ],
  },
  {
    cat: "Lunch",
    items: [
      { n: "Thiebou Djeun", d: "Exotic red fish and Djolof rice, with eggplant, cabbage and carrots", p: 20, feat: true },
      { n: "Thiebou Yapp", d: "Lamb and exotic Jolof rice, onion sauce on the side", p: 20, feat: true },
      { n: "Suppu Kandja", d: "Okra sauce fish stew with white rice", p: 20 },
      { n: "Thiou Poisson", d: "Fish stewed in tomato sauce with vegetables", p: 20 },
      { n: "Lamb Maffe", d: "Lamb in a rich peanut butter sauce, with white rice", p: 20, feat: true },
      { n: "Thiebou Kethiokhe", d: "Rice and fish or dry fish and beans in tomato sauce", p: 20 },
      { n: "Thiebou Gimar", d: "Chicken with exotic Jolof rice", p: 20 },
      { n: "Sulukhu", p: 20 },
      { n: "Chicken Yassa", d: "Chicken marinated in lemon and onion sauce", p: 20, feat: true },
      { n: "Domada Yapp", d: "Lamb stewed in tomato and vegetable sauce", p: 20 },
      { n: "Mbakhale", d: "Lamb and rice, stewed with onion sauce", p: 20 },
      { n: "Dakhine", p: 20 },
      { n: "Cebon", d: "Mix with seafood, served with white rice", p: 25 },
    ],
  },
  {
    cat: "Fast Food",
    items: [
      { n: "Shawarma", d: "Beef or chicken, with pita bread", p: 12 },
      { n: "Tacos", d: "Chicken or beef", p: 13 },
    ],
  },
  {
    cat: "Desserts",
    items: [
      { n: "Ngualakh", d: "Fine couscous, peanut butter and vanilla", p: 5 },
      { n: "Thiakry", d: "Fine couscous, sour cream and vanilla", p: 5 },
    ],
  },
  {
    cat: "Beverages",
    items: [
      { n: "Bouyé (Baobab)", p: 5 },
      { n: "Bissap Juice", p: 5 },
      { n: "Fruit Cocktail", p: 5 },
      { n: "Tamarind Juice", p: 5 },
      { n: "Ginger Juice", p: 5 },
      { n: "Soda", p: 2 },
      { n: "Spring Water", p: 1 },
    ],
  },
];

async function main() {
  // --- Admin account ---
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME || "Admin";

  if (!email || !password) {
    console.warn("ADMIN_EMAIL / ADMIN_PASSWORD not set in .env — skipping admin account creation.");
  } else {
    const passwordHash = await bcrypt.hash(password, 10);
    await prisma.adminUser.upsert({
      where: { email },
      update: { passwordHash, name },
      create: { email, passwordHash, name },
    });
    console.log(`Admin account ready: ${email}`);
  }

  // --- Menu (categories + items) ---
  for (let catIndex = 0; catIndex < MENU.length; catIndex++) {
    const cat = MENU[catIndex];
    const category = await prisma.category.upsert({
      where: { name: cat.cat },
      update: { sortOrder: catIndex },
      create: { name: cat.cat, sortOrder: catIndex },
    });

    for (let itemIndex = 0; itemIndex < cat.items.length; itemIndex++) {
      const item = cat.items[itemIndex];
      const existing = await prisma.menuItem.findFirst({
        where: { name: item.n, categoryId: category.id },
      });
      const data = {
        name: item.n,
        description: item.d || null,
        priceCents: Math.round(item.p * 100),
        featured: !!item.feat,
        sortOrder: itemIndex,
        categoryId: category.id,
      };
      if (existing) {
        await prisma.menuItem.update({ where: { id: existing.id }, data });
      } else {
        await prisma.menuItem.create({ data });
      }
    }
    console.log(`Seeded category "${cat.cat}" with ${cat.items.length} item(s).`);
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
