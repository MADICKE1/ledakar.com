// Centralized error handler — keeps route handlers free of repetitive try/catch boilerplate
// when used together with src/utils/asyncHandler.js.
function errorHandler(err, req, res, _next) {
  console.error("[error]", err);

  if (err.code === "P2002") {
    // Prisma unique constraint violation
    return res.status(409).json({ error: "A record with this value already exists." });
  }
  if (err.code === "P2025") {
    // Prisma "record not found"
    return res.status(404).json({ error: "Record not found." });
  }

  const status = err.statusCode || 500;
  res.status(status).json({
    error: status === 500 ? "Internal server error." : err.message,
  });
}

module.exports = { errorHandler };
