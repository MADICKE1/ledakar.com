require("dotenv").config();

const path = require("path");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");

const { errorHandler } = require("./middleware/errorHandler");

const app = express();

// --- Security & logging ---
app.use(
  helmet({
    // The admin dashboard is plain HTML/CSS/JS served from this same app; keep CSP relaxed for it
    // rather than fighting inline styles/scripts. Tighten this if you replace the dashboard.
    contentSecurityPolicy: false,
  })
);
app.use(
  cors({
    origin: process.env.FRONTEND_ORIGIN || "*",
    credentials: false,
  })
);
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));

// Basic global rate limit as a safety net; individual routes add stricter limits where it matters.
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

// --- Stripe webhook: MUST get the raw body, so mount it BEFORE express.json() ---
app.use("/api/webhooks/stripe", express.raw({ type: "application/json" }), require("./routes/stripeWebhook"));

// --- Normal JSON body parsing for everything else ---
app.use(express.json({ limit: "1mb" }));

// --- Health check (useful for uptime monitors / hosting platforms) ---
app.get("/api/health", (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// --- API routes ---
app.use("/api/admin", require("./routes/adminAuth"));
app.use("/api/categories", require("./routes/categories"));
app.use("/api/menu-items", require("./routes/menuItems"));
app.use("/api/catering", require("./routes/catering"));
app.use("/api/contact", require("./routes/contact"));
app.use("/api/orders", require("./routes/orders"));
app.use("/api/uploads", require("./routes/uploads"));

// --- Admin dashboard (static HTML/CSS/JS, talks to the API above via fetch) ---
app.use("/admin", express.static(path.join(__dirname, "..", "public", "admin")));

// --- Uploaded dish photos (served statically; see src/routes/uploads.js) ---
app.use("/uploads", express.static(path.join(__dirname, "..", "public", "uploads")));

// --- 404 for anything else under /api ---
app.use("/api", (req, res) => res.status(404).json({ error: "Not found." }));

// --- Central error handler (must be last) ---
app.use(errorHandler);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`LE DAKAR backend listening on http://localhost:${PORT}`);
  console.log(`Admin dashboard:            http://localhost:${PORT}/admin`);
});
