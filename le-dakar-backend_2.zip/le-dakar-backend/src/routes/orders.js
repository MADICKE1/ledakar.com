const express = require("express");
const rateLimit = require("express-rate-limit");
const prisma = require("../db");
const stripe = require("../utils/stripe");
const { requireAdmin } = require("../middleware/auth");
const { asyncHandler } = require("../utils/asyncHandler");
const { notifyRestaurant } = require("../utils/mailer");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const orderLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
});

// POST /api/orders — create an order and a Stripe Checkout session for it.
// Body: { customerName, customerEmail, customerPhone?, notes?, items: [{ menuItemId, quantity }] }
// Prices are ALWAYS read from the database, never trusted from the client.
router.post(
  "/",
  orderLimiter,
  asyncHandler(async (req, res) => {
    const b = req.body || {};
    const errors = [];
    if (!b.customerName || !b.customerName.trim()) errors.push("customerName is required.");
    if (!b.customerEmail || !EMAIL_RE.test(b.customerEmail)) errors.push("A valid customerEmail is required.");
    if (!Array.isArray(b.items) || b.items.length === 0) errors.push("items must be a non-empty array.");
    if (errors.length) return res.status(400).json({ error: errors.join(" ") });

    for (const line of b.items) {
      if (!line.menuItemId || !Number.isInteger(line.quantity) || line.quantity < 1) {
        return res.status(400).json({ error: "Each item needs a menuItemId and a positive integer quantity." });
      }
    }

    const ids = b.items.map((i) => i.menuItemId);
    const dbItems = await prisma.menuItem.findMany({ where: { id: { in: ids } } });
    const dbById = new Map(dbItems.map((i) => [i.id, i]));

    const missing = ids.filter((id) => !dbById.has(id));
    if (missing.length) {
      return res.status(400).json({ error: `Unknown menu item id(s): ${missing.join(", ")}` });
    }
    const unavailable = b.items.filter((line) => !dbById.get(line.menuItemId).available);
    if (unavailable.length) {
      return res.status(409).json({
        error: `Some items are no longer available: ${unavailable
          .map((l) => dbById.get(l.menuItemId).name)
          .join(", ")}`,
      });
    }

    const orderItemsData = b.items.map((line) => {
      const item = dbById.get(line.menuItemId);
      return {
        menuItemId: item.id,
        nameSnapshot: item.name,
        unitPriceCents: item.priceCents,
        quantity: line.quantity,
      };
    });
    const totalCents = orderItemsData.reduce((sum, l) => sum + l.unitPriceCents * l.quantity, 0);

    const order = await prisma.order.create({
      data: {
        customerName: b.customerName.trim(),
        customerEmail: b.customerEmail.trim(),
        customerPhone: b.customerPhone || null,
        notes: b.notes || null,
        totalCents,
        items: { create: orderItemsData },
      },
      include: { items: true },
    });

    const frontendOrigin = process.env.FRONTEND_ORIGIN || "http://localhost:3000";

    let session;
    try {
      session = await stripe.checkout.sessions.create({
        mode: "payment",
        customer_email: order.customerEmail,
        line_items: orderItemsData.map((l) => ({
          quantity: l.quantity,
          price_data: {
            currency: "usd",
            unit_amount: l.unitPriceCents,
            product_data: { name: l.nameSnapshot },
          },
        })),
        metadata: { orderId: order.id },
        success_url: `${frontendOrigin}/order-confirmation?orderId=${order.id}&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${frontendOrigin}/order-cancelled?orderId=${order.id}`,
      });
    } catch (err) {
      // Keep the order record (status stays PENDING_PAYMENT) but surface the Stripe error.
      return res.status(502).json({
        error: "Could not start checkout with the payment provider. Please try again.",
        detail: err.message,
        orderId: order.id,
      });
    }

    await prisma.order.update({ where: { id: order.id }, data: { stripeCheckoutId: session.id } });

    res.status(201).json({ orderId: order.id, checkoutUrl: session.url });
  })
);

// GET /api/orders/:id — lets the confirmation page poll order status (no sensitive data beyond the order itself).
router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { items: true },
    });
    if (!order) return res.status(404).json({ error: "Order not found." });
    res.json({
      id: order.id,
      status: order.status,
      totalCents: order.totalCents,
      items: order.items.map((i) => ({ name: i.nameSnapshot, quantity: i.quantity, unitPriceCents: i.unitPriceCents })),
      createdAt: order.createdAt,
    });
  })
);

// GET /api/orders — admin only, list all orders (?status=PAID etc.)
router.get(
  "/",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const where = req.query.status ? { status: req.query.status } : {};
    const orders = await prisma.order.findMany({
      where,
      include: { items: true },
      orderBy: { createdAt: "desc" },
    });
    res.json(orders);
  })
);

// PATCH /api/orders/:id — admin only, move order through the kitchen workflow.
router.patch(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { status } = req.body || {};
    const valid = ["PAID", "PREPARING", "READY", "COMPLETED", "CANCELLED"];
    if (!valid.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${valid.join(", ")}` });
    }
    const updated = await prisma.order.update({ where: { id: req.params.id }, data: { status } });
    res.json(updated);
  })
);

module.exports = router;
