const express = require("express");
const rateLimit = require("express-rate-limit");
const prisma = require("../db");
const { requireAdmin } = require("../middleware/auth");
const { asyncHandler } = require("../utils/asyncHandler");
const { notifyRestaurant } = require("../utils/mailer");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const submitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many messages from this device. Please try again later or call us directly." },
});

// POST /api/contact — public contact form submission.
router.post(
  "/",
  submitLimiter,
  asyncHandler(async (req, res) => {
    const b = req.body || {};
    const errors = [];
    if (!b.name || !b.name.trim()) errors.push("Name is required.");
    if (!b.email || !EMAIL_RE.test(b.email)) errors.push("A valid email is required.");
    if (!b.message || !b.message.trim()) errors.push("Message is required.");
    if (errors.length) return res.status(400).json({ error: errors.join(" ") });

    const msg = await prisma.contactMessage.create({
      data: {
        name: b.name.trim(),
        email: b.email.trim(),
        phone: b.phone || null,
        message: b.message.trim(),
      },
    });

    notifyRestaurant(
      `New website contact message from ${msg.name}`,
      `Name: ${msg.name}\nEmail: ${msg.email}\nPhone: ${msg.phone || "-"}\n\n${msg.message}`
    ).catch(() => {});

    res.status(201).json({ message: "Message received. We'll get back to you soon.", id: msg.id });
  })
);

// GET /api/contact — admin only.
router.get(
  "/",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const where = req.query.status ? { status: req.query.status } : {};
    const messages = await prisma.contactMessage.findMany({ where, orderBy: { createdAt: "desc" } });
    res.json(messages);
  })
);

// PATCH /api/contact/:id — admin only, update status (NEW/READ/ARCHIVED).
router.patch(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { status } = req.body || {};
    const valid = ["NEW", "READ", "ARCHIVED"];
    if (!valid.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${valid.join(", ")}` });
    }
    const updated = await prisma.contactMessage.update({ where: { id: req.params.id }, data: { status } });
    res.json(updated);
  })
);

module.exports = router;
