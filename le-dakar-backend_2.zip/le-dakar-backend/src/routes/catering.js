const express = require("express");
const rateLimit = require("express-rate-limit");
const prisma = require("../db");
const { requireAdmin } = require("../middleware/auth");
const { asyncHandler } = require("../utils/asyncHandler");
const { notifyRestaurant } = require("../utils/mailer");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const submitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests from this device. Please try again later or call us directly." },
});

// POST /api/catering — public form submission (matches the Catering page form fields).
router.post(
  "/",
  submitLimiter,
  asyncHandler(async (req, res) => {
    const b = req.body || {};
    const errors = [];
    if (!b.name || !b.name.trim()) errors.push("Name is required.");
    if (!b.phone || !b.phone.trim()) errors.push("Phone is required.");
    if (!b.email || !EMAIL_RE.test(b.email)) errors.push("A valid email is required.");
    if (!b.eventDate) errors.push("Event date is required.");
    if (!b.guestCount || Number(b.guestCount) < 1) errors.push("Guest count must be at least 1.");
    if (!b.eventType || !b.eventType.trim()) errors.push("Event type is required.");
    if (errors.length) return res.status(400).json({ error: errors.join(" ") });

    const eventDate = new Date(b.eventDate);
    if (Number.isNaN(eventDate.getTime())) {
      return res.status(400).json({ error: "Event date is not a valid date." });
    }

    const request = await prisma.cateringRequest.create({
      data: {
        name: b.name.trim(),
        company: b.company || null,
        phone: b.phone.trim(),
        email: b.email.trim(),
        eventDate,
        guestCount: Number(b.guestCount),
        eventType: b.eventType.trim(),
        budget: b.budget || null,
        requestedDishes: b.requestedDishes || null,
        additionalInfo: b.additionalInfo || null,
      },
    });

    notifyRestaurant(
      `New catering request — ${request.name} (${request.guestCount} guests, ${eventDate.toDateString()})`,
      `Name: ${request.name}\nCompany: ${request.company || "-"}\nPhone: ${request.phone}\nEmail: ${request.email}\nEvent date: ${eventDate.toDateString()}\nGuests: ${request.guestCount}\nEvent type: ${request.eventType}\nBudget: ${request.budget || "-"}\nRequested dishes: ${request.requestedDishes || "-"}\nAdditional info: ${request.additionalInfo || "-"}`
    ).catch(() => {});

    res.status(201).json({ message: "Catering request received. We'll follow up shortly.", id: request.id });
  })
);

// GET /api/catering — admin only, list all requests (?status=NEW to filter).
router.get(
  "/",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const where = req.query.status ? { status: req.query.status } : {};
    const requests = await prisma.cateringRequest.findMany({ where, orderBy: { createdAt: "desc" } });
    res.json(requests);
  })
);

// PATCH /api/catering/:id — admin only, update status (NEW/CONTACTED/CONFIRMED/COMPLETED/CANCELLED).
router.patch(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { status } = req.body || {};
    const valid = ["NEW", "CONTACTED", "CONFIRMED", "COMPLETED", "CANCELLED"];
    if (!valid.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${valid.join(", ")}` });
    }
    const updated = await prisma.cateringRequest.update({ where: { id: req.params.id }, data: { status } });
    res.json(updated);
  })
);

module.exports = router;
