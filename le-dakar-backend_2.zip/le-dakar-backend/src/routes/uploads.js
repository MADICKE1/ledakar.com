const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const fs = require("fs");
const { requireAdmin } = require("../middleware/auth");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

// Photos are written to disk, under public/uploads, and served statically by
// server.js at /uploads/<filename>. Fine for a single small server; if you
// later move to multiple server instances or a CDN, swap this storage engine
// for an S3/Cloudinary one — the route's request/response shape stays the same.
const uploadsDir = path.join(__dirname, "..", "..", "public", "uploads");
fs.mkdirSync(uploadsDir, { recursive: true });

const ALLOWED_TYPES = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = ALLOWED_TYPES[file.mimetype] || path.extname(file.originalname) || "";
    cb(null, `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB — plenty for a dish photo, keeps the disk/DB light
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_TYPES[file.mimetype]) {
      return cb(new Error("Only JPEG, PNG, WEBP or GIF images are allowed."));
    }
    cb(null, true);
  },
});

// POST /api/uploads — admin only. multipart/form-data with a single field named "photo".
// Returns { url } — a path relative to this server (e.g. "/uploads/171234-ab12cd.jpg").
// Save that url into a menu item's imageUrl (PUT /api/menu-items/:id) right after this resolves.
router.post(
  "/",
  requireAdmin,
  (req, res, next) => {
    upload.single("photo")(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      next();
    });
  },
  asyncHandler(async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded (expected a "photo" field).' });
    }
    res.status(201).json({ url: `/uploads/${req.file.filename}` });
  })
);

module.exports = router;
