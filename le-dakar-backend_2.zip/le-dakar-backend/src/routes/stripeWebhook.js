const express = require("express");
const prisma = require("../db");
const stripe = require("../utils/stripe");
const { notifyRestaurant } = require("../utils/mailer");
const { sendMail } = require("../utils/mailer");

const router = express.Router();

// IMPORTANT: this route must receive the RAW request body (not JSON-parsed) so
// Stripe's signature can be verified. server.js mounts express.raw() for this
// path specifically, before the global express.json() middleware.
router.post("/", async (req, res) => {
  const signature = req.headers["stripe-signature"];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("[stripe webhook] signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const orderId = session.metadata && session.metadata.orderId;
      if (orderId) {
        const order = await prisma.order.update({
          where: { id: orderId },
          data: {
            status: "PAID",
            stripePaymentIntentId: session.payment_intent || null,
          },
          include: { items: true },
        });

        notifyRestaurant(
          `New paid order — ${order.customerName} ($${(order.totalCents / 100).toFixed(2)})`,
          order.items.map((i) => `${i.quantity}x ${i.nameSnapshot}`).join("\n")
        ).catch(() => {});

        sendMail({
          to: order.customerEmail,
          subject: "Your LE DAKAR order is confirmed",
          text: `Thank you, ${order.customerName}! Your order (#${order.id.slice(0, 8)}) for $${(
            order.totalCents / 100
          ).toFixed(2)} has been received and is being prepared.`,
        }).catch(() => {});
      }
    } else if (event.type === "checkout.session.expired") {
      const session = event.data.object;
      const orderId = session.metadata && session.metadata.orderId;
      if (orderId) {
        await prisma.order.update({ where: { id: orderId }, data: { status: "PAYMENT_FAILED" } });
      }
    }
  } catch (err) {
    // Log but still 200 the webhook — Stripe will not retry endlessly for a bug on our side once acknowledged,
    // and we don't want a DB hiccup to cause Stripe to keep retrying a webhook we can't process anyway.
    console.error("[stripe webhook] handler error:", err);
  }

  res.json({ received: true });
});

module.exports = router;
