const express = require("express");
const prisma = require("../db");
const { requireAdmin } = require("../middleware/auth");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

// GET /api/categories — public, used by the site to build the menu tabs.
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const categories = await prisma.category.findMany({ orderBy: { sortOrder: "asc" } });
    res.json(categories);
  })
);

// POST /api/admin/categories — create a category.
router.post(
  "/",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { name, sortOrder } = req.body || {};
    if (!name || !name.trim()) {
      return res.status(400).json({ error: "Category name is required." });
    }
    const category = await prisma.category.create({
      data: { name: name.trim(), sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0 },
    });
    res.status(201).json(category);
  })
);

// PUT /api/admin/categories/:id — rename / reorder a category.
router.put(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { name, sortOrder } = req.body || {};
    const category = await prisma.category.update({
      where: { id: req.params.id },
      data: {
        ...(name !== undefined ? { name: name.trim() } : {}),
        ...(sortOrder !== undefined ? { sortOrder } : {}),
      },
    });
    res.json(category);
  })
);

// DELETE /api/admin/categories/:id — refuses if items still reference it (see schema onDelete: Restrict).
router.delete(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const itemCount = await prisma.menuItem.count({ where: { categoryId: req.params.id } });
    if (itemCount > 0) {
      return res.status(409).json({
        error: `Cannot delete: ${itemCount} menu item(s) still belong to this category. Move or delete them first.`,
      });
    }
    await prisma.category.delete({ where: { id: req.params.id } });
    res.status(204).end();
  })
);

module.exports = router;
