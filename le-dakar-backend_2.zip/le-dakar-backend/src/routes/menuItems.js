const express = require("express");
const prisma = require("../db");
const { requireAdmin } = require("../middleware/auth");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

function serialize(item) {
  return {
    id: item.id,
    name: item.name,
    description: item.description,
    price: item.priceCents / 100,
    imageUrl: item.imageUrl,
    featured: item.featured,
    available: item.available,
    sortOrder: item.sortOrder,
    categoryId: item.categoryId,
    category: item.category ? { id: item.category.id, name: item.category.name } : undefined,
  };
}

// GET /api/menu-items — public. ?includeUnavailable=true to also return 86'd items (admin dashboard uses this).
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const includeUnavailable = req.query.includeUnavailable === "true";
    const items = await prisma.menuItem.findMany({
      where: includeUnavailable ? {} : { available: true },
      include: { category: true },
      orderBy: [{ category: { sortOrder: "asc" } }, { sortOrder: "asc" }],
    });
    res.json(items.map(serialize));
  })
);

// GET /api/menu-items/:id — public, single item detail.
router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const item = await prisma.menuItem.findUnique({
      where: { id: req.params.id },
      include: { category: true },
    });
    if (!item) return res.status(404).json({ error: "Menu item not found." });
    res.json(serialize(item));
  })
);

function validateBody(body, { partial } = { partial: false }) {
  const errors = [];
  if (!partial || body.name !== undefined) {
    if (!body.name || !String(body.name).trim()) errors.push("name is required.");
  }
  if (!partial || body.price !== undefined) {
    if (typeof body.price !== "number" || body.price < 0) errors.push("price must be a non-negative number.");
  }
  if (!partial || body.categoryId !== undefined) {
    if (!body.categoryId) errors.push("categoryId is required.");
  }
  return errors;
}

// POST /api/menu-items — admin only.
router.post(
  "/",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const body = req.body || {};
    const errors = validateBody(body);
    if (errors.length) return res.status(400).json({ error: errors.join(" ") });

    const item = await prisma.menuItem.create({
      data: {
        name: body.name.trim(),
        description: body.description || null,
        priceCents: Math.round(body.price * 100),
        imageUrl: body.imageUrl || null,
        featured: !!body.featured,
        available: body.available === undefined ? true : !!body.available,
        sortOrder: Number.isFinite(body.sortOrder) ? body.sortOrder : 0,
        categoryId: body.categoryId,
      },
      include: { category: true },
    });
    res.status(201).json(serialize(item));
  })
);

// PUT /api/menu-items/:id — admin only, partial update.
router.put(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const body = req.body || {};
    const errors = validateBody(body, { partial: true });
    if (errors.length) return res.status(400).json({ error: errors.join(" ") });

    const data = {};
    if (body.name !== undefined) data.name = body.name.trim();
    if (body.description !== undefined) data.description = body.description || null;
    if (body.price !== undefined) data.priceCents = Math.round(body.price * 100);
    if (body.imageUrl !== undefined) data.imageUrl = body.imageUrl || null;
    if (body.featured !== undefined) data.featured = !!body.featured;
    if (body.available !== undefined) data.available = !!body.available;
    if (body.sortOrder !== undefined) data.sortOrder = body.sortOrder;
    if (body.categoryId !== undefined) data.categoryId = body.categoryId;

    const item = await prisma.menuItem.update({
      where: { id: req.params.id },
      data,
      include: { category: true },
    });
    res.json(serialize(item));
  })
);

// DELETE /api/menu-items/:id — admin only.
router.delete(
  "/:id",
  requireAdmin,
  asyncHandler(async (req, res) => {
    // Menu items referenced by past orders are kept for order history integrity;
    // marking unavailable is safer than deleting once an item has been ordered.
    const orderCount = await prisma.orderItem.count({ where: { menuItemId: req.params.id } });
    if (orderCount > 0) {
      await prisma.menuItem.update({ where: { id: req.params.id }, data: { available: false } });
      return res.json({ message: "Item has past orders — marked unavailable instead of deleted." });
    }
    await prisma.menuItem.delete({ where: { id: req.params.id } });
    res.status(204).end();
  })
);

module.exports = router;
