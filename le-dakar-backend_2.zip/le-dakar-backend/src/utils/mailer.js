// Best-effort email notifications. If SMTP_* env vars are not set, every
// function below silently no-ops so the API keeps working without email.
const nodemailer = require("nodemailer");

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASSWORD) {
    return null;
  }
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASSWORD,
    },
  });
  return transporter;
}

async function sendMail({ to, subject, text, html }) {
  const t = getTransporter();
  if (!t) {
    console.log(`[mailer] SMTP not configured — skipping email "${subject}" to ${to}`);
    return { skipped: true };
  }
  try {
    return await t.sendMail({
      from: process.env.NOTIFY_EMAIL_FROM || process.env.SMTP_USER,
      to,
      subject,
      text,
      html,
    });
  } catch (err) {
    // Email failures must never break the request that triggered them.
    console.error("[mailer] failed to send email:", err.message);
    return { error: err.message };
  }
}

function notifyRestaurant(subject, text) {
  const to = process.env.NOTIFY_EMAIL_TO;
  if (!to) return Promise.resolve({ skipped: true });
  return sendMail({ to, subject, text });
}

module.exports = { sendMail, notifyRestaurant };
