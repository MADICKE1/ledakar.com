(function () {
  // Already logged in? Skip straight to the dashboard.
  if (getToken()) {
    window.location.href = "/admin/dashboard.html";
    return;
  }

  const form = document.getElementById("login-form");
  const errorSlot = document.getElementById("error-slot");
  const submitBtn = document.getElementById("submit-btn");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorSlot.innerHTML = "";
    submitBtn.disabled = true;
    submitBtn.textContent = "Logging in…";

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    try {
      const data = await api("/admin/login", { method: "POST", body: { email, password }, auth: false });
      setToken(data.token);
      window.location.href = "/admin/dashboard.html";
    } catch (err) {
      errorSlot.innerHTML = `<div class="error-box">${escapeHtml(err.message)}</div>`;
      submitBtn.disabled = false;
      submitBtn.textContent = "Log In";
    }
  });
})();
