// Shared fetch helper for the admin dashboard. Talks to the API mounted on this same origin.
const API_BASE = "/api";

function getToken() {
  return localStorage.getItem("ld_admin_token");
}
function setToken(token) {
  localStorage.setItem("ld_admin_token", token);
}
function clearToken() {
  localStorage.removeItem("ld_admin_token");
}

async function api(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (!token) {
      window.location.href = "/admin/index.html";
      throw new Error("Not authenticated");
    }
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 401 && auth) {
    clearToken();
    window.location.href = "/admin/index.html";
    throw new Error("Session expired");
  }

  const isJson = res.headers.get("content-type")?.includes("application/json");
  const data = isJson ? await res.json().catch(() => ({})) : null;

  if (!res.ok) {
    throw new Error((data && data.error) || `Request failed (${res.status})`);
  }
  return data;
}

// Uploads a photo file (multipart/form-data — no JSON.stringify, no Content-Type
// override, the browser sets the multipart boundary itself). Returns { url }.
async function apiUpload(file) {
  const token = getToken();
  if (!token) {
    window.location.href = "/admin/index.html";
    throw new Error("Not authenticated");
  }
  const form = new FormData();
  form.append("photo", file);

  const res = await fetch(`${API_BASE}/uploads`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: form,
  });

  if (res.status === 401) {
    clearToken();
    window.location.href = "/admin/index.html";
    throw new Error("Session expired");
  }

  const isJson = res.headers.get("content-type")?.includes("application/json");
  const data = isJson ? await res.json().catch(() => ({})) : null;

  if (!res.ok) {
    throw new Error((data && data.error) || `Upload failed (${res.status})`);
  }
  return data;
}

function requireAuthOrRedirect() {
  if (!getToken()) {
    window.location.href = "/admin/index.html";
  }
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function money(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

function fmtDate(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
