(function () {
  requireAuthOrRedirect();

  let categories = [];

  // ---------- tabs ----------
  document.querySelectorAll(".tabs button").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tabs button").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel-section").forEach((s) => s.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`panel-${btn.dataset.tab}`).classList.add("active");
    });
  });

  document.getElementById("logout-btn").addEventListener("click", () => {
    clearToken();
    window.location.href = "/admin/index.html";
  });

  function badge(status) {
    return `<span class="badge badge-${status.toLowerCase()}">${status.replace(/_/g, " ")}</span>`;
  }

  // ================= MENU =================
  async function loadCategories() {
    categories = await api("/categories", { auth: false });
    const sel = document.getElementById("item-category");
    sel.innerHTML = categories
      .map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`)
      .join("");

    const tbody = document.getElementById("category-table-body");
    tbody.innerHTML = categories
      .map(
        (c) => `
        <tr>
          <td>${escapeHtml(c.name)}</td>
          <td>${c.sortOrder}</td>
          <td class="row-actions">
            <button class="btn btn-outline btn-sm" onclick="deleteCategory('${c.id}')">Delete</button>
          </td>
        </tr>`
      )
      .join("");
  }

  async function loadMenuItems() {
    const items = await api("/menu-items?includeUnavailable=true", { auth: false });
    const tbody = document.getElementById("menu-table-body");
    document.getElementById("menu-empty").hidden = items.length > 0;
    tbody.innerHTML = items
      .map(
        (item) => `
        <tr>
          <td>${escapeHtml(item.category ? item.category.name : "-")}</td>
          <td>${escapeHtml(item.name)}</td>
          <td>${money(item.price * 100)}</td>
          <td>${item.featured ? "★" : ""}</td>
          <td>${item.available ? "Yes" : "No"}</td>
          <td class="row-actions">
            <button class="btn btn-outline btn-sm" onclick='editItem(${JSON.stringify(item).replace(/'/g, "&#39;")})'>Edit</button>
            <button class="btn btn-outline btn-sm" onclick="deleteItem('${item.id}')">Delete</button>
          </td>
        </tr>`
      )
      .join("");
  }

  window.deleteCategory = async function (id) {
    if (!confirm("Delete this category? This only works if it has no menu items.")) return;
    try {
      await api(`/categories/${id}`, { method: "DELETE" });
      await loadCategories();
    } catch (err) {
      alert(err.message);
    }
  };

  window.deleteItem = async function (id) {
    if (!confirm("Delete this menu item?")) return;
    try {
      const result = await api(`/menu-items/${id}`, { method: "DELETE" });
      if (result && result.message) alert(result.message);
      await loadMenuItems();
    } catch (err) {
      alert(err.message);
    }
  };

  function showImagePreview(url) {
    const img = document.getElementById("item-image-preview");
    if (url) {
      img.src = url.startsWith("/") ? url : url; // relative (/uploads/..) or absolute URL both work as-is
      img.hidden = false;
    } else {
      img.hidden = true;
      img.src = "";
    }
  }

  window.editItem = function (item) {
    document.getElementById("item-modal-title").textContent = "Edit Menu Item";
    document.getElementById("item-id").value = item.id;
    document.getElementById("item-name").value = item.name;
    document.getElementById("item-description").value = item.description || "";
    document.getElementById("item-price").value = item.price;
    document.getElementById("item-category").value = item.categoryId;
    document.getElementById("item-image").value = item.imageUrl || "";
    document.getElementById("item-featured").checked = !!item.featured;
    document.getElementById("item-available").checked = !!item.available;
    document.getElementById("item-error-slot").innerHTML = "";
    document.getElementById("item-photo-file").value = "";
    document.getElementById("item-photo-status").textContent = "";
    showImagePreview(item.imageUrl || "");
    document.getElementById("item-modal-overlay").hidden = false;
  };

  document.getElementById("new-item-btn").addEventListener("click", () => {
    document.getElementById("item-modal-title").textContent = "Add Menu Item";
    document.getElementById("item-form").reset();
    document.getElementById("item-id").value = "";
    document.getElementById("item-available").checked = true;
    document.getElementById("item-error-slot").innerHTML = "";
    document.getElementById("item-photo-file").value = "";
    document.getElementById("item-photo-status").textContent = "";
    showImagePreview("");
    document.getElementById("item-modal-overlay").hidden = false;
  });

  document.getElementById("item-photo-file").addEventListener("change", async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById("item-photo-status");
    statusEl.textContent = "Uploading…";
    try {
      const result = await apiUpload(file);
      document.getElementById("item-image").value = result.url;
      showImagePreview(result.url);
      statusEl.textContent = "Uploaded ✓ — will be saved when you click Save.";
    } catch (err) {
      statusEl.textContent = `Upload failed: ${err.message}`;
    } finally {
      e.target.value = "";
    }
  });
  document.getElementById("item-cancel-btn").addEventListener("click", () => {
    document.getElementById("item-modal-overlay").hidden = true;
  });

  document.getElementById("item-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("item-id").value;
    const body = {
      name: document.getElementById("item-name").value.trim(),
      description: document.getElementById("item-description").value.trim() || null,
      price: parseFloat(document.getElementById("item-price").value),
      categoryId: document.getElementById("item-category").value,
      imageUrl: document.getElementById("item-image").value.trim() || null,
      featured: document.getElementById("item-featured").checked,
      available: document.getElementById("item-available").checked,
    };
    try {
      if (id) {
        await api(`/menu-items/${id}`, { method: "PUT", body });
      } else {
        await api("/menu-items", { method: "POST", body });
      }
      document.getElementById("item-modal-overlay").hidden = true;
      await loadMenuItems();
    } catch (err) {
      document.getElementById("item-error-slot").innerHTML = `<div class="error-box">${escapeHtml(err.message)}</div>`;
    }
  });

  document.getElementById("new-category-btn").addEventListener("click", () => {
    document.getElementById("category-form").reset();
    document.getElementById("category-error-slot").innerHTML = "";
    document.getElementById("category-modal-overlay").hidden = false;
  });
  document.getElementById("category-cancel-btn").addEventListener("click", () => {
    document.getElementById("category-modal-overlay").hidden = true;
  });
  document.getElementById("category-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const body = {
      name: document.getElementById("category-name").value.trim(),
      sortOrder: parseInt(document.getElementById("category-sort").value, 10) || 0,
    };
    try {
      await api("/categories", { method: "POST", body });
      document.getElementById("category-modal-overlay").hidden = true;
      await loadCategories();
    } catch (err) {
      document.getElementById("category-error-slot").innerHTML = `<div class="error-box">${escapeHtml(err.message)}</div>`;
    }
  });

  // ================= ORDERS =================
  async function loadOrders() {
    const status = document.getElementById("orders-filter").value;
    const orders = await api(`/orders${status ? `?status=${status}` : ""}`);
    const tbody = document.getElementById("orders-table-body");
    document.getElementById("orders-empty").hidden = orders.length > 0;
    const nextStatus = {
      PAID: "PREPARING",
      PREPARING: "READY",
      READY: "COMPLETED",
    };
    tbody.innerHTML = orders
      .map((o) => {
        const itemsStr = o.items.map((i) => `${i.quantity}× ${escapeHtml(i.nameSnapshot)}`).join(", ");
        const advance = nextStatus[o.status];
        return `
        <tr>
          <td>${fmtDate(o.createdAt)}</td>
          <td>${escapeHtml(o.customerName)}<br><span class="hint">${escapeHtml(o.customerEmail)}</span></td>
          <td>${itemsStr}</td>
          <td>${money(o.totalCents)}</td>
          <td>${badge(o.status)}</td>
          <td class="row-actions">
            ${advance ? `<button class="btn btn-outline btn-sm" onclick="setOrderStatus('${o.id}','${advance}')">Mark ${advance.toLowerCase()}</button>` : ""}
            ${["PENDING_PAYMENT", "PAID", "PREPARING"].includes(o.status) ? `<button class="btn btn-outline btn-sm" onclick="setOrderStatus('${o.id}','CANCELLED')">Cancel</button>` : ""}
          </td>
        </tr>`;
      })
      .join("");
  }
  window.setOrderStatus = async function (id, status) {
    try {
      await api(`/orders/${id}`, { method: "PATCH", body: { status } });
      await loadOrders();
    } catch (err) {
      alert(err.message);
    }
  };
  document.getElementById("orders-filter").addEventListener("change", loadOrders);

  // ================= CATERING =================
  async function loadCatering() {
    const status = document.getElementById("catering-filter").value;
    const requests = await api(`/catering${status ? `?status=${status}` : ""}`);
    const tbody = document.getElementById("catering-table-body");
    document.getElementById("catering-empty").hidden = requests.length > 0;
    tbody.innerHTML = requests
      .map(
        (r) => `
        <tr>
          <td>${fmtDate(r.createdAt)}</td>
          <td>${escapeHtml(r.name)}${r.company ? `<br><span class="hint">${escapeHtml(r.company)}</span>` : ""}</td>
          <td>${escapeHtml(r.eventType)}<br><span class="hint">${new Date(r.eventDate).toLocaleDateString()}</span></td>
          <td>${r.guestCount}</td>
          <td>${escapeHtml(r.phone)}<br><span class="hint">${escapeHtml(r.email)}</span></td>
          <td>${badge(r.status)}</td>
          <td class="row-actions">
            <select onchange="setCateringStatus('${r.id}', this.value)" style="width:auto;">
              <option value="">Change status…</option>
              <option value="NEW">New</option>
              <option value="CONTACTED">Contacted</option>
              <option value="CONFIRMED">Confirmed</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </td>
        </tr>`
      )
      .join("");
  }
  window.setCateringStatus = async function (id, status) {
    if (!status) return;
    try {
      await api(`/catering/${id}`, { method: "PATCH", body: { status } });
      await loadCatering();
    } catch (err) {
      alert(err.message);
    }
  };
  document.getElementById("catering-filter").addEventListener("change", loadCatering);

  // ================= CONTACT =================
  async function loadContact() {
    const status = document.getElementById("contact-filter").value;
    const messages = await api(`/contact${status ? `?status=${status}` : ""}`);
    const tbody = document.getElementById("contact-table-body");
    document.getElementById("contact-empty").hidden = messages.length > 0;
    tbody.innerHTML = messages
      .map(
        (m) => `
        <tr>
          <td>${fmtDate(m.createdAt)}</td>
          <td>${escapeHtml(m.name)}</td>
          <td>${escapeHtml(m.email)}${m.phone ? `<br><span class="hint">${escapeHtml(m.phone)}</span>` : ""}</td>
          <td style="max-width:320px;">${escapeHtml(m.message)}</td>
          <td>${badge(m.status)}</td>
          <td class="row-actions">
            <select onchange="setContactStatus('${m.id}', this.value)" style="width:auto;">
              <option value="">Change status…</option>
              <option value="NEW">New</option>
              <option value="READ">Read</option>
              <option value="ARCHIVED">Archived</option>
            </select>
          </td>
        </tr>`
      )
      .join("");
  }
  window.setContactStatus = async function (id, status) {
    if (!status) return;
    try {
      await api(`/contact/${id}`, { method: "PATCH", body: { status } });
      await loadContact();
    } catch (err) {
      alert(err.message);
    }
  };
  document.getElementById("contact-filter").addEventListener("change", loadContact);

  // ================= init =================
  (async function init() {
    try {
      await loadCategories();
      await loadMenuItems();
      await loadOrders();
      await loadCatering();
      await loadContact();
    } catch (err) {
      console.error(err);
    }
  })();
})();
