# LE DAKAR — Restaurant Platform

Authentic Senegalese & African cuisine in New York. A full-stack restaurant
website and management platform: online ordering with Stripe payments, a
role-based staff dashboard, multi-platform (Uber Eats/DoorDash/Grubhub)
pricing and order integration, a QR digital menu, and an audit trail —
built incrementally on top of the original single-restaurant website
without discarding its working design or code.

## Tech Stack

- **Frontend:** Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS
- **Backend:** Next.js Route Handlers (API routes) — no separate backend
  service; at this app's scale a second Node/NestJS service would add
  deployment and auth-sharing complexity without a corresponding benefit.
- **Database:** PostgreSQL (works with [Neon](https://neon.tech), [Supabase](https://supabase.com), or any managed Postgres)
- **ORM:** Prisma
- **Payments:** Stripe Checkout (Card, Apple Pay, Google Pay)
- **Images:** Cloudinary when configured, local `public/uploads/` fallback otherwise (see [Image Uploads](#image-uploads))
- **Background jobs:** BullMQ + Redis when `REDIS_URL` is set, inline execution otherwise (see [Background Jobs](#background-jobs-queue))
- **Realtime:** Server-Sent Events over an in-process event bus (admin Orders/Kitchen pages update live)
- **Email:** Resend
- **Auth:** Custom JWT-based staff sessions (via `jose`), bcrypt password hashing, role-based access control (RBAC)
- **Deployment target:** Vercel (frontend/API) + any managed Postgres + optional Redis (Upstash)

## What's real vs. what's a placeholder

Per the project brief, nothing was invented. Specifically:

- **Menu items and prices** are transcribed directly from the restaurant's
  printed menu photo (see `prisma/seed.ts`). A handful of side items and two
  appetizer eggrolls did not show a clear price on the source menu — those
  are seeded as `priceUnclear: true` and hidden from the public menu until
  the owner enters a real price in `/admin/menu`.
- **Address & phone** come straight from the menu photo (2778 3rd Avenue,
  Bronx, NY 10455 · 347-431-3400) and are editable in `/admin/settings`.
- **Hours, delivery-platform URLs (Uber Eats/DoorDash/Grubhub), social media
  links, and the Google review link** were not provided anywhere and are
  left blank on purpose. Every button tied to one of these (e.g. "Order with
  Uber Eats") is hidden on the public site until the owner fills it in from
  `/admin/settings`.
- **Food photography:** we don't have real photos of these dishes, so every
  menu item without an uploaded photo renders an on-brand placeholder tile
  instead of a stock photo standing in for food that was never photographed.
  Upload real photos any time via `/admin/menu` (wire up your preferred
  image host/upload flow, or paste a hosted image URL) — the site
  automatically switches to `next/image` optimization once `imageUrl` is set.
- **Customer reviews:** no reviews are fabricated. The homepage shows a
  "Leave a Review" link once `googleReviewUrl` is set, and is a plain
  placeholder until then.
- **Delivery platform (Uber Eats/DoorDash/Grubhub) credentials:** none exist
  anywhere in this codebase, and none are invented. Every provider runs in
  MOCK mode — connect/sync/webhook calls succeed with simulated data — until
  a real client secret is set as an environment variable (see
  [Delivery Platform Integrations](#delivery-platform-integrations)). The
  app works fully with zero platforms connected.
- **Default admin password:** `prisma/seed.ts` no longer ships a hardcoded
  default. If you don't set `SEED_ADMIN_PASSWORD`, it generates a random
  one and prints it once to the terminal running the seed command — it is
  never written to a file or committed anywhere. See step 3 below.

## Getting Started (Local Development)

### 1. Install dependencies

```bash
npm install
```

### 2. Set up your database

Create a free Postgres database on [Neon](https://neon.tech) (recommended) or
[Supabase](https://supabase.com), or point at a local Postgres instance.

Copy the env file and fill in `DATABASE_URL`:

```bash
cp .env.example .env
```

### 3. Run migrations and seed the database

```bash
npx prisma migrate dev --name init
npm run db:seed
```

This creates all tables and seeds the real LE DAKAR menu, a default OWNER
account, and disconnected (sandbox-mode) rows for the three delivery
integrations and the QR menu settings.

The OWNER account's email is `admin@ledakarnyc.com` unless you set
`SEED_ADMIN_EMAIL`. Its password is **not** a fixed default — watch the
terminal output from `npm run db:seed`:

- If you set `SEED_ADMIN_PASSWORD` in `.env`, that's used, silently.
- Otherwise the script generates a random password and prints it once,
  right there in your terminal, in an obvious bordered block. Copy it
  immediately — it isn't saved anywhere else.

Log in at `/admin`, then use **Staff Accounts** (`/admin/users`, OWNER-only)
→ **Reset password** on your own row to set something you'll remember.

### 4. Run the dev server

```bash
npm run dev
```

Visit `http://localhost:3000` for the site and `http://localhost:3000/admin`
for the dashboard.

## Stripe Setup

1. Create a [Stripe account](https://dashboard.stripe.com/register) (test
   mode is fine to start).
2. Copy your test **Secret key** and **Publishable key** into `.env` as
   `STRIPE_SECRET_KEY` and `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`.
3. For local webhook testing, install the [Stripe CLI](https://stripe.com/docs/stripe-cli)
   and run:

   ```bash
   stripe listen --forward-to localhost:3000/api/webhooks/stripe
   ```

   Copy the `whsec_...` value it prints into `STRIPE_WEBHOOK_SECRET`.
4. In production (Vercel), create a webhook endpoint in the Stripe
   Dashboard pointing at `https://yourdomain.com/api/webhooks/stripe`,
   subscribed to at least: `checkout.session.completed`,
   `checkout.session.expired`, `payment_intent.payment_failed`. Copy its
   signing secret into the Vercel env var `STRIPE_WEBHOOK_SECRET`.
5. Apple Pay / Google Pay show up automatically inside Stripe Checkout for
   card payments on supported devices/browsers once your domain is live —
   no extra code is required, but Apple Pay requires domain verification in
   the Stripe Dashboard (Settings → Payment methods → Apple Pay) for your
   production domain.

All order totals (subtotal, tax, delivery fee, discount, tip) are
recalculated server-side from the database in `src/lib/pricing.ts` before a
Stripe Checkout Session is created — the browser is never trusted for
dollar amounts.

## Email (Resend)

1. Create a [Resend](https://resend.com) account and verify a sending domain.
2. Add your API key as `EMAIL_API_KEY` and set `EMAIL_FROM` to a verified
   address.
3. Order confirmation emails send automatically from the Stripe webhook
   handler once payment succeeds. Catering request acknowledgements send
   from `POST /api/catering`.

If `EMAIL_API_KEY` isn't set, emails are skipped (logged to the console)
rather than throwing — the app still works end-to-end without email
configured.

## Staff Accounts & Roles (RBAC)

Five roles, defined once in `src/lib/rbac.ts` and enforced in two places —
never just hidden in the UI:

- **middleware** (`src/middleware.ts`) does a coarse first pass per
  `/api/admin/*` prefix (e.g. you need at least `menu:view` to hit
  `/api/admin/menu` at all);
- **each route handler** then checks the specific permission the action
  actually needs (e.g. `PATCH /api/admin/menu/[id]` requires
  `pricing:manage` only if the request body touches `price`, separately
  from `descriptions:manage` for `description`/`allergens`/etc. — see
  `permissionsRequiredFor()` in that file for the full field map).

| Role | Can do |
|---|---|
| **OWNER** | Everything, always. |
| **MANAGER** | Day-to-day operations: orders, menu, pricing, availability, images, integrations, analytics, coupons, catering, inventory, audit log. Not staff accounts or restaurant settings. |
| **KITCHEN** | Orders + Kitchen Display only. |
| **CASHIER** | Orders + payment status only. |
| **MARKETING** | Menu descriptions, images, and featured flags only — not prices, availability, or structure. |

Manage staff at `/admin/users` (OWNER-only): create accounts, change roles,
deactivate (rather than delete, to preserve their audit-log history),
and reset a password. A lone active OWNER can't demote or deactivate
themselves — promote a second OWNER first.

## Delivery Platform Integrations

`/admin/integrations` manages Uber Eats, DoorDash, and Grubhub. Each is
built as a `DeliveryProvider` adapter (`src/lib/integrations/*-provider.ts`,
implementing the interface in `types.ts`) so a real API integration can
be dropped in later without touching the routes, UI, or order pipeline —
see `src/lib/integrations/base-mock-provider.ts` for what "MOCK mode" does
today (simulates success, logs to `IntegrationEvent`, nothing external is
called).

To connect a real platform once you have credentials from its developer
portal: set `<PLATFORM>_CLIENT_SECRET` (the exact variable name is
whatever `IntegrationCredential.clientSecretEnvVar` says — see
`.env.example`), then hit **Connect** on that platform's card. Until then
that platform's card stays "Not Connected" and everything else — website
menu, orders, checkout — is entirely unaffected.

**Multi-platform pricing:** in `/admin/menu`, click **Manage** → **Platform
Pricing** on any dish to set a different price per platform (useful for
absorbing commission fees) and toggle it on/off per platform. The website
price is always the master price; platform prices are a distribution
detail on top of it.

**Inbound orders:** each platform POSTs to its own webhook
(`/api/webhooks/uber-eats`, `/doordash`, `/grubhub`), verified by an HMAC
signature against `<PLATFORM>_WEBHOOK_SECRET` (fails closed — 400 — while
that's unset) and deduplicated by `(source, externalId)` so a redelivered
webhook can never create a second order. All three normalize into the same
`Order` model used by website checkout, so `/admin/orders` and the Kitchen
Display (`/admin/kitchen`) show every source in one place — filter by
platform there.

## QR Digital Menu

`/admin/qr-menu` generates a QR code pointing at the site's permanent
`/menu` page. Because that page reads live from the database, the QR code
itself never needs to be reprinted when a price, photo, description, or
availability changes — only if you deliberately replace the menu URL
itself. Download it as PNG or SVG; the headline/accent-color/legend
toggles on that page only affect what you print alongside the code (a
table-tent card), not the live page.

## Image Uploads

`/admin/menu` → **Manage** → **Details & Image** uploads a dish photo (and
a gallery of extra photos) through `POST /api/admin/images/upload`, backed
by `src/lib/images.ts`:

- With `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET`
  set, uploads go to Cloudinary and delivery URLs get `f_auto,q_auto`
  (automatic format — WebP where the browser supports it — and quality).
- Without them, uploads fall back to `public/uploads/` locally. Fine for
  development; **not durable on Vercel or any serverless host** (ephemeral
  filesystem) — set Cloudinary before you rely on this in production.

## Background Jobs (Queue)

`src/lib/queue.ts` is BullMQ-backed when `REDIS_URL` is set, and runs jobs
inline (no queue, no retries, but nothing silently dropped) otherwise — the
app never requires Redis to function. Wired in today: multi-platform price
sync (`src/lib/jobs/menu-sync-worker.ts`), started via `src/instrumentation.ts`
on server boot. Job types for image processing, notifications, webhook
retry, and analytics aggregation are defined and ready
(`registerWorker(name, handler)` + `enqueue(name, data)`) but nothing
currently routes through them — this app's request volume doesn't need it
yet at those points (image upload and webhook handling are already fast,
synchronous operations).

## Testing

```bash
npm run test        # run once
npm run test:watch  # watch mode
```

Vitest, in `tests/`. Covers RBAC/permission logic, input validation
(product/price/availability/staff-role schemas), cart price calculation
(`src/lib/pricing.ts` — tax, discount, delivery minimum, tip, and that a
client-submitted price is never trusted), the Stripe webhook's idempotency
and PENDING→CONFIRMED transition, the delivery-platform webhooks'
idempotency and platform mapping, and the background-job queue's
no-Redis fallback — all with Prisma/Stripe/BullMQ mocked at the module
boundary, so no database or external service is required to run them.

Not covered here: full route-level integration tests (an actual HTTP
request through Next.js hitting a real Postgres database) and end-to-end
browser tests. Both are reasonable next additions once this is deployed
against a real database — the unit tests above cover the business-logic
core that integration tests would otherwise have to exercise indirectly.

## SMS Notifications (optional, not yet implemented)

The codebase is structured so SMS can be added without touching call sites:
see `sendOrderStatusSms()` in `src/lib/email.ts`. To enable it, add the
`twilio` package and your `TWILIO_ACCOUNT_SID` / `TWILIO_AUTH_TOKEN` /
`TWILIO_FROM_NUMBER` env vars, then implement the function body and call it
from the admin order-status update route (`src/app/api/admin/orders/[id]/route.ts`).

## Deploying to Vercel

1. Push this repository to GitHub/GitLab/Bitbucket.
2. Import the repo in [Vercel](https://vercel.com/new).
3. Add all variables from `.env.example` to the Vercel project's
   Environment Variables (Production **and** Preview).
4. Vercel runs `npm run build`, which runs `prisma generate` automatically
   (see the `postinstall` script) — but migrations are **not** run
   automatically. After your first deploy, run once from your machine
   (pointed at the production `DATABASE_URL`):

   ```bash
   npx prisma migrate deploy
   npm run db:seed
   ```

5. Set `NEXT_PUBLIC_SITE_URL` to your real production domain — it's used to
   build Stripe redirect URLs, the sitemap, Open Graph metadata, and the QR
   digital menu's encoded link.
6. Add the Stripe production webhook endpoint (see Stripe Setup above)
   once the domain is live. If you're connecting real delivery platforms,
   add their webhook endpoints too (see Delivery Platform Integrations).
7. Vercel's functions are stateless/serverless: the in-memory rate limiter
   (`src/lib/rate-limit.ts`), realtime event bus (`src/lib/events.ts`), and
   the no-Redis queue fallback (`src/lib/queue.ts`) all work per-instance
   only there, not globally. They're fine as shipped for this app's scale;
   set `REDIS_URL` (Upstash) if you outgrow that — see Background Jobs.

## Admin Dashboard

`/admin` (protected by `src/middleware.ts`, which checks a signed session
cookie *and* that the session's role has permission for that section — see
[Staff Accounts & Roles](#staff-accounts--roles-rbac)):

- **Overview** — today's orders, revenue, active orders, new catering
  leads; links to the full Analytics page.
- **Orders** — filter by status and by source (Website/Uber Eats/DoorDash/
  Grubhub), update status (Pending → Paid → Confirmed → Preparing → Ready →
  Out for Delivery → Completed, or Cancelled), updates live via SSE.
- **Kitchen** (`/admin/kitchen`) — large-card Kitchen Display System:
  Start → Ready → Complete, with an audio chime on new orders.
- **Menu** — add/edit categories and items; per dish, **Manage** opens
  platform pricing, modifier groups/options, image + gallery upload, and
  dietary tags/allergens/prep time.
- **QR Menu** (`/admin/qr-menu`) — download the QR code, set table-card
  headline/accent color.
- **Integrations** (`/admin/integrations`) — connect/disconnect/sync-menu
  per delivery platform; recent activity log.
- **Analytics** (`/admin/analytics`) — today/7-day/30-day: sales, orders,
  AOV, per-platform sales, top-selling items, sales by category, orders by
  hour, cancellation rate, payment success rate.
- **Audit Log** (`/admin/audit-log`) — every price change, availability
  toggle, image swap, staff/settings change, with who and when; searchable,
  filterable, read-only.
- **Coupons** — create percent/fixed-amount discount codes with usage limits
  and expiry.
- **Catering** — view and triage catering requests submitted from the public
  site.
- **Staff Accounts** (`/admin/users`, OWNER-only) — create/deactivate staff,
  change roles, reset passwords.
- **Settings** — restaurant name/address/phone/email, hours, tax rate,
  pickup/delivery toggles & fees, minimum order, Google Maps/review links,
  social links, and the three delivery-platform URLs — each platform button
  only appears publicly once its URL is set **and** "Show publicly" is
  checked.

## Project Structure

```
prisma/
  schema.prisma       Database models
  seed.ts              Seeds real menu data + default OWNER account
src/
  app/
    (public pages)     /, /menu, /order, /delivery, /about, /catering, /gallery, /contact
    checkout/           Cart checkout, Stripe redirect, success/cancel pages
    admin/               Protected staff dashboard pages (RBAC-filtered nav)
    api/
      admin/            Staff-only CRUD + analytics + audit log (all RBAC-checked)
      webhooks/          stripe, uber-eats, doordash, grubhub — signed + idempotent
      checkout/          Server-priced Stripe Checkout session creation
  components/          Reusable UI (nav, cart, menu cards, forms, etc.)
  lib/
    integrations/       DeliveryProvider interface + mock adapters + webhook handling
    jobs/                Background-job handlers (see Background Jobs)
    prisma.ts, stripe.ts, auth.ts, rbac.ts, rbac-guard.ts, audit.ts,
    images.ts, queue.ts, events.ts, rate-limit.ts, pricing.ts, email.ts,
    menu.ts, settings.ts, validations.ts, cart-store.ts
  types/               Shared TypeScript types
  middleware.ts        Authenticates + RBAC-checks /admin and /api/admin routes
  instrumentation.ts   Starts background-job workers on server boot
tests/                 Vitest unit tests (see Testing)
```

## Security Notes

- Admin routes are protected at the middleware layer (`src/middleware.ts`),
  which checks both a valid signed session cookie *and* that the session's
  role has the permission that route area requires.
- Every mutating admin API route re-checks permission server-side
  (`withPermission()` / `requirePermission()` in `src/lib/rbac-guard.ts`) —
  middleware's per-prefix check is a coarse first pass, not the only gate.
  Some routes go further with field-level checks (e.g. changing a dish's
  `price` requires `pricing:manage` specifically, independent of whatever
  else is in the same request) — see `permissionsRequiredFor()` in
  `src/app/api/admin/menu/[id]/route.ts`.
- Passwords are hashed with bcrypt; sessions are signed JWTs in an
  `httpOnly`, `secure` (in production), `sameSite=lax` cookie.
- All prices are recalculated server-side before payment — the client
  cart is only trusted for item IDs/quantities.
- Stripe and delivery-platform webhook signatures are verified before any
  order is marked paid or created; every webhook event id is recorded in a
  `WebhookEvent` row with a unique constraint, so a redelivered webhook is
  a safe no-op instead of a duplicate order or double-charged coupon.
- Admin login and image upload are rate-limited per IP
  (`src/lib/rate-limit.ts`).
- No secrets are hard-coded; everything sensitive comes from environment
  variables (see `.env.example`). Delivery-platform credentials are never
  invented — `IntegrationCredential` stores only an env var *name*, checked
  at request time, never a secret value.
- The seed script no longer prints a fixed default password — see
  [Getting Started, step 3](#3-run-migrations-and-seed-the-database).
