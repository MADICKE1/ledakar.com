import { describe, expect, it, vi, beforeEach } from "vitest";
import { priceCheckout, PricingError, generateOrderNumber } from "@/lib/pricing";

// priceCheckout is the one function standing between "whatever the browser
// sent" and "what the customer is actually charged" — see the big comment
// in src/lib/pricing.ts. Mock Prisma so this exercises the real pricing
// math (tax, discount, delivery minimum, tip) without a live database —
// this sandbox can't run `prisma generate` (see README), so this is the
// only way to unit test it here; a real Postgres integration test should
// be added once deployed.
const findManyMenuItem = vi.fn();
const findFirstSettings = vi.fn();
const findUniqueCoupon = vi.fn();

vi.mock("@/lib/prisma", () => ({
  prisma: {
    menuItem: { findMany: (...args: unknown[]) => findManyMenuItem(...args) },
    restaurantSettings: { findFirst: (...args: unknown[]) => findFirstSettings(...args) },
    coupon: { findUnique: (...args: unknown[]) => findUniqueCoupon(...args) }
  }
}));

const YASSA = { id: "item_1", name: "Yassa Chicken", price: 18, status: "AVAILABLE" };
const THIAKRY = { id: "item_2", name: "Thiakry", price: 6, status: "AVAILABLE" };

const DEFAULT_SETTINGS = {
  taxRatePercent: 8.875,
  deliveryFee: 4,
  minOrderAmount: 25,
  deliveryEnabled: true
};

describe("priceCheckout", () => {
  beforeEach(() => {
    findManyMenuItem.mockReset();
    findFirstSettings.mockReset();
    findUniqueCoupon.mockReset();
  });

  it("computes subtotal, tax, and total for a simple pickup order", async () => {
    findManyMenuItem.mockResolvedValue([YASSA]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    const result = await priceCheckout({
      items: [{ menuItemId: "item_1", quantity: 2 }],
      orderType: "PICKUP"
    } as any);

    expect(result.subtotal).toBe(36);
    expect(result.tax).toBe(3.2); // round2(36 * 8.875%) = round2(3.195) = 3.20
    expect(result.deliveryFee).toBe(0); // pickup never charges delivery
    expect(result.total).toBe(39.2);
  });

  it("charges the configured delivery fee only for DELIVERY orders", async () => {
    findManyMenuItem.mockResolvedValue([YASSA, YASSA]); // same item twice = two line items
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    const result = await priceCheckout({
      items: [
        { menuItemId: "item_1", quantity: 1 },
        { menuItemId: "item_1", quantity: 1 }
      ],
      orderType: "DELIVERY"
    } as any);

    expect(result.deliveryFee).toBe(4);
  });

  it("rejects delivery below the configured minimum order amount", async () => {
    findManyMenuItem.mockResolvedValue([THIAKRY]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    await expect(
      priceCheckout({ items: [{ menuItemId: "item_2", quantity: 1 }], orderType: "DELIVERY" } as any)
    ).rejects.toBeInstanceOf(PricingError);
  });

  it("rejects delivery entirely when the restaurant has delivery disabled", async () => {
    findManyMenuItem.mockResolvedValue([YASSA, YASSA]);
    findFirstSettings.mockResolvedValue({ ...DEFAULT_SETTINGS, deliveryEnabled: false });

    await expect(
      priceCheckout({
        items: [{ menuItemId: "item_1", quantity: 2 }],
        orderType: "DELIVERY"
      } as any)
    ).rejects.toBeInstanceOf(PricingError);
  });

  it("rejects an item that is not AVAILABLE (sold out / hidden) even if the client sent it", async () => {
    findManyMenuItem.mockResolvedValue([{ ...YASSA, status: "SOLD_OUT" }]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    await expect(
      priceCheckout({ items: [{ menuItemId: "item_1", quantity: 1 }], orderType: "PICKUP" } as any)
    ).rejects.toBeInstanceOf(PricingError);
  });

  it("rejects a menu item id the client sent that doesn't exist server-side", async () => {
    findManyMenuItem.mockResolvedValue([]); // server found nothing for the requested id
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    await expect(
      priceCheckout({ items: [{ menuItemId: "ghost_item", quantity: 1 }], orderType: "PICKUP" } as any)
    ).rejects.toBeInstanceOf(PricingError);
  });

  it("never trusts a client-submitted price — total is derived only from the server-side item price", async () => {
    findManyMenuItem.mockResolvedValue([YASSA]); // server price is $18, regardless of what the client claims
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    const result = await priceCheckout({
      // A tampered client could stuff an arbitrary "price" field onto the
      // line item — priceCheckout must never read it.
      items: [{ menuItemId: "item_1", quantity: 1, price: 0.01 } as any],
      orderType: "PICKUP"
    } as any);

    expect(result.subtotal).toBe(18); // not 0.01
  });

  it("applies a valid percent-off coupon and floors the discount at the subtotal", async () => {
    findManyMenuItem.mockResolvedValue([YASSA]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);
    findUniqueCoupon.mockResolvedValue({
      code: "SAVE50",
      active: true,
      expiresAt: null,
      maxUses: null,
      usedCount: 0,
      minOrderAmount: 0,
      discountType: "PERCENT",
      discountValue: 50
    });

    const result = await priceCheckout({
      items: [{ menuItemId: "item_1", quantity: 1 }],
      orderType: "PICKUP",
      couponCode: "save50"
    } as any);

    expect(result.discount).toBe(9); // 50% of $18
    expect(result.couponCode).toBe("SAVE50");
  });

  it("rejects an expired coupon", async () => {
    findManyMenuItem.mockResolvedValue([YASSA]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);
    findUniqueCoupon.mockResolvedValue({
      code: "OLD10",
      active: true,
      expiresAt: new Date("2020-01-01"),
      maxUses: null,
      usedCount: 0,
      minOrderAmount: 0,
      discountType: "FIXED",
      discountValue: 10
    });

    await expect(
      priceCheckout({
        items: [{ menuItemId: "item_1", quantity: 1 }],
        orderType: "PICKUP",
        couponCode: "OLD10"
      } as any)
    ).rejects.toBeInstanceOf(PricingError);
  });

  it("rejects a coupon that has hit its max redemptions", async () => {
    findManyMenuItem.mockResolvedValue([YASSA]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);
    findUniqueCoupon.mockResolvedValue({
      code: "LIMITED",
      active: true,
      expiresAt: null,
      maxUses: 5,
      usedCount: 5,
      minOrderAmount: 0,
      discountType: "FIXED",
      discountValue: 5
    });

    await expect(
      priceCheckout({
        items: [{ menuItemId: "item_1", quantity: 1 }],
        orderType: "PICKUP",
        couponCode: "LIMITED"
      } as any)
    ).rejects.toBeInstanceOf(PricingError);
  });

  it("computes a percent tip off the subtotal (before tax) and a flat tip as given", async () => {
    findManyMenuItem.mockResolvedValue([YASSA]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    const pctResult = await priceCheckout({
      items: [{ menuItemId: "item_1", quantity: 1 }],
      orderType: "PICKUP",
      tipPercent: 20
    } as any);
    expect(pctResult.tip).toBeCloseTo(18 * 0.2, 2);

    const flatResult = await priceCheckout({
      items: [{ menuItemId: "item_1", quantity: 1 }],
      orderType: "PICKUP",
      tipAmount: 7
    } as any);
    expect(flatResult.tip).toBe(7);
  });

  it("rejects an empty cart", async () => {
    findManyMenuItem.mockResolvedValue([]);
    findFirstSettings.mockResolvedValue(DEFAULT_SETTINGS);

    await expect(priceCheckout({ items: [], orderType: "PICKUP" } as any)).rejects.toBeInstanceOf(PricingError);
  });
});

describe("generateOrderNumber", () => {
  it("produces an LD-YYYYMMDD-#### formatted, non-colliding-by-construction number", () => {
    const n = generateOrderNumber();
    expect(n).toMatch(/^LD-\d{8}-\d{4}$/);
  });
});
