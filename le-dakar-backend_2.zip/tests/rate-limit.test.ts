import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { rateLimit, clientIp } from "@/lib/rate-limit";

// Backs the admin login throttle and the image-upload throttle. A bug here
// either locks legitimate staff out or lets a brute-force attempt run wild.

describe("rateLimit", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00.000Z"));
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it("allows requests under the limit", () => {
    const key = `test-${Math.random()}`;
    for (let i = 0; i < 5; i++) {
      expect(rateLimit(key, 5, 60_000).ok).toBe(true);
    }
  });

  it("blocks the request that exceeds the limit within the window", () => {
    const key = `test-${Math.random()}`;
    for (let i = 0; i < 10; i++) rateLimit(key, 10, 60_000);
    const result = rateLimit(key, 10, 60_000);
    expect(result.ok).toBe(false);
    expect(result.retryAfterMs).toBeGreaterThan(0);
  });

  it("resets once the window elapses", () => {
    const key = `test-${Math.random()}`;
    for (let i = 0; i < 10; i++) rateLimit(key, 10, 60_000);
    expect(rateLimit(key, 10, 60_000).ok).toBe(false);

    vi.advanceTimersByTime(60_001);

    expect(rateLimit(key, 10, 60_000).ok).toBe(true);
  });

  it("tracks separate keys independently (per-IP isolation)", () => {
    const keyA = `ip-a-${Math.random()}`;
    const keyB = `ip-b-${Math.random()}`;
    for (let i = 0; i < 10; i++) rateLimit(keyA, 10, 60_000);
    expect(rateLimit(keyA, 10, 60_000).ok).toBe(false);
    expect(rateLimit(keyB, 10, 60_000).ok).toBe(true);
  });
});

describe("clientIp", () => {
  it("prefers the first address in x-forwarded-for", () => {
    const req = new Request("https://example.com", {
      headers: { "x-forwarded-for": "203.0.113.5, 10.0.0.1" }
    });
    expect(clientIp(req)).toBe("203.0.113.5");
  });

  it("falls back to x-real-ip when x-forwarded-for is absent", () => {
    const req = new Request("https://example.com", { headers: { "x-real-ip": "198.51.100.9" } });
    expect(clientIp(req)).toBe("198.51.100.9");
  });

  it("falls back to 'unknown' when neither header is present", () => {
    const req = new Request("https://example.com");
    expect(clientIp(req)).toBe("unknown");
  });
});
