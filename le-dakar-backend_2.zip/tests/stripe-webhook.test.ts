import { describe, expect, it, vi, beforeEach } from "vitest";
import { NextRequest } from "next/server";

// Covers Stripe webhook idempotency and the PENDING -> CONFIRMED order
// status transition it drives — the same idempotency ledger pattern as the
// delivery-platform webhooks (see tests/handle-webhook.test.ts), applied to
// real money. Everything Prisma/Stripe-SDK is mocked; this sandbox can't
// run `prisma generate` (see README), so this exercises the route's
// control flow rather than a live Stripe+Postgres round trip.

const constructEvent = vi.fn();
const webhookEventCreate = vi.fn();
const orderFindUnique = vi.fn();
const orderUpdate = vi.fn();
const transaction = vi.fn();
const orderUpdateMany = vi.fn();
const paymentUpdateMany = vi.fn();
const couponUpdate = vi.fn();
const sendOrderConfirmationEmail = vi.fn();
const emitOrderEvent = vi.fn();

vi.mock("@/lib/stripe", () => ({
  stripe: { webhooks: { constructEvent: (...args: unknown[]) => constructEvent(...args) } }
}));

vi.mock("@/lib/prisma", () => ({
  prisma: {
    webhookEvent: { create: (...args: unknown[]) => webhookEventCreate(...args) },
    order: {
      findUnique: (...args: unknown[]) => orderFindUnique(...args),
      update: (...args: unknown[]) => orderUpdate(...args),
      updateMany: (...args: unknown[]) => orderUpdateMany(...args)
    },
    payment: { updateMany: (...args: unknown[]) => paymentUpdateMany(...args) },
    coupon: { update: (...args: unknown[]) => couponUpdate(...args) },
    $transaction: (...args: unknown[]) => transaction(...args)
  }
}));

vi.mock("@/lib/email", () => ({
  sendOrderConfirmationEmail: (...args: unknown[]) => sendOrderConfirmationEmail(...args)
}));

vi.mock("@/lib/events", () => ({
  emitOrderEvent: (...args: unknown[]) => emitOrderEvent(...args)
}));

import { POST } from "@/app/api/webhooks/stripe/route";

function makeRequest(rawBody: string, signature: string | null = "valid-sig") {
  const headers: Record<string, string> = {};
  if (signature) headers["stripe-signature"] = signature;
  return new NextRequest("https://ledakarnyc.com/api/webhooks/stripe", {
    method: "POST",
    headers,
    body: rawBody
  });
}

const PENDING_ORDER = {
  id: "order_1",
  orderNumber: "LD-20260101-1234",
  status: "PENDING",
  email: "amina@example.com",
  firstName: "Amina",
  total: 39.2,
  type: "PICKUP",
  couponCode: null,
  items: [{ nameSnapshot: "Yassa Chicken", quantity: 1, priceSnapshot: 18 }]
};

describe("Stripe webhook (POST /api/webhooks/stripe)", () => {
  beforeEach(() => {
    process.env.STRIPE_WEBHOOK_SECRET = "whsec_test";
    constructEvent.mockReset();
    webhookEventCreate.mockReset().mockResolvedValue({});
    orderFindUnique.mockReset();
    orderUpdate.mockReset().mockResolvedValue({});
    couponUpdate.mockReset().mockResolvedValue({});
    transaction.mockReset().mockResolvedValue([]);
    orderUpdateMany.mockReset().mockResolvedValue({});
    paymentUpdateMany.mockReset().mockResolvedValue({});
    sendOrderConfirmationEmail.mockReset();
    emitOrderEvent.mockReset();
  });

  it("returns 400 when the webhook secret isn't configured", async () => {
    delete process.env.STRIPE_WEBHOOK_SECRET;
    const res = await POST(makeRequest("{}"));
    expect(res.status).toBe(400);
    expect(constructEvent).not.toHaveBeenCalled();
  });

  it("returns 400 when the signature is missing", async () => {
    const res = await POST(makeRequest("{}", null));
    expect(res.status).toBe(400);
  });

  it("returns 400 when Stripe's SDK rejects the signature", async () => {
    constructEvent.mockImplementation(() => {
      throw new Error("No matching signature found");
    });
    const res = await POST(makeRequest("{}"));
    expect(res.status).toBe(400);
    expect(webhookEventCreate).not.toHaveBeenCalled();
  });

  it("is a no-op on a redelivered (duplicate) event id — never double-fulfills", async () => {
    constructEvent.mockReturnValue({ id: "evt_123", type: "checkout.session.completed", data: { object: {} } });
    webhookEventCreate.mockRejectedValueOnce(new Error("Unique constraint failed on (source, externalId)"));

    const res = await POST(makeRequest("{}"));
    const json = await res.json();

    expect(json).toEqual({ received: true, duplicate: true });
    expect(orderFindUnique).not.toHaveBeenCalled();
    expect(transaction).not.toHaveBeenCalled();
  });

  it("confirms a PENDING order exactly once on checkout.session.completed", async () => {
    constructEvent.mockReturnValue({
      id: "evt_456",
      type: "checkout.session.completed",
      data: {
        object: {
          id: "cs_test_123",
          metadata: { orderId: "order_1" },
          payment_intent: "pi_test_123"
        }
      }
    });
    orderFindUnique.mockResolvedValue(PENDING_ORDER);

    const res = await POST(makeRequest("{}"));
    const json = await res.json();

    expect(json).toEqual({ received: true });
    expect(transaction).toHaveBeenCalledTimes(1);
    expect(sendOrderConfirmationEmail).toHaveBeenCalledTimes(1);
    expect(emitOrderEvent).toHaveBeenCalledWith({ type: "order.updated", orderId: "order_1", status: "CONFIRMED" });
  });

  it("does not re-fulfill an order that's already past PENDING (e.g. a second distinct event for the same order)", async () => {
    constructEvent.mockReturnValue({
      id: "evt_789",
      type: "checkout.session.completed",
      data: { object: { id: "cs_test_123", metadata: { orderId: "order_1" } } }
    });
    orderFindUnique.mockResolvedValue({ ...PENDING_ORDER, status: "CONFIRMED" });

    const res = await POST(makeRequest("{}"));
    await res.json();

    expect(transaction).not.toHaveBeenCalled();
    expect(sendOrderConfirmationEmail).not.toHaveBeenCalled();
  });

  it("cancels a still-PENDING order on checkout.session.expired", async () => {
    constructEvent.mockReturnValue({
      id: "evt_expired",
      type: "checkout.session.expired",
      data: { object: { id: "cs_test_999", metadata: { orderId: "order_2" } } }
    });

    await POST(makeRequest("{}"));

    expect(orderUpdateMany).toHaveBeenCalledWith({
      where: { id: "order_2", status: "PENDING" },
      data: { status: "CANCELLED" }
    });
  });

  it("marks the payment FAILED on payment_intent.payment_failed", async () => {
    constructEvent.mockReturnValue({
      id: "evt_failed",
      type: "payment_intent.payment_failed",
      data: { object: { id: "pi_test_456" } }
    });

    await POST(makeRequest("{}"));

    expect(paymentUpdateMany).toHaveBeenCalledWith({
      where: { stripePaymentIntentId: "pi_test_456" },
      data: { status: "FAILED" }
    });
  });
});
