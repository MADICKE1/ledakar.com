import { describe, expect, it } from "vitest";
import { hasPermission, permissionsForRole, ROUTE_PERMISSIONS } from "@/lib/rbac";

// Pure logic, no DB — exercises every role x a representative slice of
// permissions, which is exactly the surface middleware.ts and every
// withPermission() call in the API routes rely on for authorization.

describe("hasPermission", () => {
  it("grants OWNER every permission, including ones no role list mentions", () => {
    expect(hasPermission("OWNER", "settings:manage")).toBe(true);
    expect(hasPermission("OWNER", "users:manage")).toBe(true);
    expect(hasPermission("OWNER", "menu:manage")).toBe(true);
  });

  it("lets MANAGER run day-to-day operations but not staff/settings", () => {
    expect(hasPermission("MANAGER", "menu:manage")).toBe(true);
    expect(hasPermission("MANAGER", "pricing:manage")).toBe(true);
    expect(hasPermission("MANAGER", "orders:manage")).toBe(true);
    expect(hasPermission("MANAGER", "settings:manage")).toBe(false);
    expect(hasPermission("MANAGER", "users:manage")).toBe(false);
  });

  it("confines KITCHEN to orders/kitchen — no menu or pricing access", () => {
    expect(hasPermission("KITCHEN", "kitchen:manage")).toBe(true);
    expect(hasPermission("KITCHEN", "orders:view")).toBe(true);
    expect(hasPermission("KITCHEN", "menu:manage")).toBe(false);
    expect(hasPermission("KITCHEN", "menu:view")).toBe(false);
    expect(hasPermission("KITCHEN", "pricing:manage")).toBe(false);
  });

  it("confines CASHIER to orders/payments — no menu access at all", () => {
    expect(hasPermission("CASHIER", "orders:manage")).toBe(true);
    expect(hasPermission("CASHIER", "payments:view")).toBe(true);
    expect(hasPermission("CASHIER", "menu:view")).toBe(false);
    expect(hasPermission("CASHIER", "kitchen:manage")).toBe(false);
  });

  it("lets MARKETING touch descriptions/images/featured but never pricing or structure", () => {
    expect(hasPermission("MARKETING", "descriptions:manage")).toBe(true);
    expect(hasPermission("MARKETING", "images:manage")).toBe(true);
    expect(hasPermission("MARKETING", "featured:manage")).toBe(true);
    expect(hasPermission("MARKETING", "menu:view")).toBe(true);
    expect(hasPermission("MARKETING", "menu:manage")).toBe(false);
    expect(hasPermission("MARKETING", "pricing:manage")).toBe(false);
    expect(hasPermission("MARKETING", "availability:manage")).toBe(false);
  });

  it("returns false, never throws, for an unrecognized role/permission combo", () => {
    // Deliberately passing a bogus role (cast around the type system) to
    // prove hasPermission fails closed instead of throwing.
    expect(hasPermission("NOT_A_ROLE" as never, "menu:view")).toBe(false);
  });
});

describe("permissionsForRole", () => {
  it("gives OWNER the union of every other role's permissions plus settings/users", () => {
    const ownerPerms = permissionsForRole("OWNER");
    expect(ownerPerms).toContain("settings:manage");
    expect(ownerPerms).toContain("users:manage");
    expect(ownerPerms).toContain("kitchen:manage");
    expect(ownerPerms).toContain("descriptions:manage");
  });

  it("gives an unlisted-permission role (KITCHEN) only its own short list", () => {
    const perms = permissionsForRole("KITCHEN");
    expect(perms.sort()).toEqual(["kitchen:manage", "kitchen:view", "orders:view"].sort());
  });
});

describe("ROUTE_PERMISSIONS (middleware's coarse first pass)", () => {
  it("covers every /api/admin/* area the admin nav links to", () => {
    const prefixes = ROUTE_PERMISSIONS.map((r) => r.prefix);
    for (const p of [
      "/api/admin/menu",
      "/api/admin/orders",
      "/api/admin/kitchen",
      "/api/admin/users",
      "/api/admin/settings",
      "/api/admin/integrations",
      "/api/admin/audit-log",
      "/api/admin/analytics",
      "/api/admin/images"
    ]) {
      expect(prefixes).toContain(p);
    }
  });

  it("never grants a bare prefix full menu:manage — pricing/images/etc. stay separately gated", () => {
    const menuRoute = ROUTE_PERMISSIONS.find((r) => r.prefix === "/api/admin/menu");
    expect(menuRoute?.permission).toBe("menu:view");
    // The stricter menu:manage / pricing:manage / images:manage checks live
    // inside the route handlers themselves (field-level RBAC) — see
    // src/app/api/admin/menu/[id]/route.ts permissionsRequiredFor().
  });
});
