import { describe, expect, it, vi, beforeEach } from "vitest";
import { NextRequest } from "next/server";
import crypto from "crypto";

// Idempotency is the whole point of this handler: a delivery platform can
// and will redeliver the same webhook, and the unique (source, externalId)
// row is what stops that from creating a duplicate order. Mocked Prisma —
// this sandbox can't run `prisma generate` (see README) — but the
// duplicate-insert-throws-so-we-return-early control flow under test is
// exactly what the real unique constraint triggers in production.

const webhookEventCreate = vi.fn();
const integrationEventCreate = vi.fn();
const orderCreate = vi.fn();
const emitOrderEvent = vi.fn();
const parseIncomingOrder = vi.fn();

vi.mock("@/lib/prisma", () => ({
  prisma: {
    webhookEvent: { create: (...args: unknown[]) => webhookEventCreate(...args) },
    integrationEvent: { create: (...args: unknown[]) => integrationEventCreate(...args) },
    order: { create: (...args: unknown[]) => orderCreate(...args) }
  }
}));

vi.mock("@/lib/events", () => ({
  emitOrderEvent: (...args: unknown[]) => emitOrderEvent(...args)
}));

vi.mock("@/lib/integrations/registry", () => ({
  getProvider: () => ({ parseIncomingOrder: (...args: unknown[]) => parseIncomingOrder(...args) })
}));

import { handleDeliveryWebhook } from "@/lib/integrations/handle-webhook";

const NORMALIZED_ORDER = {
  externalOrderId: "ext_123",
  customer: { name: "Amina Diop", phone: "9175551234" },
  items: [{ name: "Yassa Chicken", quantity: 1, price: 18 }],
  subtotal: 18,
  tax: 1.6,
  deliveryFee: 3,
  tip: 2,
  total: 24.6
};

function makeRequest(body: unknown, signature: string) {
  return new NextRequest("https://ledakarnyc.com/api/webhooks/uber-eats", {
    method: "POST",
    headers: { "x-uber-signature": signature },
    body: JSON.stringify(body)
  });
}

function sign(body: unknown, secret: string) {
  // Mirrors src/lib/integrations/webhook-verify.ts exactly.
  return crypto.createHmac("sha256", secret).update(JSON.stringify(body)).digest("hex");
}

describe("handleDeliveryWebhook", () => {
  const OLD_ENV = process.env;

  beforeEach(() => {
    process.env = { ...OLD_ENV, UBER_EATS_WEBHOOK_SECRET: "shh-its-a-secret" };
    webhookEventCreate.mockReset().mockResolvedValue({});
    integrationEventCreate.mockReset().mockResolvedValue({});
    orderCreate.mockReset().mockResolvedValue({ id: "order_1", orderNumber: "LD-20260101-1234", status: "CONFIRMED" });
    emitOrderEvent.mockReset();
    parseIncomingOrder.mockReset().mockReturnValue(NORMALIZED_ORDER);
  });

  it("refuses inbound traffic when the platform's webhook secret isn't configured", async () => {
    delete process.env.UBER_EATS_WEBHOOK_SECRET;
    const res = await handleDeliveryWebhook(makeRequest({ any: "payload" }, "whatever"), "UBER_EATS");
    expect(res.status).toBe(400);
    expect(orderCreate).not.toHaveBeenCalled();
  });

  it("rejects a payload with an invalid/missing signature rather than trusting it", async () => {
    const res = await handleDeliveryWebhook(makeRequest({ any: "payload" }, "not-a-valid-signature"), "UBER_EATS");
    expect(res.status).toBe(400);
    expect(orderCreate).not.toHaveBeenCalled();
  });

  it("creates exactly one order for a correctly signed, first-time event", async () => {
    const body = { orderId: "ext_123" };
    const req = makeRequest(body, sign(body, "shh-its-a-secret"));

    const res = await handleDeliveryWebhook(req, "UBER_EATS");
    const json = await res.json();

    expect(res.status).toBe(200);
    expect(json.received).toBe(true);
    expect(orderCreate).toHaveBeenCalledTimes(1);
    expect(webhookEventCreate).toHaveBeenCalledWith({
      data: { source: "uber_eats", externalId: "ext_123", eventType: "order.created" }
    });
  });

  it("never fulfills the same externalOrderId twice — the idempotency guarantee", async () => {
    const body = { orderId: "ext_123" };
    const req1 = makeRequest(body, sign(body, "shh-its-a-secret"));
    const req2 = makeRequest(body, sign(body, "shh-its-a-secret"));

    await handleDeliveryWebhook(req1, "UBER_EATS");
    expect(orderCreate).toHaveBeenCalledTimes(1);

    // Second delivery of the identical event: simulate the real unique
    // constraint violation Postgres would raise on the duplicate insert.
    webhookEventCreate.mockRejectedValueOnce(new Error("Unique constraint failed on (source, externalId)"));

    const res2 = await handleDeliveryWebhook(req2, "UBER_EATS");
    const json2 = await res2.json();

    expect(json2).toEqual({ received: true, duplicate: true });
    expect(orderCreate).toHaveBeenCalledTimes(1); // still just once — no double fulfillment
  });

  it("maps the platform argument to the correct order.source (platform mapping)", async () => {
    const body = { orderId: "ext_456" };
    const req = new NextRequest("https://ledakarnyc.com/api/webhooks/doordash", {
      method: "POST",
      headers: { "x-dd-signature": sign(body, "shh-its-a-secret") },
      body: JSON.stringify(body)
    });
    process.env.DOORDASH_WEBHOOK_SECRET = "shh-its-a-secret";
    parseIncomingOrder.mockReturnValue({ ...NORMALIZED_ORDER, externalOrderId: "ext_456" });

    await handleDeliveryWebhook(req, "DOORDASH");

    expect(orderCreate).toHaveBeenCalledTimes(1);
    const createArgs = orderCreate.mock.calls[0][0];
    expect(createArgs.data.source).toBe("DOORDASH");
    expect(createArgs.data.externalOrderId).toBe("ext_456");
    // Marketplace orders arrive pre-paid by the platform, never PENDING.
    expect(createArgs.data.status).toBe("CONFIRMED");
  });
});
