import { describe, expect, it } from "vitest";
import crypto from "crypto";
import { verifyHmacSignature } from "@/lib/integrations/webhook-verify";

// This same function gates all three delivery-platform webhooks (see
// src/lib/integrations/handle-webhook.ts) and is the thing standing
// between "trusted inbound order" and "anyone can POST a fake order".

function sign(body: string, secret: string) {
  return crypto.createHmac("sha256", secret).update(body).digest("hex");
}

describe("verifyHmacSignature", () => {
  const secret = "test-secret-value";
  const body = JSON.stringify({ orderId: "abc123", total: 42.5 });

  it("accepts a correctly signed payload", () => {
    expect(verifyHmacSignature(body, sign(body, secret), secret)).toBe(true);
  });

  it("rejects a payload signed with the wrong secret", () => {
    expect(verifyHmacSignature(body, sign(body, "wrong-secret"), secret)).toBe(false);
  });

  it("rejects a tampered body signed for different content", () => {
    const validSig = sign(body, secret);
    const tamperedBody = JSON.stringify({ orderId: "abc123", total: 999999 });
    expect(verifyHmacSignature(tamperedBody, validSig, secret)).toBe(false);
  });

  it("rejects a missing signature header outright", () => {
    expect(verifyHmacSignature(body, null, secret)).toBe(false);
  });

  it("rejects a malformed/short signature without throwing", () => {
    expect(() => verifyHmacSignature(body, "not-a-real-signature", secret)).not.toThrow();
    expect(verifyHmacSignature(body, "not-a-real-signature", secret)).toBe(false);
  });
});
