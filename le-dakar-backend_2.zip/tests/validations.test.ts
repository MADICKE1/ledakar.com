import { describe, expect, it } from "vitest";
import {
  adminUserUpsertSchema,
  checkoutSchema,
  galleryImageSchema,
  menuItemUpsertSchema,
  platformProductUpsertSchema,
  qrMenuSettingsSchema
} from "@/lib/validations";

// Server-side input validation is the actual security boundary (frontend
// forms are UX, not enforcement) — these lock in the accepted/rejected
// shape for the fields product/price/availability/staff-role management
// all depend on.

describe("menuItemUpsertSchema", () => {
  const base = { categoryId: "cat_1", name: "Yassa Chicken", price: 18, status: "AVAILABLE" as const };

  it("accepts a minimal valid dish", () => {
    expect(menuItemUpsertSchema.safeParse(base).success).toBe(true);
  });

  it("rejects a negative price", () => {
    const result = menuItemUpsertSchema.safeParse({ ...base, price: -5 });
    expect(result.success).toBe(false);
  });

  it("rejects an empty name", () => {
    const result = menuItemUpsertSchema.safeParse({ ...base, name: "" });
    expect(result.success).toBe(false);
  });

  it("rejects a status outside the AVAILABLE/SOLD_OUT/HIDDEN enum", () => {
    const result = menuItemUpsertSchema.safeParse({ ...base, status: "DELETED" });
    expect(result.success).toBe(false);
  });

  it("rejects an uppercase or symbol-containing slug", () => {
    expect(menuItemUpsertSchema.safeParse({ ...base, slug: "Yassa Chicken!" }).success).toBe(false);
    expect(menuItemUpsertSchema.safeParse({ ...base, slug: "yassa-chicken" }).success).toBe(true);
  });

  it("accepts dietary tags and allergens as string arrays, capped in length", () => {
    expect(
      menuItemUpsertSchema.safeParse({ ...base, dietaryTags: ["halal", "spicy"], allergens: ["peanuts"] }).success
    ).toBe(true);
    const tooMany = Array.from({ length: 25 }, (_, i) => `tag-${i}`);
    expect(menuItemUpsertSchema.safeParse({ ...base, dietaryTags: tooMany }).success).toBe(false);
  });

  it("rejects a prep time outside 0-240 minutes", () => {
    expect(menuItemUpsertSchema.safeParse({ ...base, preparationTimeMins: -1 }).success).toBe(false);
    expect(menuItemUpsertSchema.safeParse({ ...base, preparationTimeMins: 241 }).success).toBe(false);
    expect(menuItemUpsertSchema.safeParse({ ...base, preparationTimeMins: 20 }).success).toBe(true);
  });
});

describe("platformProductUpsertSchema (multi-platform pricing)", () => {
  it("accepts a valid per-platform price", () => {
    const result = platformProductUpsertSchema.safeParse({
      menuItemId: "item_1",
      platform: "UBER_EATS",
      platformPrice: 21.5,
      enabled: true
    });
    expect(result.success).toBe(true);
  });

  it("rejects an unknown platform — only WEBSITE/UBER_EATS/DOORDASH/GRUBHUB are valid", () => {
    const result = platformProductUpsertSchema.safeParse({
      menuItemId: "item_1",
      platform: "POSTMATES",
      platformPrice: 21.5
    });
    expect(result.success).toBe(false);
  });

  it("rejects a negative platform price", () => {
    const result = platformProductUpsertSchema.safeParse({
      menuItemId: "item_1",
      platform: "WEBSITE",
      platformPrice: -1
    });
    expect(result.success).toBe(false);
  });
});

describe("adminUserUpsertSchema (staff accounts)", () => {
  it("accepts a valid new staff member with a strong-enough password", () => {
    const result = adminUserUpsertSchema.safeParse({
      email: "chef@ledakarnyc.com",
      name: "Chef Diallo",
      role: "KITCHEN",
      password: "correct-horse-battery"
    });
    expect(result.success).toBe(true);
  });

  it("rejects a role outside the five defined roles", () => {
    const result = adminUserUpsertSchema.safeParse({
      email: "x@example.com",
      name: "X",
      role: "SUPERADMIN",
      password: "correct-horse-battery"
    });
    expect(result.success).toBe(false);
  });

  it("rejects a too-short password on create", () => {
    const result = adminUserUpsertSchema.safeParse({
      email: "x@example.com",
      name: "X",
      role: "CASHIER",
      password: "short"
    });
    expect(result.success).toBe(false);
  });

  it("allows password to be omitted (edit-without-changing-password flow)", () => {
    const result = adminUserUpsertSchema.safeParse({
      email: "x@example.com",
      name: "X",
      role: "CASHIER"
    });
    expect(result.success).toBe(true);
  });
});

describe("galleryImageSchema", () => {
  it("requires a valid URL", () => {
    expect(galleryImageSchema.safeParse({ url: "not-a-url" }).success).toBe(false);
    expect(galleryImageSchema.safeParse({ url: "https://res.cloudinary.com/x/y.jpg" }).success).toBe(true);
  });
});

describe("qrMenuSettingsSchema", () => {
  it("requires a 6-digit hex color when provided", () => {
    expect(qrMenuSettingsSchema.safeParse({ accentColor: "red" }).success).toBe(false);
    expect(qrMenuSettingsSchema.safeParse({ accentColor: "#C1502E" }).success).toBe(true);
  });

  it("allows an empty object (all fields optional/partial update)", () => {
    expect(qrMenuSettingsSchema.safeParse({}).success).toBe(true);
  });
});

describe("checkoutSchema (cart -> order input)", () => {
  const validCart = {
    firstName: "Amina",
    lastName: "Diop",
    phone: "9175551234",
    email: "amina@example.com",
    orderType: "PICKUP" as const,
    items: [{ menuItemId: "item_1", quantity: 2 }]
  };

  it("accepts a valid pickup order", () => {
    expect(checkoutSchema.safeParse(validCart).success).toBe(true);
  });

  it("rejects an empty cart", () => {
    expect(checkoutSchema.safeParse({ ...validCart, items: [] }).success).toBe(false);
  });

  it("rejects a quantity of zero or above the per-line cap", () => {
    expect(checkoutSchema.safeParse({ ...validCart, items: [{ menuItemId: "item_1", quantity: 0 }] }).success).toBe(
      false
    );
    expect(checkoutSchema.safeParse({ ...validCart, items: [{ menuItemId: "item_1", quantity: 51 }] }).success).toBe(
      false
    );
  });

  it("rejects an invalid email", () => {
    expect(checkoutSchema.safeParse({ ...validCart, email: "not-an-email" }).success).toBe(false);
  });
});
