import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { enqueue, registerWorker } from "@/lib/queue";

// Covers the "zero infrastructure required" fallback path: with no
// REDIS_URL, enqueue() must still run the job (inline) rather than
// silently dropping it, so the app behaves identically whether or not
// Redis has been provisioned. The BullMQ-backed path is not exercised
// here — it needs an actual Redis instance, which isn't available in
// this sandbox (see README's `prisma generate` note for the same class
// of sandbox limitation applied to a different dependency).

describe("queue (no REDIS_URL configured)", () => {
  const OLD_ENV = process.env;

  beforeEach(() => {
    process.env = { ...OLD_ENV };
    delete process.env.REDIS_URL;
  });
  afterEach(() => {
    process.env = OLD_ENV;
  });

  it("runs a registered handler for an enqueued job", async () => {
    const handler = vi.fn().mockResolvedValue(undefined);
    registerWorker("analytics", handler);

    await enqueue("analytics", { date: "2026-01-01" });
    // Inline execution is scheduled via setImmediate — flush the macrotask queue.
    await new Promise((resolve) => setImmediate(resolve));

    expect(handler).toHaveBeenCalledWith({ date: "2026-01-01" });
  });

  it("logs a warning instead of throwing when no worker is registered for a job", async () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    await expect(enqueue("notifications", { type: "test.unregistered", payload: {} })).resolves.toBeUndefined();
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
  });

  it("logs (never throws out of enqueue) when the inline handler itself rejects", async () => {
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    registerWorker("webhook-retry", async () => {
      throw new Error("simulated failure");
    });

    await enqueue("webhook-retry", { source: "uber_eats", externalId: "evt_1" });
    await new Promise((resolve) => setImmediate(resolve));

    expect(errorSpy).toHaveBeenCalled();
    errorSpy.mockRestore();
  });
});
