import Stripe from "stripe";

const secretKey = process.env.STRIPE_SECRET_KEY;

if (!secretKey && process.env.NODE_ENV === "production") {
  // Fail loudly in production rather than silently accepting unpaid orders.
  console.error("STRIPE_SECRET_KEY is not set. Payments will not work.");
}

export const stripe = new Stripe(secretKey || "sk_test_placeholder", {
  apiVersion: "2025-02-24.acacia",
  typescript: true
});

export const STRIPE_PUBLISHABLE_KEY = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "";
