import { prisma } from "@/lib/prisma";
import type { CheckoutInput } from "@/lib/validations";

export class PricingError extends Error {}

/**
 * Recomputes order totals entirely from server-trusted data (current DB
 * prices, current settings, current coupon state). The browser is only
 * trusted for *which* items and quantities were selected — never for any
 * dollar amount. This is what prevents a manipulated client from paying
 * less than the real total.
 */
export async function priceCheckout(input: CheckoutInput) {
  const menuItemIds = input.items.map((i) => i.menuItemId);
  const menuItems = await prisma.menuItem.findMany({ where: { id: { in: menuItemIds } } });
  const byId = new Map(menuItems.map((m) => [m.id, m]));

  const lineItems = input.items.map((line) => {
    const item = byId.get(line.menuItemId);
    if (!item) throw new PricingError(`Menu item ${line.menuItemId} not found.`);
    if (item.status !== "AVAILABLE") {
      throw new PricingError(`"${item.name}" is not currently available.`);
    }
    const price = Number(item.price);
    return {
      menuItemId: item.id,
      name: item.name,
      price,
      quantity: line.quantity,
      specialInstructions: line.specialInstructions || null,
      lineTotal: price * line.quantity
    };
  });

  if (lineItems.length === 0) {
    throw new PricingError("Cart is empty.");
  }

  const subtotal = lineItems.reduce((sum, l) => sum + l.lineTotal, 0);

  const settings = await prisma.restaurantSettings.findFirst();
  const taxRatePercent = settings ? Number(settings.taxRatePercent) : 8.875;
  const configuredDeliveryFee = settings ? Number(settings.deliveryFee) : 0;
  const minOrderAmount = settings ? Number(settings.minOrderAmount) : 0;

  if (input.orderType === "DELIVERY" && settings && !settings.deliveryEnabled) {
    throw new PricingError("Delivery is not currently available. Please choose pickup.");
  }

  if (input.orderType === "DELIVERY" && subtotal < minOrderAmount) {
    throw new PricingError(
      `A minimum order of $${minOrderAmount.toFixed(2)} is required for delivery.`
    );
  }

  let discount = 0;
  let couponCode: string | null = null;
  if (input.couponCode) {
    const coupon = await prisma.coupon.findUnique({ where: { code: input.couponCode.toUpperCase() } });
    if (
      coupon &&
      coupon.active &&
      (!coupon.expiresAt || coupon.expiresAt > new Date()) &&
      (!coupon.maxUses || coupon.usedCount < coupon.maxUses) &&
      subtotal >= Number(coupon.minOrderAmount)
    ) {
      discount =
        coupon.discountType === "PERCENT"
          ? subtotal * (Number(coupon.discountValue) / 100)
          : Number(coupon.discountValue);
      discount = Math.min(discount, subtotal);
      couponCode = coupon.code;
    } else {
      throw new PricingError("This coupon code is invalid or no longer available.");
    }
  }

  const taxableAmount = Math.max(subtotal - discount, 0);
  const tax = taxableAmount * (taxRatePercent / 100);
  const deliveryFee = input.orderType === "DELIVERY" ? configuredDeliveryFee : 0;

  let tip = 0;
  if (typeof input.tipAmount === "number" && input.tipAmount > 0) {
    tip = input.tipAmount;
  } else if (typeof input.tipPercent === "number" && input.tipPercent > 0) {
    tip = subtotal * (input.tipPercent / 100);
  }

  const total = taxableAmount + tax + deliveryFee + tip;

  const round2 = (n: number) => Math.round(n * 100) / 100;

  return {
    lineItems,
    subtotal: round2(subtotal),
    discount: round2(discount),
    tax: round2(tax),
    deliveryFee: round2(deliveryFee),
    tip: round2(tip),
    total: round2(total),
    couponCode
  };
}

export function generateOrderNumber() {
  const date = new Date();
  const ymd = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(
    date.getDate()
  ).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `LD-${ymd}-${rand}`;
}
