import { BaseMockProvider } from "./base-mock-provider";

/**
 * DoorDash adapter — mock-only until real DoorDash Marketplace API
 * credentials exist. See uber-eats-provider.ts for the exact steps to turn
 * this into a real adapter (DoorDash docs: https://developer.doordash.com).
 */
export class DoorDashProvider extends BaseMockProvider {
  readonly platform = "DOORDASH" as const;
}
