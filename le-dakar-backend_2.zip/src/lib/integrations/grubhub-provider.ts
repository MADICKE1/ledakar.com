import { BaseMockProvider } from "./base-mock-provider";

/**
 * Grubhub adapter — mock-only until real Grubhub Marketplace/Partner API
 * credentials exist. See uber-eats-provider.ts for the exact steps to turn
 * this into a real adapter.
 */
export class GrubhubProvider extends BaseMockProvider {
  readonly platform = "GRUBHUB" as const;
}
