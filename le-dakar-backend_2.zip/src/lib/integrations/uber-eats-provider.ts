import { BaseMockProvider } from "./base-mock-provider";

/**
 * Uber Eats adapter. Currently mock-only (see BaseMockProvider) because no
 * Uber Eats API credentials or partnership access exist. To make this a
 * real adapter once you have them:
 *
 *   1. Add UBER_EATS_CLIENT_ID / UBER_EATS_CLIENT_SECRET / UBER_EATS_WEBHOOK_SECRET
 *      to your env (see .env.example) and connect from /admin/integrations.
 *   2. Override updatePrice/updateAvailability/syncMenu/acceptOrder/etc.
 *      below to call Uber Eats' actual Marketplace API
 *      (https://developer.uber.com/docs/eats) instead of just logging.
 *   3. Override parseIncomingOrder to map their real webhook payload shape
 *      into ExternalOrderPayload.
 */
export class UberEatsProvider extends BaseMockProvider {
  readonly platform = "UBER_EATS" as const;
}
