import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyHmacSignature } from "./webhook-verify";
import { getProvider } from "./registry";
import { generateOrderNumber } from "@/lib/pricing";
import { emitOrderEvent } from "@/lib/events";
import type { SalesChannel } from "@prisma/client";

type Platform = "UBER_EATS" | "DOORDASH" | "GRUBHUB";

const SIGNATURE_HEADER: Record<Platform, string> = {
  UBER_EATS: "x-uber-signature",
  DOORDASH: "x-dd-signature",
  GRUBHUB: "x-grubhub-signature"
};

const SECRET_ENV_VAR: Record<Platform, string> = {
  UBER_EATS: "UBER_EATS_WEBHOOK_SECRET",
  DOORDASH: "DOORDASH_WEBHOOK_SECRET",
  GRUBHUB: "GRUBHUB_WEBHOOK_SECRET"
};

/**
 * Shared inbound-order webhook handler for all three delivery platforms.
 * Each platform's route.ts is a 3-line wrapper around this (see
 * src/app/api/webhooks/uber-eats/route.ts for the pattern) — the actual
 * per-platform differences (signature scheme, payload shape) live in
 * src/lib/integrations/webhook-verify.ts and each Provider's
 * parseIncomingOrder(), not duplicated here.
 */
export async function handleDeliveryWebhook(req: NextRequest, platform: Platform) {
  const secret = process.env[SECRET_ENV_VAR[platform]];
  if (!secret) {
    // Never silently accept unverifiable orders — see README "Delivery
    // Platform Integrations" for how to configure this once you have real
    // credentials. Until then this endpoint exists and is documented, but
    // refuses inbound traffic rather than trusting an unsigned payload.
    return NextResponse.json(
      { error: `${SECRET_ENV_VAR[platform]} is not configured — this webhook is not active yet.` },
      { status: 400 }
    );
  }

  const rawBody = await req.text();
  const signature = req.headers.get(SIGNATURE_HEADER[platform]);
  if (!verifyHmacSignature(rawBody, signature, secret)) {
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  let payload: unknown;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "Invalid JSON." }, { status: 400 });
  }

  const provider = getProvider(platform);
  const normalized = provider.parseIncomingOrder(payload);

  // Idempotency: the same externalOrderId (or delivery event) must never be
  // fulfilled twice, exactly like the Stripe webhook.
  try {
    await prisma.webhookEvent.create({
      data: { source: platform.toLowerCase(), externalId: normalized.externalOrderId, eventType: "order.created" }
    });
  } catch {
    return NextResponse.json({ received: true, duplicate: true });
  }

  await prisma.integrationEvent.create({
    data: { platform: platform as SalesChannel, direction: "INBOUND", eventType: "order.received", payload: payload as object }
  });

  const order = await prisma.order.create({
    data: {
      orderNumber: generateOrderNumber(),
      source: platform as SalesChannel,
      externalOrderId: normalized.externalOrderId,
      firstName: normalized.customer.name.split(" ")[0] || normalized.customer.name,
      lastName: normalized.customer.name.split(" ").slice(1).join(" ") || "",
      email: `${normalized.externalOrderId}@${platform.toLowerCase()}.orders.placeholder`,
      phone: normalized.customer.phone || "",
      type: "DELIVERY",
      // Marketplace orders arrive already paid by the platform — they enter
      // our pipeline as CONFIRMED, not PENDING (which means "awaiting our
      // own Stripe payment").
      status: "CONFIRMED",
      subtotal: normalized.subtotal,
      tax: normalized.tax,
      deliveryFee: normalized.deliveryFee,
      tip: normalized.tip,
      total: normalized.total,
      items: {
        create: normalized.items.map((i) => ({
          nameSnapshot: i.name,
          priceSnapshot: i.price,
          quantity: i.quantity
        }))
      }
    }
  });

  emitOrderEvent({ type: "order.created", orderId: order.id, status: order.status });

  return NextResponse.json({ received: true, orderId: order.id, orderNumber: order.orderNumber });
}
