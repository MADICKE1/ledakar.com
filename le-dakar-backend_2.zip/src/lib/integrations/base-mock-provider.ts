import { prisma } from "@/lib/prisma";
import type { DeliveryProvider, ExternalOrderPayload } from "./types";
import type { SalesChannel } from "@prisma/client";

/**
 * Shared MOCK behavior for every delivery platform. A real adapter (once
 * credentials + partnership access exist) extends this and overrides the
 * network-calling methods — see the "real adapter" TODOs in each subclass
 * file. Every call here is logged to IntegrationEvent so /admin/integrations
 * has a real activity trail even in mock mode.
 */
export abstract class BaseMockProvider implements DeliveryProvider {
  abstract readonly platform: "UBER_EATS" | "DOORDASH" | "GRUBHUB";

  protected async log(direction: "INBOUND" | "OUTBOUND", eventType: string, payload?: unknown, success = true, errorMessage?: string) {
    await prisma.integrationEvent
      .create({
        data: {
          platform: this.platform as SalesChannel,
          direction,
          eventType,
          payload: payload === undefined ? undefined : (payload as object),
          success,
          errorMessage
        }
      })
      .catch((err) => console.error(`[integrations:${this.platform}] failed to log event:`, err));
  }

  async isConnected() {
    const cred = await prisma.integrationCredential.findUnique({ where: { platform: this.platform as SalesChannel } });
    return !!cred?.connected;
  }

  async connect() {
    const connected = await this.isConnected();
    await this.log("OUTBOUND", "connect.attempt", { alreadyConnected: connected });
    // Real OAuth/partner handshake happens in a real adapter. In mock mode
    // we just reflect whatever IntegrationCredential.connected already is —
    // /admin/integrations is where an owner actually flips that on, once
    // real credentials are entered via the documented env vars.
    return { connected, sandboxMode: true };
  }

  async disconnect() {
    await prisma.integrationCredential.update({
      where: { platform: this.platform as SalesChannel },
      data: { connected: false, connectedAt: null }
    });
    await this.log("OUTBOUND", "disconnect");
  }

  async syncMenu() {
    const items = await prisma.menuItem.findMany({ where: { status: { not: "HIDDEN" } } });
    await this.log("OUTBOUND", "menu.sync", { itemCount: items.length });
    // MOCK: pretend every item synced. A real adapter would call the
    // platform's catalog API per item and report real failures.
    return { synced: items.length, failed: 0 };
  }

  async updateProduct(menuItemId: string, data: { name: string; description?: string | null }) {
    await this.log("OUTBOUND", "product.update", { menuItemId, ...data });
  }

  async updatePrice(menuItemId: string, price: number) {
    const connected = await this.isConnected();
    await this.log("OUTBOUND", "price.update", { menuItemId, price, connected });
    if (!connected) {
      // Still succeeds in mock mode — this is what lets the app "continue
      // working even if no delivery platform is connected yet."
      return;
    }
  }

  async updateAvailability(menuItemId: string, available: boolean) {
    await this.log("OUTBOUND", "availability.update", { menuItemId, available });
  }

  parseIncomingOrder(rawPayload: unknown): ExternalOrderPayload {
    // MOCK: expects the same shape our own /api/webhooks/{platform} test
    // payloads use. A real adapter parses that platform's actual webhook
    // schema here instead.
    const p = rawPayload as ExternalOrderPayload;
    return p;
  }

  async acceptOrder(externalOrderId: string) {
    await this.log("OUTBOUND", "order.accept", { externalOrderId });
  }

  async rejectOrder(externalOrderId: string, reason: string) {
    await this.log("OUTBOUND", "order.reject", { externalOrderId, reason });
  }

  async updateOrderStatus(externalOrderId: string, status: string) {
    await this.log("OUTBOUND", "order.status", { externalOrderId, status });
  }
}
