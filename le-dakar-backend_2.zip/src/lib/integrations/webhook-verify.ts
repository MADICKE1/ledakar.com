import crypto from "crypto";

/**
 * Generic HMAC-SHA256 webhook signature check (raw body + shared secret ->
 * hex digest, compared in constant time). This is the same *shape* of
 * verification Uber Eats, DoorDash, and Grubhub all use, but each has its
 * own exact header name / encoding / signed-payload format — replace this
 * with that platform's documented scheme when you build the real adapter:
 *
 *   - Uber Eats: https://developer.uber.com/docs/eats/guides/webhooks
 *   - DoorDash:  https://developer.doordash.com/en-US/docs/drive/how-to/webhooks
 *   - Grubhub:   (via partner/API docs once granted access)
 */
export function verifyHmacSignature(rawBody: string, signatureHeader: string | null, secret: string): boolean {
  if (!signatureHeader) return false;
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(signatureHeader);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
