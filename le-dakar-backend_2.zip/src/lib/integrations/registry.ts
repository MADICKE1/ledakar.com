import type { DeliveryProvider } from "./types";
import { UberEatsProvider } from "./uber-eats-provider";
import { DoorDashProvider } from "./doordash-provider";
import { GrubhubProvider } from "./grubhub-provider";

const providers: Record<"UBER_EATS" | "DOORDASH" | "GRUBHUB", DeliveryProvider> = {
  UBER_EATS: new UberEatsProvider(),
  DOORDASH: new DoorDashProvider(),
  GRUBHUB: new GrubhubProvider()
};

export function getProvider(platform: "UBER_EATS" | "DOORDASH" | "GRUBHUB"): DeliveryProvider {
  return providers[platform];
}
