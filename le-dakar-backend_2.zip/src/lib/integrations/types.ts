/**
 * Provider abstraction for delivery-platform integrations.
 *
 * IMPORTANT: no real Uber Eats/DoorDash/Grubhub credentials exist anywhere
 * in this codebase, and none are invented. Every concrete provider below
 * runs in MOCK mode until an owner connects real credentials from
 * /admin/integrations (which only stores the *name* of an env var holding
 * a secret — see prisma.IntegrationCredential — never the secret itself).
 * Until then, calling any of these methods logs the attempt (IntegrationEvent)
 * and resolves successfully with simulated data, so the rest of the app
 * (menu editing, pricing, orders) keeps working with zero required setup.
 */

export type ExternalOrderPayload = {
  externalOrderId: string;
  customer: { name: string; phone?: string };
  items: { name: string; quantity: number; price: number; externalProductId?: string }[];
  subtotal: number;
  tax: number;
  deliveryFee: number;
  tip: number;
  total: number;
};

export interface DeliveryProvider {
  readonly platform: "UBER_EATS" | "DOORDASH" | "GRUBHUB";

  /** Is this provider running against real credentials, or simulating? */
  isConnected(): Promise<boolean>;

  connect(): Promise<{ connected: boolean; sandboxMode: boolean }>;
  disconnect(): Promise<void>;

  /** Push the full current MASTER MENU to this platform. */
  syncMenu(): Promise<{ synced: number; failed: number }>;

  updateProduct(menuItemId: string, data: { name: string; description?: string | null }): Promise<void>;
  updatePrice(menuItemId: string, price: number): Promise<void>;
  updateAvailability(menuItemId: string, available: boolean): Promise<void>;

  /** Normalizes a platform's webhook payload into this app's unified Order shape. */
  parseIncomingOrder(rawPayload: unknown): ExternalOrderPayload;

  acceptOrder(externalOrderId: string): Promise<void>;
  rejectOrder(externalOrderId: string, reason: string): Promise<void>;
  updateOrderStatus(externalOrderId: string, status: string): Promise<void>;
}
