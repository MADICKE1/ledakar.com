import { PrismaClient } from "@prisma/client";

// Reuse a single PrismaClient instance across hot reloads in dev, and across
// serverless invocations where the module stays warm, to avoid exhausting DB
// connections.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"]
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
