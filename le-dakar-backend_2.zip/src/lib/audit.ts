import { prisma } from "@/lib/prisma";

type AuditSession = { adminId: string } | { adminId?: undefined };

/**
 * Writes one audit log row. Never throws into the caller — an audit-log
 * failure (e.g. a transient DB blip) should never block or roll back the
 * actual staff action it's describing, so failures are swallowed and
 * logged to the server console instead.
 */
export async function logAudit(
  session: AuditSession | null | undefined,
  entry: {
    action: string;
    entityType: string;
    entityId?: string;
    oldValue?: unknown;
    newValue?: unknown;
  }
) {
  try {
    await prisma.auditLog.create({
      data: {
        adminId: session?.adminId ?? null,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        oldValue: entry.oldValue === undefined ? undefined : (entry.oldValue as object),
        newValue: entry.newValue === undefined ? undefined : (entry.newValue as object)
      }
    });
  } catch (err) {
    console.error("[audit] failed to write audit log entry:", err);
  }
}

/** Formats "changed X from A to B" style messages for common field diffs. */
export function describeChange(entityName: string, field: string, oldVal: unknown, newVal: unknown): string {
  const fmt = (v: unknown) => (typeof v === "number" ? v.toFixed(2) : String(v));
  return `Changed ${entityName} ${field} from ${fmt(oldVal)} to ${fmt(newVal)}`;
}
