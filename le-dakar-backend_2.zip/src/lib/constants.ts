// Static brand/config fallbacks. Anything that is genuinely restaurant-owner
// data (hours, delivery links, socials, reviews) is NOT hard-coded here — it
// lives in RestaurantSettings / DeliveryPlatform in the database and is
// managed from /admin/settings, per the project brief ("never invent missing
// restaurant info").

export const SITE_NAME = "LE DAKAR";
export const SITE_TAGLINE = "Authentic Senegalese & African Cuisine in New York";
export const SITE_TAGLINE_ALT = "A Taste of Senegal in the Heart of New York";

export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://ledakarnyc.com";

export const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/menu", label: "Menu" },
  { href: "/order", label: "Order Online" },
  { href: "/delivery", label: "Delivery" },
  { href: "/catering", label: "Catering" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" }
];

export const MOBILE_NAV_LINKS = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/menu", label: "Menu", icon: "menu" },
  { href: "/order", label: "Order", icon: "bag" },
  { href: "/checkout", label: "Cart", icon: "cart" },
  { href: "/contact", label: "Contact", icon: "phone" }
] as const;

export const TIP_PRESETS = [15, 18, 20, 25] as const;

export const DEFAULT_TAX_RATE_PERCENT = 8.875; // NYC combined sales tax — editable in admin settings
