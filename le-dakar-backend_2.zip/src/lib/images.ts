import { randomBytes } from "crypto";
import { mkdir, unlink, writeFile } from "fs/promises";
import path from "path";

/**
 * Image storage abstraction — production-quality when Cloudinary env vars
 * are set, with a local-disk fallback so the app works with zero external
 * setup during development.
 *
 * IMPORTANT: the local fallback writes into `public/uploads/`, which is
 * NOT durable on serverless platforms (Vercel's filesystem is read-only /
 * ephemeral outside `/tmp`, and even on a persistent host the files won't
 * survive a redeploy). It exists purely so menu-image uploads work out of
 * the box in local dev without requiring a Cloudinary account first. Set
 * CLOUDINARY_CLOUD_NAME / CLOUDINARY_API_KEY / CLOUDINARY_API_SECRET (see
 * .env.example) before deploying — the code below switches to Cloudinary
 * automatically the moment those three are present, no code change needed.
 */

export type UploadedImage = {
  url: string;
  publicId: string | null;
  width: number | null;
  height: number | null;
  provider: "cloudinary" | "local";
};

const MAX_BYTES = 8 * 1024 * 1024; // 8MB
const ALLOWED_MIME = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"]);

export function isCloudinaryConfigured(): boolean {
  return Boolean(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET);
}

export class ImageValidationError extends Error {}

export function assertValidImageUpload(mimeType: string, size: number) {
  if (!ALLOWED_MIME.has(mimeType)) {
    throw new ImageValidationError(`Unsupported image type "${mimeType}". Use JPEG, PNG, WebP, GIF, or AVIF.`);
  }
  if (size > MAX_BYTES) {
    throw new ImageValidationError(`Image is too large (${(size / 1024 / 1024).toFixed(1)}MB). Max is 8MB.`);
  }
}

export async function uploadImage(
  buffer: Buffer,
  opts: { filename: string; mimeType: string; folder: string }
): Promise<UploadedImage> {
  assertValidImageUpload(opts.mimeType, buffer.byteLength);

  if (isCloudinaryConfigured()) {
    return uploadToCloudinary(buffer, opts);
  }
  return uploadToLocalDisk(buffer, opts);
}

export async function deleteImage(image: { publicId: string | null; url: string; provider?: "cloudinary" | "local" }): Promise<void> {
  if (image.publicId && isCloudinaryConfigured()) {
    const { v2: cloudinary } = await import("cloudinary");
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET
    });
    await cloudinary.uploader.destroy(image.publicId).catch(() => {
      // Best-effort: a failed remote delete shouldn't block removing the DB row.
    });
    return;
  }
  if (image.url.startsWith("/uploads/")) {
    const filePath = path.join(process.cwd(), "public", image.url);
    await unlink(filePath).catch(() => {
      // File may already be gone (e.g. ephemeral filesystem) — non-fatal.
    });
  }
}

/** Inserts Cloudinary's automatic-format/automatic-quality transformation into a delivery URL — the "generate WebP where possible" requirement, done declaratively rather than by re-encoding at upload time. No-op for non-Cloudinary URLs. */
export function optimizedImageUrl(url: string): string {
  if (!url.includes("res.cloudinary.com") || !url.includes("/upload/")) return url;
  if (url.includes("/upload/f_auto")) return url;
  return url.replace("/upload/", "/upload/f_auto,q_auto/");
}

async function uploadToCloudinary(buffer: Buffer, opts: { filename: string; mimeType: string; folder: string }): Promise<UploadedImage> {
  const { v2: cloudinary } = await import("cloudinary");
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
    secure: true
  });

  const dataUri = `data:${opts.mimeType};base64,${buffer.toString("base64")}`;
  const result = await cloudinary.uploader.upload(dataUri, {
    folder: `le-dakar/${opts.folder}`,
    resource_type: "image"
  });

  return {
    url: optimizedImageUrl(result.secure_url),
    publicId: result.public_id,
    width: result.width ?? null,
    height: result.height ?? null,
    provider: "cloudinary"
  };
}

async function uploadToLocalDisk(buffer: Buffer, opts: { filename: string; mimeType: string; folder: string }): Promise<UploadedImage> {
  const ext = extensionFor(opts.mimeType, opts.filename);
  const safeName = `${Date.now()}-${randomBytes(6).toString("hex")}${ext}`;
  const dir = path.join(process.cwd(), "public", "uploads", opts.folder);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, safeName), buffer);

  return {
    url: `/uploads/${opts.folder}/${safeName}`,
    publicId: null,
    width: null,
    height: null,
    provider: "local"
  };
}

function extensionFor(mimeType: string, filename: string): string {
  const fromName = path.extname(filename);
  if (fromName) return fromName.toLowerCase();
  const map: Record<string, string> = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/avif": ".avif"
  };
  return map[mimeType] || "";
}
