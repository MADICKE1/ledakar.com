import { Resend } from "resend";

const resendApiKey = process.env.EMAIL_API_KEY;
const resend = resendApiKey ? new Resend(resendApiKey) : null;

const FROM_ADDRESS = process.env.EMAIL_FROM || "LE DAKAR <orders@ledakarnyc.com>";

export type OrderConfirmationEmailInput = {
  to: string;
  orderNumber: string;
  customerName: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  type: "PICKUP" | "DELIVERY";
  estimatedTime?: string;
};

export async function sendOrderConfirmationEmail(input: OrderConfirmationEmailInput) {
  if (!resend) {
    console.warn(
      `[email] EMAIL_API_KEY not configured — skipping confirmation email for order ${input.orderNumber}.`
    );
    return { skipped: true };
  }

  const itemsHtml = input.items
    .map(
      (i) =>
        `<tr><td style="padding:4px 8px">${i.quantity}x ${i.name}</td><td style="padding:4px 8px;text-align:right">$${(
          i.price * i.quantity
        ).toFixed(2)}</td></tr>`
    )
    .join("");

  const html = `
    <div style="font-family: Georgia, serif; max-width: 480px; margin: 0 auto; color:#221B17;">
      <h1 style="color:#C1502E;">Thank you, ${input.customerName}!</h1>
      <p>Your LE DAKAR order has been received.</p>
      <p><strong>Order #${input.orderNumber}</strong></p>
      <table style="width:100%; border-collapse: collapse; margin: 16px 0;">${itemsHtml}</table>
      <p style="font-size:18px;"><strong>Total: $${input.total.toFixed(2)}</strong></p>
      <p>Order type: ${input.type === "PICKUP" ? "Pickup" : "Delivery"}</p>
      ${input.estimatedTime ? `<p>Estimated time: ${input.estimatedTime}</p>` : ""}
      <p style="margin-top:24px; color:#6B4530;">Merci — see you soon at LE DAKAR.</p>
    </div>
  `;

  try {
    await resend.emails.send({
      from: FROM_ADDRESS,
      to: input.to,
      subject: `LE DAKAR — Order Confirmation #${input.orderNumber}`,
      html
    });
    return { skipped: false };
  } catch (err) {
    console.error("[email] Failed to send order confirmation:", err);
    return { skipped: true, error: err };
  }
}

export type CateringRequestEmailInput = {
  to: string;
  name: string;
  eventDate: string;
  guestCount: number;
};

export async function sendCateringAckEmail(input: CateringRequestEmailInput) {
  if (!resend) return { skipped: true };
  try {
    await resend.emails.send({
      from: FROM_ADDRESS,
      to: input.to,
      subject: "LE DAKAR — Catering Request Received",
      html: `<p>Hi ${input.name},</p><p>Thank you for your catering request for ${input.guestCount} guests on ${input.eventDate}. Our team will reach out shortly to confirm details and pricing.</p><p>— LE DAKAR</p>`
    });
    return { skipped: false };
  } catch (err) {
    console.error("[email] Failed to send catering ack:", err);
    return { skipped: true, error: err };
  }
}

/**
 * SMS notifications are not enabled yet. This stub documents the intended
 * integration point so a provider such as Twilio can be wired in later
 * without changing call sites (see README "SMS Notifications (optional)").
 */
export async function sendOrderStatusSms(_phone: string, _message: string) {
  if (!process.env.TWILIO_ACCOUNT_SID) {
    return { skipped: true, reason: "Twilio not configured" };
  }
  // Intentionally left unimplemented — wire up `twilio` SDK here using
  // TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN / TWILIO_FROM_NUMBER env vars.
  return { skipped: true, reason: "Not implemented" };
}
