import { EventEmitter } from "events";

/**
 * In-process event bus for realtime admin updates (orders, kitchen).
 *
 * This is enough for a single long-lived Node process (Railway/Render, or
 * `next start` anywhere) — exactly this project's documented backend
 * targets. It is NOT a distributed pub/sub: on serverless platforms with
 * multiple concurrent function instances (e.g. Vercel), an event emitted
 * from one instance won't reach an SSE connection held open on another.
 * The admin Orders/Kitchen pages still poll every 15s as a fallback, so
 * they never go stale for more than that — but if you deploy the backend
 * as serverless functions, swap this for Redis pub/sub (the REDIS_URL env
 * var is already there for BullMQ — see src/lib/queue.ts) to get instant
 * updates across instances too.
 */

export type OrderEvent = {
  type: "order.created" | "order.updated";
  orderId: string;
  status?: string;
};

class Bus extends EventEmitter {}
const bus = new Bus();
bus.setMaxListeners(0);

export function emitOrderEvent(event: OrderEvent) {
  bus.emit("order", event);
}

export function onOrderEvent(handler: (event: OrderEvent) => void) {
  bus.on("order", handler);
  return () => bus.off("order", handler);
}
