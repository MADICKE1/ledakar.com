/**
 * Background job queue — Redis + BullMQ when REDIS_URL is configured,
 * an in-process fallback otherwise so the app needs zero extra
 * infrastructure to run locally or on a first deploy.
 *
 * This mirrors the pattern used throughout the integrations layer (see
 * src/lib/integrations/*, src/lib/images.ts): a real, production-quality
 * implementation behind an env var, and a working default when that env
 * var isn't set, so nothing in the app *requires* Redis to function —
 * jobs just run inline instead of being queued and retried durably.
 *
 * Usage:
 *   // once, at startup (e.g. a small worker entrypoint, or lazily on
 *   // first import in a long-lived Node process):
 *   registerWorker("menu-sync", async (data) => { ... });
 *
 *   // anywhere a job needs to run:
 *   await enqueue("menu-sync", { platform: "UBER_EATS", menuItemId });
 *
 * Wired into the app today: platform price/availability sync (see
 * src/app/api/admin/platform-products/route.ts and .../[id]/retry/route.ts)
 * goes through enqueue("menu-sync", ...) instead of a bare fire-and-forget
 * promise, so that path gets Redis-backed retries for free once REDIS_URL
 * is set. The other job types below (image processing, notifications,
 * webhook retry, analytics) are defined and ready to use — nothing in the
 * app currently needs to route through them at this scale (image upload
 * and webhook handling are already fast synchronous operations), so they
 * aren't wired to a call site yet. Register a worker and call enqueue()
 * for any of them exactly like menu-sync above.
 */

export type QueueName = "menu-sync" | "order-sync" | "image-processing" | "notifications" | "webhook-retry" | "analytics";

export type JobPayloads = {
  "menu-sync": { platform: "UBER_EATS" | "DOORDASH" | "GRUBHUB"; menuItemId: string; price: number };
  "order-sync": { orderId: string; platform: "UBER_EATS" | "DOORDASH" | "GRUBHUB" };
  "image-processing": { imageId: string; url: string };
  notifications: { type: string; payload: Record<string, unknown> };
  "webhook-retry": { source: string; externalId: string };
  analytics: { date: string };
};

type Handler<K extends QueueName> = (data: JobPayloads[K]) => Promise<void>;

const handlers = new Map<QueueName, Handler<QueueName>>();

export function registerWorker<K extends QueueName>(name: K, handler: Handler<K>): void {
  handlers.set(name, handler as Handler<QueueName>);
}

function isRedisConfigured(): boolean {
  return Boolean(process.env.REDIS_URL);
}

// Lazily created, one BullMQ Queue per name, only when Redis is actually
// configured — constructing a BullMQ Queue eagerly would try to open a
// Redis connection (defaulting to localhost:6379) even when nobody asked
// for one, which is exactly the kind of "requires infrastructure nobody
// set up" failure this file exists to avoid.
const bullQueues = new Map<QueueName, import("bullmq").Queue>();

async function getBullQueue(name: QueueName) {
  const existing = bullQueues.get(name);
  if (existing) return existing;

  const { Queue } = await import("bullmq");
  const IORedis = (await import("ioredis")).default;
  const connection = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null });
  const queue = new Queue(name, { connection });
  bullQueues.set(name, queue);
  return queue;
}

export async function enqueue<K extends QueueName>(
  name: K,
  data: JobPayloads[K],
  opts?: { delayMs?: number; jobId?: string }
): Promise<void> {
  if (isRedisConfigured()) {
    const queue = await getBullQueue(name);
    await queue.add(name, data, { delay: opts?.delayMs, jobId: opts?.jobId, removeOnComplete: 500, removeOnFail: 1000 });
    return;
  }

  // No Redis: run the job inline instead of dropping it. Not durable (a
  // crash between enqueue and completion loses it, same as the bare
  // fire-and-forget pattern this replaced), but keeps every environment
  // working the same way without a required external dependency.
  const handler = handlers.get(name);
  if (!handler) {
    console.warn(`[queue:${name}] no worker registered — job dropped. Call registerWorker("${name}", ...) first.`);
    return;
  }
  setImmediate(() => {
    handler(data).catch((err) => console.error(`[queue:${name}] inline job failed:`, err));
  });
}

/**
 * Starts a BullMQ Worker for every registered handler. No-op when Redis
 * isn't configured (inline execution via enqueue() already covers that
 * case). Call this once from a long-lived process — the same Next.js
 * server process is fine at this app's scale; split into a separate
 * worker process only if job volume ever demands it.
 */
export async function startQueueWorkers(): Promise<void> {
  if (!isRedisConfigured()) return;

  const { Worker } = await import("bullmq");
  const IORedis = (await import("ioredis")).default;

  for (const [name, handler] of handlers) {
    const connection = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null });
    new Worker(
      name,
      async (job) => {
        await handler(job.data);
      },
      { connection }
    );
  }
}
