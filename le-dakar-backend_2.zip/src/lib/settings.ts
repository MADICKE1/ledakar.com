import { prisma } from "@/lib/prisma";
import { DeliveryPlatformName } from "@prisma/client";

/**
 * Restaurant settings is a singleton row. This helper fetches it, creating a
 * blank default row on first run so the rest of the app never has to
 * null-check "does settings exist" — only whether individual fields
 * (hours, socials, review link, etc.) have been filled in by the owner yet.
 */
export async function getRestaurantSettings() {
  let settings = await prisma.restaurantSettings.findFirst();
  if (!settings) {
    settings = await prisma.restaurantSettings.create({ data: {} });
  }
  return settings;
}

export async function getDeliveryPlatforms() {
  const platforms = await prisma.deliveryPlatform.findMany();
  const byName = new Map(platforms.map((p) => [p.name, p]));

  // Guarantee all three platform rows exist so the admin settings page
  // always has something to render, even on a fresh database.
  for (const name of [
    DeliveryPlatformName.UBER_EATS,
    DeliveryPlatformName.DOORDASH,
    DeliveryPlatformName.GRUBHUB
  ]) {
    if (!byName.has(name)) {
      const created = await prisma.deliveryPlatform.create({
        data: { name, url: null, enabled: false }
      });
      byName.set(name, created);
    }
  }

  return Array.from(byName.values());
}

/** Only platforms with a real, configured URL and enabled=true are ever shown publicly. */
export function publiclyVisiblePlatforms(
  platforms: { name: DeliveryPlatformName; url: string | null; enabled: boolean }[]
) {
  return platforms.filter((p) => p.enabled && p.url && p.url.trim().length > 0);
}

export const DELIVERY_PLATFORM_LABELS: Record<DeliveryPlatformName, string> = {
  UBER_EATS: "Uber Eats",
  DOORDASH: "DoorDash",
  GRUBHUB: "Grubhub"
};
