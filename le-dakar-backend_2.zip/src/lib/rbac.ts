import type { AdminRole } from "@prisma/client";

/**
 * Pure permission logic — no imports beyond the Prisma-generated enum type.
 * This file must stay Edge-runtime-safe: `src/middleware.ts` imports it
 * directly. Anything that touches the database, cookies, or bcrypt (i.e.
 * anything that needs the actual current session) belongs in
 * `src/lib/rbac-guard.ts` instead, which is Node-only and used by route
 * handlers and server components.
 *
 * `OWNER` is not listed in ROLE_PERMISSIONS — it always has full access,
 * checked first in `hasPermission` (brief: "OWNER: full access").
 */
export type Permission =
  | "orders:view"
  | "orders:manage" // change status, accept/reject
  | "kitchen:view"
  | "kitchen:manage" // start/ready/complete
  | "payments:view"
  | "menu:view"
  | "menu:manage" // create/edit/delete dishes, categories, modifiers
  | "pricing:manage" // base + platform prices
  | "availability:manage"
  | "images:manage"
  | "descriptions:manage" // marketing copy on existing items
  | "featured:manage"
  | "customers:view"
  | "analytics:view"
  | "integrations:manage"
  | "settings:manage"
  | "users:manage"
  | "coupons:manage"
  | "catering:manage"
  | "inventory:manage"
  | "audit:view";

const ROLE_PERMISSIONS: Record<Exclude<AdminRole, "OWNER">, Permission[]> = {
  MANAGER: [
    "orders:view",
    "orders:manage",
    "kitchen:view",
    "kitchen:manage",
    "payments:view",
    "menu:view",
    "menu:manage",
    "pricing:manage",
    "availability:manage",
    "images:manage",
    "descriptions:manage",
    "featured:manage",
    "customers:view",
    "analytics:view",
    "integrations:manage",
    "coupons:manage",
    "catering:manage",
    "inventory:manage",
    "audit:view"
    // Managers run day-to-day operations but can't touch restaurant
    // settings or other staff accounts — that's OWNER-only.
  ],
  KITCHEN: ["orders:view", "kitchen:view", "kitchen:manage"],
  CASHIER: ["orders:view", "orders:manage", "payments:view"],
  MARKETING: ["menu:view", "descriptions:manage", "images:manage", "featured:manage", "analytics:view"]
};

export function hasPermission(role: AdminRole, permission: Permission): boolean {
  if (role === "OWNER") return true;
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

export function permissionsForRole(role: AdminRole): Permission[] {
  if (role === "OWNER") {
    return Array.from(
      new Set(Object.values(ROLE_PERMISSIONS).flat())
    ).concat(["settings:manage", "users:manage"]) as Permission[];
  }
  return ROLE_PERMISSIONS[role] ?? [];
}

/** Route-prefix -> permission map, used by middleware for a coarse first pass. */
export const ROUTE_PERMISSIONS: { prefix: string; permission: Permission }[] = [
  { prefix: "/api/admin/kitchen", permission: "kitchen:view" },
  { prefix: "/api/admin/orders", permission: "orders:view" },
  { prefix: "/api/admin/menu", permission: "menu:view" },
  { prefix: "/api/admin/categories", permission: "menu:view" },
  { prefix: "/api/admin/customers", permission: "customers:view" },
  { prefix: "/api/admin/analytics", permission: "analytics:view" },
  { prefix: "/api/admin/integrations", permission: "integrations:manage" },
  { prefix: "/api/admin/coupons", permission: "coupons:manage" },
  { prefix: "/api/admin/catering", permission: "catering:manage" },
  { prefix: "/api/admin/inventory", permission: "inventory:manage" },
  { prefix: "/api/admin/audit-log", permission: "audit:view" },
  { prefix: "/api/admin/users", permission: "users:manage" },
  { prefix: "/api/admin/settings", permission: "settings:manage" },
  { prefix: "/api/admin/delivery-platforms", permission: "settings:manage" },
  { prefix: "/api/admin/qr-menu", permission: "menu:view" },
  { prefix: "/api/admin/modifier-groups", permission: "menu:view" },
  { prefix: "/api/admin/modifiers", permission: "menu:view" },
  { prefix: "/api/admin/platform-products", permission: "pricing:manage" },
  { prefix: "/api/admin/images", permission: "images:manage" }
];
