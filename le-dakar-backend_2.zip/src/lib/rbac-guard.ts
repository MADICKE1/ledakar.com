import { NextResponse } from "next/server";
import type { AdminRole } from "@prisma/client";
import { getAdminSession } from "@/lib/auth";
import { hasPermission, type Permission } from "@/lib/rbac";

// Node-only (uses next/headers + Prisma via auth.ts) — import this from
// route handlers and server components, never from middleware.ts.

export class ForbiddenError extends Error {
  constructor(permission: Permission) {
    super(`Role lacks permission: ${permission}`);
    this.name = "ForbiddenError";
  }
}

/**
 * Server-side guard for API route handlers and server components. Throws
 * (never just returns false) so a route can't accidentally fall through and
 * run anyway if a caller forgets to check a boolean return value.
 *
 *   const session = await requirePermission("pricing:manage");
 */
export async function requirePermission(permission: Permission) {
  const session = await getAdminSession();
  if (!session) {
    throw new ForbiddenError(permission); // no session — middleware should already have redirected/401'd
  }
  if (!hasPermission(session.role as AdminRole, permission)) {
    throw new ForbiddenError(permission);
  }
  return session;
}

/** Wraps a route handler body so ForbiddenError becomes a clean 403 JSON response. */
export async function withPermission<T>(
  permission: Permission,
  fn: (session: Awaited<ReturnType<typeof requirePermission>>) => Promise<T>
): Promise<T | NextResponse> {
  try {
    const session = await requirePermission(permission);
    return await fn(session);
  } catch (err) {
    if (err instanceof ForbiddenError) {
      return NextResponse.json({ error: "Forbidden — your role does not allow this action." }, { status: 403 });
    }
    throw err;
  }
}
