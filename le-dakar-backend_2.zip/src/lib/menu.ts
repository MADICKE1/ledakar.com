import { prisma } from "@/lib/prisma";
import type { MenuCategoryDTO, MenuItemDTO } from "@/types";

function toItemDTO(item: {
  id: string;
  categoryId: string;
  name: string;
  slug: string;
  description: string | null;
  price: unknown;
  imageUrl: string | null;
  status: string;
  isFeatured: boolean;
  sortOrder: number;
  priceUnclear: boolean;
  allergenNote: string | null;
  allergens: string[];
  dietaryTags: string[];
  preparationTimeMins: number | null;
}): MenuItemDTO {
  return {
    id: item.id,
    categoryId: item.categoryId,
    name: item.name,
    slug: item.slug,
    description: item.description,
    price: Number(item.price),
    imageUrl: item.imageUrl,
    status: item.status as MenuItemDTO["status"],
    isFeatured: item.isFeatured,
    sortOrder: item.sortOrder,
    priceUnclear: item.priceUnclear,
    allergenNote: item.allergenNote,
    allergens: item.allergens,
    dietaryTags: item.dietaryTags,
    preparationTimeMins: item.preparationTimeMins
  };
}

/** Public menu: hides HIDDEN items entirely; SOLD_OUT items still render (greyed out, unorderable). */
export async function getPublicMenu(): Promise<MenuCategoryDTO[]> {
  const categories = await prisma.menuCategory.findMany({
    orderBy: { sortOrder: "asc" },
    include: {
      items: {
        where: { status: { in: ["AVAILABLE", "SOLD_OUT"] } },
        orderBy: { sortOrder: "asc" }
      }
    }
  });

  return categories
    .map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      description: c.description,
      sortOrder: c.sortOrder,
      items: c.items.map(toItemDTO)
    }))
    .filter((c) => c.items.length > 0);
}

export async function getFeaturedItems(limit = 8): Promise<MenuItemDTO[]> {
  const items = await prisma.menuItem.findMany({
    where: { isFeatured: true, status: "AVAILABLE" },
    orderBy: { sortOrder: "asc" },
    take: limit
  });
  return items.map(toItemDTO);
}
