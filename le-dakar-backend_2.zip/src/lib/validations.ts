import { z } from "zod";

export const cartLineSchema = z.object({
  menuItemId: z.string().min(1),
  quantity: z.number().int().min(1).max(50),
  specialInstructions: z.string().max(300).optional().nullable()
});

export const checkoutSchema = z.object({
  firstName: z.string().min(1).max(80),
  lastName: z.string().min(1).max(80),
  phone: z.string().min(7).max(20),
  email: z.string().email(),
  orderType: z.enum(["PICKUP", "DELIVERY"]),
  address: z
    .object({
      line1: z.string().min(1),
      line2: z.string().optional().nullable(),
      city: z.string().min(1),
      state: z.string().min(2).max(2),
      zip: z.string().min(5).max(10),
      instructions: z.string().max(300).optional().nullable()
    })
    .optional()
    .nullable(),
  items: z.array(cartLineSchema).min(1),
  tipPercent: z.number().min(0).max(100).optional(),
  tipAmount: z.number().min(0).optional(),
  couponCode: z.string().max(40).optional().nullable(),
  scheduledFor: z.string().datetime().optional().nullable()
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;

export const cateringRequestSchema = z.object({
  name: z.string().min(1).max(120),
  company: z.string().max(120).optional().nullable(),
  phone: z.string().min(7).max(20),
  email: z.string().email(),
  eventDate: z.string().min(1),
  guestCount: z.number().int().min(1).max(5000),
  eventType: z.string().min(1).max(120),
  budget: z.string().max(120).optional().nullable(),
  requestedDishes: z.string().max(2000).optional().nullable(),
  additionalInfo: z.string().max(2000).optional().nullable()
});

export const adminLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

export const menuItemUpsertSchema = z.object({
  id: z.string().optional(),
  categoryId: z.string().min(1),
  name: z.string().min(1).max(160),
  slug: z
    .string()
    .min(1)
    .max(160)
    .regex(/^[a-z0-9-]+$/, "Slug must be lowercase letters, numbers, and hyphens only.")
    .optional(),
  description: z.string().max(1000).optional().nullable(),
  price: z.number().min(0),
  imageUrl: z.string().url().optional().nullable(),
  status: z.enum(["AVAILABLE", "SOLD_OUT", "HIDDEN"]),
  isFeatured: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
  allergenNote: z.string().max(300).optional().nullable(),
  allergens: z.array(z.string().max(60)).max(20).optional(),
  ingredients: z.array(z.string().max(80)).max(40).optional(),
  dietaryTags: z.array(z.string().max(40)).max(15).optional(),
  preparationTimeMins: z.number().int().min(0).max(240).optional().nullable()
});

export const modifierGroupUpsertSchema = z.object({
  id: z.string().optional(),
  menuItemId: z.string().min(1),
  name: z.string().min(1).max(120),
  required: z.boolean().optional(),
  minSelect: z.number().int().min(0).max(20).optional(),
  maxSelect: z.number().int().min(1).max(20).optional(),
  sortOrder: z.number().int().optional()
});

export const modifierUpsertSchema = z.object({
  id: z.string().optional(),
  groupId: z.string().min(1),
  name: z.string().min(1).max(120),
  priceDelta: z.number().optional(),
  available: z.boolean().optional(),
  sortOrder: z.number().int().optional()
});

export const platformProductUpsertSchema = z.object({
  menuItemId: z.string().min(1),
  platform: z.enum(["WEBSITE", "UBER_EATS", "DOORDASH", "GRUBHUB"]),
  platformPrice: z.number().min(0),
  enabled: z.boolean().optional(),
  externalProductId: z.string().max(160).optional().nullable()
});

export const qrMenuSettingsSchema = z.object({
  headline: z.string().max(120).optional().nullable(),
  accentColor: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/, "Use a 6-digit hex color, e.g. #C1502E")
    .optional()
    .nullable(),
  showAllergens: z.boolean().optional(),
  showFeatured: z.boolean().optional()
});

export const galleryImageSchema = z.object({
  url: z.string().url(),
  publicId: z.string().max(300).optional().nullable(),
  width: z.number().int().optional().nullable(),
  height: z.number().int().optional().nullable()
});

export const adminUserUpsertSchema = z.object({
  id: z.string().optional(),
  email: z.string().email(),
  name: z.string().min(1).max(120),
  role: z.enum(["OWNER", "MANAGER", "KITCHEN", "CASHIER", "MARKETING"]),
  password: z.string().min(8).max(200).optional(), // required on create, optional on edit (leave blank to keep current)
  active: z.boolean().optional()
});

export const kitchenActionSchema = z.object({
  action: z.enum(["START", "READY", "COMPLETE"])
});

export const restaurantSettingsSchema = z.object({
  name: z.string().min(1),
  tagline: z.string().min(1),
  addressLine1: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  state: z.string().optional().nullable(),
  zip: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  email: z.string().email().optional().nullable(),
  hours: z.record(z.string()).optional().nullable(),
  googleMapsUrl: z.string().url().optional().nullable(),
  googleReviewUrl: z.string().url().optional().nullable(),
  instagramUrl: z.string().url().optional().nullable(),
  facebookUrl: z.string().url().optional().nullable(),
  tiktokUrl: z.string().url().optional().nullable(),
  pickupEnabled: z.boolean(),
  deliveryEnabled: z.boolean(),
  minOrderAmount: z.number().min(0),
  deliveryFee: z.number().min(0),
  deliveryRadiusMiles: z.number().min(0),
  taxRatePercent: z.number().min(0).max(30)
});

export const couponUpsertSchema = z.object({
  id: z.string().optional(),
  code: z.string().min(2).max(40),
  description: z.string().max(300).optional().nullable(),
  discountType: z.enum(["PERCENT", "FIXED"]),
  discountValue: z.number().min(0),
  minOrderAmount: z.number().min(0).optional(),
  maxUses: z.number().int().min(1).optional().nullable(),
  active: z.boolean(),
  expiresAt: z.string().optional().nullable()
});

export const deliveryPlatformSchema = z.object({
  name: z.enum(["UBER_EATS", "DOORDASH", "GRUBHUB"]),
  url: z.string().url().optional().nullable(),
  enabled: z.boolean()
});
