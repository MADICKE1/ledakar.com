import { registerWorker } from "@/lib/queue";
import { prisma } from "@/lib/prisma";
import { getProvider } from "@/lib/integrations/registry";

/**
 * The actual work behind a "menu-sync" job: push one item's price to one
 * delivery platform, then record the result. Registered once at server
 * startup (see src/instrumentation.ts) so it's ready whether the job runs
 * inline (no REDIS_URL — src/lib/queue.ts's fallback) or via a real BullMQ
 * Worker (REDIS_URL set). Either way this is the same code path the old
 * fire-and-forget `.then()/.catch()` in the platform-products routes used
 * to run directly — centralizing it here is what makes it retryable.
 */
registerWorker("menu-sync", async ({ platform, menuItemId, price }) => {
  const provider = getProvider(platform);

  try {
    await provider.updatePrice(menuItemId, price);
    await prisma.platformProduct.updateMany({
      where: { menuItemId, platform },
      data: { syncStatus: "SYNCED", lastSyncedAt: new Date(), syncError: null }
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown sync error";
    await prisma.platformProduct.updateMany({
      where: { menuItemId, platform },
      data: { syncStatus: "FAILED", syncError: message }
    });
    throw err; // let BullMQ's retry policy see the failure when Redis is configured
  }
});
