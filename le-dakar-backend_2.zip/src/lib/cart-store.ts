"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine } from "@/types";

type CartState = {
  lines: CartLine[];
  orderType: "PICKUP" | "DELIVERY";
  addItem: (line: CartLine) => void;
  removeItem: (menuItemId: string, specialInstructions?: string) => void;
  updateQuantity: (menuItemId: string, quantity: number, specialInstructions?: string) => void;
  setOrderType: (type: "PICKUP" | "DELIVERY") => void;
  clear: () => void;
  subtotal: () => number;
  itemCount: () => number;
};

// A cart line is keyed by menuItemId + specialInstructions so the same dish
// with different notes ("no onions" vs "extra spicy") stays separate.
function lineKey(menuItemId: string, specialInstructions?: string) {
  return `${menuItemId}::${specialInstructions?.trim() || ""}`;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      orderType: "PICKUP",

      addItem: (line) => {
        set((state) => {
          const key = lineKey(line.menuItemId, line.specialInstructions);
          const existingIndex = state.lines.findIndex(
            (l) => lineKey(l.menuItemId, l.specialInstructions) === key
          );
          if (existingIndex >= 0) {
            const updated = [...state.lines];
            updated[existingIndex] = {
              ...updated[existingIndex],
              quantity: updated[existingIndex].quantity + line.quantity
            };
            return { lines: updated };
          }
          return { lines: [...state.lines, line] };
        });
      },

      removeItem: (menuItemId, specialInstructions) => {
        set((state) => ({
          lines: state.lines.filter(
            (l) => lineKey(l.menuItemId, l.specialInstructions) !== lineKey(menuItemId, specialInstructions)
          )
        }));
      },

      updateQuantity: (menuItemId, quantity, specialInstructions) => {
        set((state) => ({
          lines: state.lines
            .map((l) =>
              lineKey(l.menuItemId, l.specialInstructions) === lineKey(menuItemId, specialInstructions)
                ? { ...l, quantity }
                : l
            )
            .filter((l) => l.quantity > 0)
        }));
      },

      setOrderType: (type) => set({ orderType: type }),

      clear: () => set({ lines: [] }),

      subtotal: () => get().lines.reduce((sum, l) => sum + l.price * l.quantity, 0),

      itemCount: () => get().lines.reduce((sum, l) => sum + l.quantity, 0)
    }),
    {
      name: "ledakar-cart",
      version: 1
    }
  )
);
