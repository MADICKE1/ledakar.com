// Next.js server-startup hook (stable since Next 14, no experimental flag
// needed). Starts BullMQ workers for the background job queue — see
// src/lib/queue.ts — but only when REDIS_URL is actually configured and
// only in the real Node.js server process (this file's register() also
// runs once for the Edge runtime compilation, which must never try to
// open a Redis/TCP connection).
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  // Registers the one job type actually wired into the app today (see
  // src/lib/queue.ts's file comment for what "wired in" means here). Must
  // run before startQueueWorkers() below, which only creates a BullMQ
  // Worker for handlers that are already registered.
  await import("@/lib/jobs/menu-sync-worker");

  const { startQueueWorkers } = await import("@/lib/queue");
  await startQueueWorkers(); // no-op when REDIS_URL isn't set
}
