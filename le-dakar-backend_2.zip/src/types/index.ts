export type MenuItemDTO = {
  id: string;
  categoryId: string;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  imageUrl: string | null;
  status: "AVAILABLE" | "SOLD_OUT" | "HIDDEN";
  isFeatured: boolean;
  sortOrder: number;
  priceUnclear: boolean;
  allergenNote: string | null;
  allergens: string[];
  dietaryTags: string[];
  preparationTimeMins: number | null;
};

export type MenuCategoryDTO = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  sortOrder: number;
  items: MenuItemDTO[];
};

export type CartLine = {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  specialInstructions?: string;
  imageUrl?: string | null;
};

export type OrderType = "PICKUP" | "DELIVERY";
