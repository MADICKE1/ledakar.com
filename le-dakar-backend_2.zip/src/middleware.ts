import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";
import { hasPermission, ROUTE_PERMISSIONS } from "@/lib/rbac";
import type { AdminRole } from "@prisma/client";

const ADMIN_COOKIE = "ledakar_admin_session";
const secret = new TextEncoder().encode(
  process.env.ADMIN_SESSION_SECRET || "dev-only-insecure-secret-change-me"
);

async function getSession(req: NextRequest): Promise<{ role: AdminRole } | null> {
  const token = req.cookies.get(ADMIN_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return payload as unknown as { role: AdminRole };
  } catch {
    return null;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const isApiAdmin = pathname.startsWith("/api/admin") && pathname !== "/api/admin/login";
  const isAdminPage = pathname.startsWith("/admin") && pathname !== "/admin/login";

  if (isApiAdmin || isAdminPage) {
    const session = await getSession(req);
    if (!session) {
      if (isApiAdmin) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
      }
      const loginUrl = new URL("/admin/login", req.url);
      loginUrl.searchParams.set("next", pathname);
      return NextResponse.redirect(loginUrl);
    }

    // Coarse RBAC pass: does this role have at least view access to this
    // area at all? Fine-grained checks (e.g. "can view but not edit prices")
    // happen inside each route handler via requirePermission/withPermission
    // — middleware can't tell a GET from a role-restricted POST body here
    // without duplicating route logic, so it only blocks whole areas a role
    // has zero business being in (e.g. KITCHEN hitting /api/admin/settings).
    const rule = ROUTE_PERMISSIONS.find((r) => pathname.startsWith(r.prefix));
    if (rule && !hasPermission(session.role, rule.permission)) {
      if (isApiAdmin) {
        return NextResponse.json({ error: "Forbidden — your role does not allow this." }, { status: 403 });
      }
      return NextResponse.redirect(new URL("/admin", req.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/api/admin/:path*"]
};
