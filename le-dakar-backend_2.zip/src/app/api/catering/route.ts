import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { cateringRequestSchema } from "@/lib/validations";
import { sendCateringAckEmail } from "@/lib/email";
import { getRestaurantSettings } from "@/lib/settings";

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = cateringRequestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
  }

  const data = parsed.data;

  const request = await prisma.cateringRequest.create({
    data: {
      name: data.name,
      company: data.company || null,
      phone: data.phone,
      email: data.email,
      eventDate: new Date(data.eventDate),
      guestCount: data.guestCount,
      eventType: data.eventType,
      budget: data.budget || null,
      requestedDishes: data.requestedDishes || null,
      additionalInfo: data.additionalInfo || null
    }
  });

  await sendCateringAckEmail({
    to: data.email,
    name: data.name,
    eventDate: data.eventDate,
    guestCount: data.guestCount
  });

  // Notify the restaurant too, if a contact email has been configured.
  const settings = await getRestaurantSettings();
  if (settings.email) {
    await sendCateringAckEmail({
      to: settings.email,
      name: `New catering request from ${data.name}`,
      eventDate: data.eventDate,
      guestCount: data.guestCount
    });
  }

  return NextResponse.json({ id: request.id }, { status: 201 });
}
