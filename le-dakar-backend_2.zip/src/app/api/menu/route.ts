import { NextResponse } from "next/server";
import { getPublicMenu } from "@/lib/menu";

export async function GET() {
  const categories = await getPublicMenu();
  return NextResponse.json({ categories });
}
