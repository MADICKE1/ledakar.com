import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";
import { checkoutSchema } from "@/lib/validations";
import { priceCheckout, generateOrderNumber, PricingError } from "@/lib/pricing";
import { SITE_URL } from "@/lib/constants";
import { emitOrderEvent } from "@/lib/events";

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
  }
  const input = parsed.data;

  if (input.orderType === "DELIVERY" && !input.address) {
    return NextResponse.json({ error: "A delivery address is required." }, { status: 400 });
  }

  let priced;
  try {
    // All dollar amounts are recomputed server-side from the database here —
    // the client's cart is only ever trusted for item IDs and quantities.
    priced = await priceCheckout(input);
  } catch (err) {
    if (err instanceof PricingError) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Unable to price this order." }, { status: 500 });
  }

  // Upsert the customer record.
  const customer = await prisma.customer.upsert({
    where: { email: input.email },
    update: { firstName: input.firstName, lastName: input.lastName, phone: input.phone },
    create: {
      email: input.email,
      firstName: input.firstName,
      lastName: input.lastName,
      phone: input.phone
    }
  });

  let addressId: string | undefined;
  if (input.orderType === "DELIVERY" && input.address) {
    const address = await prisma.address.create({
      data: {
        customerId: customer.id,
        line1: input.address.line1,
        line2: input.address.line2 || null,
        city: input.address.city,
        state: input.address.state.toUpperCase(),
        zip: input.address.zip,
        instructions: input.address.instructions || null
      }
    });
    addressId = address.id;
  }

  const orderNumber = generateOrderNumber();

  const order = await prisma.order.create({
    data: {
      orderNumber,
      customerId: customer.id,
      firstName: input.firstName,
      lastName: input.lastName,
      email: input.email,
      phone: input.phone,
      type: input.orderType,
      status: "PENDING",
      addressId,
      deliveryInstructions: input.address?.instructions || null,
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : null,
      subtotal: priced.subtotal,
      tax: priced.tax,
      deliveryFee: priced.deliveryFee,
      tip: priced.tip,
      discount: priced.discount,
      total: priced.total,
      couponCode: priced.couponCode,
      items: {
        create: priced.lineItems.map((li) => ({
          menuItemId: li.menuItemId,
          nameSnapshot: li.name,
          priceSnapshot: li.price,
          quantity: li.quantity,
          specialInstructions: li.specialInstructions
        }))
      }
    }
  });

  emitOrderEvent({ type: "order.created", orderId: order.id, status: order.status });

  const toCents = (n: number) => Math.round(n * 100);

  const lineItems: import("stripe").default.Checkout.SessionCreateParams.LineItem[] = priced.lineItems.map(
    (li) => ({
      quantity: li.quantity,
      price_data: {
        currency: "usd",
        unit_amount: toCents(li.price),
        product_data: { name: li.name }
      }
    })
  );

  // Stripe Checkout line items cannot have a negative unit_amount, so a
  // discount is applied as a real Stripe coupon on the session rather than
  // as a negative line item.
  let stripeDiscounts: import("stripe").default.Checkout.SessionCreateParams.Discount[] | undefined;
  if (priced.discount > 0) {
    const stripeCoupon = await stripe.coupons.create({
      amount_off: toCents(priced.discount),
      currency: "usd",
      duration: "once",
      name: `Discount${priced.couponCode ? ` (${priced.couponCode})` : ""}`
    });
    stripeDiscounts = [{ coupon: stripeCoupon.id }];
  }
  if (priced.tax > 0) {
    lineItems.push({
      quantity: 1,
      price_data: { currency: "usd", unit_amount: toCents(priced.tax), product_data: { name: "Sales Tax" } }
    });
  }
  if (priced.deliveryFee > 0) {
    lineItems.push({
      quantity: 1,
      price_data: {
        currency: "usd",
        unit_amount: toCents(priced.deliveryFee),
        product_data: { name: "Delivery Fee" }
      }
    });
  }
  if (priced.tip > 0) {
    lineItems.push({
      quantity: 1,
      price_data: { currency: "usd", unit_amount: toCents(priced.tip), product_data: { name: "Tip" } }
    });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: lineItems,
      ...(stripeDiscounts ? { discounts: stripeDiscounts } : { allow_promotion_codes: false }),
      customer_email: input.email,
      client_reference_id: order.id,
      metadata: { orderId: order.id, orderNumber },
      success_url: `${SITE_URL}/checkout/success?order=${orderNumber}`,
      cancel_url: `${SITE_URL}/checkout/cancel?order=${orderNumber}`
    });

    await prisma.payment.create({
      data: {
        orderId: order.id,
        stripeCheckoutSessionId: session.id,
        amount: priced.total,
        currency: "usd",
        status: "REQUIRES_PAYMENT"
      }
    });

    return NextResponse.json({ url: session.url, orderNumber });
  } catch (err) {
    console.error("[checkout] Stripe session creation failed:", err);
    await prisma.order.update({ where: { id: order.id }, data: { status: "CANCELLED" } });
    return NextResponse.json(
      { error: "We couldn't start payment. Please check your Stripe configuration and try again." },
      { status: 502 }
    );
  }
}
