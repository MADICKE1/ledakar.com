import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";
import { getProvider } from "@/lib/integrations/registry";
import { logAudit } from "@/lib/audit";

// Retries a FAILED sync for one item/platform pair — the button behind
// "Uber Eats: FAILED" in the staff dashboard. Deliberately synchronous
// (unlike the queued sync in POST /api/admin/platform-products — see
// src/lib/queue.ts) rather than enqueued: a human just clicked "Retry" and
// the UI wants an immediate success/failure result to show, not a job id.
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("pricing:manage", async (session) => {
    const record = await prisma.platformProduct.findUnique({ where: { id: params.id } });
    if (!record) return NextResponse.json({ error: "Not found." }, { status: 404 });
    if (record.platform === "WEBSITE") {
      return NextResponse.json({ error: "Website pricing doesn't need syncing." }, { status: 400 });
    }

    await prisma.platformProduct.update({ where: { id: record.id }, data: { syncStatus: "PENDING" } });

    const provider = getProvider(record.platform as "UBER_EATS" | "DOORDASH" | "GRUBHUB");
    try {
      await provider.updatePrice(record.menuItemId, Number(record.platformPrice));
      const updated = await prisma.platformProduct.update({
        where: { id: record.id },
        data: { syncStatus: "SYNCED", lastSyncedAt: new Date(), syncError: null }
      });
      await logAudit(session, {
        action: `Retried ${record.platform} sync — succeeded`,
        entityType: "PlatformProduct",
        entityId: record.id
      });
      return NextResponse.json({ platformProduct: updated });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown sync error";
      const updated = await prisma.platformProduct.update({
        where: { id: record.id },
        data: { syncStatus: "FAILED", syncError: message }
      });
      return NextResponse.json({ platformProduct: updated, error: message }, { status: 502 });
    }
  });
}
