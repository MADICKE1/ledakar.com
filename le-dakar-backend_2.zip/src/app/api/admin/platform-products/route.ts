import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { platformProductUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";
import { enqueue } from "@/lib/queue";

// Creates or updates one platform's price/availability for a dish. This
// writes to the internal database FIRST (the master menu is always the
// source of truth) and only then enqueues the external sync — a failure to
// sync with Uber Eats/DoorDash/Grubhub never rolls back the local price.
export async function POST(req: NextRequest) {
  return withPermission("pricing:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = platformProductUpsertSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    const { menuItemId, platform, ...data } = parsed.data;

    const record = await prisma.platformProduct.upsert({
      where: { menuItemId_platform: { menuItemId, platform } },
      update: { ...data, syncStatus: platform === "WEBSITE" ? "SYNCED" : "PENDING" },
      create: {
        menuItemId,
        platform,
        ...data,
        syncStatus: platform === "WEBSITE" ? "SYNCED" : "PENDING"
      }
    });

    const item = await prisma.menuItem.findUnique({ where: { id: menuItemId } });
    await logAudit(session, {
      action: `Set ${platform} price for "${item?.name ?? menuItemId}" to $${data.platformPrice.toFixed(2)}`,
      entityType: "PlatformProduct",
      entityId: record.id,
      newValue: { platform, platformPrice: data.platformPrice, enabled: data.enabled }
    });

    // Queues the sync to the external platform (no-op / MOCK when that
    // platform isn't connected — see src/lib/integrations/*). Runs inline
    // when REDIS_URL isn't set, or as a retryable BullMQ job when it is —
    // see src/lib/queue.ts and src/lib/jobs/menu-sync-worker.ts.
    if (platform !== "WEBSITE") {
      await enqueue("menu-sync", { platform, menuItemId, price: data.platformPrice });
    }

    return NextResponse.json({ platformProduct: record }, { status: 201 });
  });
}
