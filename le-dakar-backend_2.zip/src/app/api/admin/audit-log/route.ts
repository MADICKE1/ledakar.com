import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";

const PAGE_SIZE = 50;

// Read-only, paginated. Every mutating admin route already calls logAudit()
// (see src/lib/audit.ts) — this just surfaces those rows. No write path
// here: audit entries are never editable, and deletion isn't exposed
// either (a tamperable audit log defeats its own purpose).
export async function GET(req: NextRequest) {
  return withPermission("audit:view", async () => {
    const { searchParams } = new URL(req.url);
    const page = Math.max(1, Number(searchParams.get("page")) || 1);
    const entityType = searchParams.get("entityType") || undefined;
    const adminId = searchParams.get("adminId") || undefined;
    const q = searchParams.get("q")?.trim();

    const where = {
      ...(entityType ? { entityType } : {}),
      ...(adminId ? { adminId } : {}),
      ...(q ? { action: { contains: q, mode: "insensitive" as const } } : {})
    };

    const [entries, total, entityTypes, admins] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,
        include: { admin: { select: { id: true, name: true, role: true } } }
      }),
      prisma.auditLog.count({ where }),
      prisma.auditLog.findMany({ distinct: ["entityType"], select: { entityType: true }, orderBy: { entityType: "asc" } }),
      prisma.admin.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } })
    ]);

    return NextResponse.json({
      entries,
      total,
      page,
      pageSize: PAGE_SIZE,
      totalPages: Math.max(1, Math.ceil(total / PAGE_SIZE)),
      entityTypes: entityTypes.map((e: { entityType: string }) => e.entityType),
      admins
    });
  });
}
