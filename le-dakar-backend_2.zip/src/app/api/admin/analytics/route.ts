import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";

const RANGE_DAYS: Record<string, number> = { today: 1, "7d": 7, "30d": 30 };

// Minimal shapes for what this route actually reads off each row. Typed
// explicitly (rather than left to inference) because Prisma Client's
// generated types aren't available in this sandbox — see README /
// .env.example note on `prisma generate` — so query results would
// otherwise infer as `any` throughout. These match the real Order/
// OrderItem/Payment columns this route selects.
type OrderRow = { id: string; status: string; source: string; total: unknown; createdAt: Date };
type OrderWithItemsRow = OrderRow & {
  items: {
    menuItemId: string | null;
    nameSnapshot: string;
    priceSnapshot: unknown;
    quantity: number;
    menuItem: { category: { name: string } | null } | null;
  }[];
};
type PaymentRow = { status: string };

// All numbers here come straight from the database for the requested
// window — nothing hardcoded or simulated. "Today's Sales" and "Orders
// Today" are always literally today (midnight-to-now in server time),
// independent of the `range` selector, which drives every other card.
export async function GET(req: NextRequest) {
  return withPermission("analytics:view", async () => {
    const { searchParams } = new URL(req.url);
    const range = RANGE_DAYS[searchParams.get("range") || "today"] ? searchParams.get("range")! : "today";
    const days = RANGE_DAYS[range];

    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);

    const rangeStart = new Date();
    rangeStart.setHours(0, 0, 0, 0);
    rangeStart.setDate(rangeStart.getDate() - (days - 1));

    const [todayOrders, rangeOrders, rangePayments] = (await Promise.all([
      prisma.order.findMany({ where: { createdAt: { gte: startOfToday } } }),
      prisma.order.findMany({
        where: { createdAt: { gte: rangeStart } },
        include: { items: { include: { menuItem: { include: { category: true } } } } }
      }),
      prisma.payment.findMany({ where: { createdAt: { gte: rangeStart } } })
    ])) as [OrderRow[], OrderWithItemsRow[], PaymentRow[]];

    const isRevenue = (status: string) => status !== "PENDING" && status !== "CANCELLED";

    // --- Today ---------------------------------------------------------
    const todaysSales = todayOrders.filter((o) => isRevenue(o.status)).reduce((s, o) => s + Number(o.total), 0);
    const ordersTodayCount = todayOrders.length;

    // --- Range-based cards ----------------------------------------------
    const revenueOrders = rangeOrders.filter((o) => isRevenue(o.status));
    const totalRevenue = revenueOrders.reduce((s, o) => s + Number(o.total), 0);
    const aov = revenueOrders.length > 0 ? totalRevenue / revenueOrders.length : 0;

    const cancelledOrders = rangeOrders.filter((o) => o.status === "CANCELLED").length;
    const cancelledRate = rangeOrders.length > 0 ? cancelledOrders / rangeOrders.length : 0;

    const platforms = ["WEBSITE", "UBER_EATS", "DOORDASH", "GRUBHUB"] as const;
    const salesByPlatform = Object.fromEntries(
      platforms.map((p) => [p, revenueOrders.filter((o) => o.source === p).reduce((s, o) => s + Number(o.total), 0)])
    );
    const ordersByPlatform = Object.fromEntries(platforms.map((p) => [p, rangeOrders.filter((o) => o.source === p).length]));

    const ordersByHour = Array.from({ length: 24 }, (_, hour) => ({
      hour,
      count: rangeOrders.filter((o) => new Date(o.createdAt).getHours() === hour).length
    }));

    const itemTotals = new Map<string, { name: string; quantity: number; revenue: number }>();
    const categoryTotals = new Map<string, { name: string; revenue: number }>();
    for (const order of revenueOrders) {
      for (const item of order.items) {
        const key = item.menuItemId || item.nameSnapshot;
        const lineRevenue = Number(item.priceSnapshot) * item.quantity;
        const existing = itemTotals.get(key) || { name: item.nameSnapshot, quantity: 0, revenue: 0 };
        existing.quantity += item.quantity;
        existing.revenue += lineRevenue;
        itemTotals.set(key, existing);

        const categoryName = item.menuItem?.category?.name || "Uncategorized";
        const catExisting = categoryTotals.get(categoryName) || { name: categoryName, revenue: 0 };
        catExisting.revenue += lineRevenue;
        categoryTotals.set(categoryName, catExisting);
      }
    }
    const topSellingItems = Array.from(itemTotals.values())
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 8);
    const salesByCategory = Array.from(categoryTotals.values()).sort((a, b) => b.revenue - a.revenue);

    const completedPayments = rangePayments.filter((p) => p.status === "SUCCEEDED").length;
    const attemptedPayments = rangePayments.filter((p) => p.status !== "REQUIRES_PAYMENT" && p.status !== "PROCESSING").length;
    const paymentSuccessRate = attemptedPayments > 0 ? completedPayments / attemptedPayments : null;

    return NextResponse.json({
      range,
      todaysSales,
      ordersTodayCount,
      aov,
      totalRevenue,
      ordersCount: rangeOrders.length,
      cancelledOrders,
      cancelledRate,
      salesByPlatform,
      ordersByPlatform,
      ordersByHour,
      topSellingItems,
      salesByCategory,
      paymentSuccessRate,
      completedPayments,
      attemptedPayments
    });
  });
}
