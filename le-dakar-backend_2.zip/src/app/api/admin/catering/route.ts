import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const requests = await prisma.cateringRequest.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json({ requests });
}
