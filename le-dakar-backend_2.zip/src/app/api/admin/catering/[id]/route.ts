import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

const schema = z.object({
  status: z.enum(["NEW", "CONTACTED", "QUOTED", "BOOKED", "CLOSED"])
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("catering:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "A valid status is required." }, { status: 400 });
    }
    const before = await prisma.cateringRequest.findUnique({ where: { id: params.id } });
    const request_ = await prisma.cateringRequest.update({
      where: { id: params.id },
      data: { status: parsed.data.status }
    });

    await logAudit(session, {
      action: `Changed catering request status from ${before?.status ?? "?"} to ${parsed.data.status}`,
      entityType: "CateringRequest",
      entityId: request_.id,
      oldValue: { status: before?.status },
      newValue: { status: parsed.data.status }
    });

    return NextResponse.json({ request: request_ });
  });
}
