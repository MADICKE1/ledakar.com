import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { modifierUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = modifierUpsertSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input." }, { status: 400 });
    }
    const { id, ...data } = parsed.data;
    const modifier = await prisma.modifier.update({ where: { id: params.id }, data });
    await logAudit(session, { action: `Updated modifier "${modifier.name}"`, entityType: "Modifier", entityId: modifier.id });
    return NextResponse.json({ modifier });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("menu:manage", async (session) => {
    const modifier = await prisma.modifier.findUnique({ where: { id: params.id } });
    await prisma.modifier.delete({ where: { id: params.id } });
    if (modifier) {
      await logAudit(session, { action: `Deleted modifier "${modifier.name}"`, entityType: "Modifier", entityId: modifier.id });
    }
    return NextResponse.json({ ok: true });
  });
}
