import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { modifierUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = modifierUpsertSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    const { id, ...data } = parsed.data;
    const modifier = await prisma.modifier.create({ data });
    await logAudit(session, {
      action: `Added modifier "${modifier.name}" (+$${Number(modifier.priceDelta).toFixed(2)})`,
      entityType: "Modifier",
      entityId: modifier.id
    });
    return NextResponse.json({ modifier }, { status: 201 });
  });
}
