import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

const categorySchema = z.object({
  name: z.string().min(1).max(100),
  slug: z.string().min(1).max(100),
  description: z.string().max(300).optional().nullable(),
  sortOrder: z.number().int().optional()
});

export async function GET() {
  return withPermission("menu:view", async () => {
    const categories = await prisma.menuCategory.findMany({
      orderBy: { sortOrder: "asc" },
      include: { _count: { select: { items: true } } }
    });
    return NextResponse.json({ categories });
  });
}

// Creating/renaming/reordering a category is a structural menu change, not
// a description/image/featured-flag tweak — requires menu:manage, same bar
// as creating a dish. (MARKETING has menu:view but not menu:manage, so
// this deliberately excludes them even though the coarse middleware pass
// alone would have let menu:view through.)
export async function POST(req: NextRequest) {
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = categorySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    const category = await prisma.menuCategory.create({ data: parsed.data });

    await logAudit(session, {
      action: `Created category "${category.name}"`,
      entityType: "MenuCategory",
      entityId: category.id,
      newValue: { name: category.name, slug: category.slug }
    });

    return NextResponse.json({ category }, { status: 201 });
  });
}
