import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

const categorySchema = z.object({
  name: z.string().min(1).max(100).optional(),
  slug: z.string().min(1).max(100).optional(),
  description: z.string().max(300).optional().nullable(),
  sortOrder: z.number().int().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = categorySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input." }, { status: 400 });
    }
    const category = await prisma.menuCategory.update({ where: { id: params.id }, data: parsed.data });

    await logAudit(session, {
      action: `Updated category "${category.name}"`,
      entityType: "MenuCategory",
      entityId: category.id,
      newValue: parsed.data
    });

    return NextResponse.json({ category });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("menu:manage", async (session) => {
    const category = await prisma.menuCategory.findUnique({ where: { id: params.id } });
    await prisma.menuCategory.delete({ where: { id: params.id } });

    if (category) {
      await logAudit(session, {
        action: `Deleted category "${category.name}"`,
        entityType: "MenuCategory",
        entityId: category.id
      });
    }

    return NextResponse.json({ ok: true });
  });
}
