import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";
import { getProvider } from "@/lib/integrations/registry";
import { logAudit } from "@/lib/audit";
import type { SalesChannel } from "@prisma/client";

const VALID = new Set(["UBER_EATS", "DOORDASH", "GRUBHUB"]);

export async function POST(_req: NextRequest, { params }: { params: { platform: string } }) {
  return withPermission("integrations:manage", async (session) => {
    if (!VALID.has(params.platform)) {
      return NextResponse.json({ error: "Unknown platform." }, { status: 400 });
    }
    const platform = params.platform as "UBER_EATS" | "DOORDASH" | "GRUBHUB";

    const credential = await prisma.integrationCredential.findUnique({ where: { platform: platform as SalesChannel } });
    const envVarSet = credential?.clientSecretEnvVar ? !!process.env[credential.clientSecretEnvVar] : false;

    if (!envVarSet) {
      return NextResponse.json(
        {
          error: `${credential?.clientSecretEnvVar || `${platform}_CLIENT_SECRET`} is not set. Add real credentials to your environment first — see .env.example.`
        },
        { status: 400 }
      );
    }

    await prisma.integrationCredential.update({
      where: { platform: platform as SalesChannel },
      data: { connected: true, connectedAt: new Date() }
    });

    await getProvider(platform).connect();
    await logAudit(session, { action: `Connected ${platform} integration`, entityType: "IntegrationCredential" });

    return NextResponse.json({ connected: true });
  });
}
