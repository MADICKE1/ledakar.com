import { NextRequest, NextResponse } from "next/server";
import { withPermission } from "@/lib/rbac-guard";
import { getProvider } from "@/lib/integrations/registry";
import { logAudit } from "@/lib/audit";

const VALID = new Set(["UBER_EATS", "DOORDASH", "GRUBHUB"]);

export async function POST(_req: NextRequest, { params }: { params: { platform: string } }) {
  return withPermission("integrations:manage", async (session) => {
    if (!VALID.has(params.platform)) {
      return NextResponse.json({ error: "Unknown platform." }, { status: 400 });
    }
    const platform = params.platform as "UBER_EATS" | "DOORDASH" | "GRUBHUB";
    const result = await getProvider(platform).syncMenu();
    await logAudit(session, {
      action: `Synced full menu to ${platform} (${result.synced} items, ${result.failed} failed)`,
      entityType: "IntegrationCredential"
    });
    return NextResponse.json(result);
  });
}
