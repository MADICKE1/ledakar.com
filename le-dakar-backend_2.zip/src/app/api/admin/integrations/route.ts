import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";
import { SalesChannel } from "@prisma/client";

export async function GET() {
  return withPermission("integrations:manage", async () => {
    const platforms: Exclude<SalesChannel, "WEBSITE">[] = ["UBER_EATS", "DOORDASH", "GRUBHUB"];
    const [credentials, recentEvents] = await Promise.all([
      prisma.integrationCredential.findMany({ where: { platform: { in: platforms } } }),
      prisma.integrationEvent.findMany({ orderBy: { createdAt: "desc" }, take: 30 })
    ]);

    // Whether the env var each credential row points at is actually set —
    // lets the UI say "waiting on UBER_EATS_CLIENT_SECRET" precisely,
    // without ever exposing the secret's value.
    const withEnvStatus = credentials.map((c) => ({
      ...c,
      envVarIsSet: c.clientSecretEnvVar ? !!process.env[c.clientSecretEnvVar] : false
    }));

    return NextResponse.json({ credentials: withEnvStatus, recentEvents });
  });
}
