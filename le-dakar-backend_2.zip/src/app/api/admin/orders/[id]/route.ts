import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";
import { emitOrderEvent } from "@/lib/events";

const statusSchema = z.object({
  status: z.enum([
    "PENDING",
    "PAID",
    "CONFIRMED",
    "PREPARING",
    "READY",
    "OUT_FOR_DELIVERY",
    "COMPLETED",
    "CANCELLED"
  ])
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("orders:manage", async (session) => {
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Invalid JSON." }, { status: 400 });
    }

    const parsed = statusSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "A valid status is required." }, { status: 400 });
    }

    const before = await prisma.order.findUnique({ where: { id: params.id } });
    if (!before) {
      return NextResponse.json({ error: "Order not found." }, { status: 404 });
    }

    const order = await prisma.order.update({
      where: { id: params.id },
      data: { status: parsed.data.status }
    });

    await logAudit(session, {
      action: `Changed Order ${order.orderNumber} status from ${before.status} to ${order.status}`,
      entityType: "Order",
      entityId: order.id,
      oldValue: { status: before.status },
      newValue: { status: order.status }
    });

    emitOrderEvent({ type: "order.updated", orderId: order.id, status: order.status });

    return NextResponse.json({ order });
  });
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("orders:view", async () => {
    const order = await prisma.order.findUnique({
      where: { id: params.id },
      include: { items: { include: { modifiers: true } }, address: true, payments: true }
    });
    if (!order) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ order });
  });
}
