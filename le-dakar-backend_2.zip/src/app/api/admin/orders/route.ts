import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { OrderStatus, SalesChannel } from "@prisma/client";
import { withPermission } from "@/lib/rbac-guard";

export async function GET(req: NextRequest) {
  return withPermission("orders:view", async () => {
    const status = req.nextUrl.searchParams.get("status") as OrderStatus | null;
    const source = req.nextUrl.searchParams.get("source") as SalesChannel | null;

    const orders = await prisma.order.findMany({
      where: {
        ...(status ? { status } : {}),
        ...(source ? { source } : {})
      },
      orderBy: { createdAt: "desc" },
      include: { items: { include: { modifiers: true } }, address: true },
      take: 200
    });

    return NextResponse.json({ orders });
  });
}
