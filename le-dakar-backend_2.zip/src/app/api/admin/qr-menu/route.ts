import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";
import { SITE_URL } from "@/lib/constants";
import { qrMenuSettingsSchema } from "@/lib/validations";

async function getOrCreateSettings() {
  let settings = await prisma.qRMenuSettings.findFirst();
  if (!settings) {
    settings = await prisma.qRMenuSettings.create({ data: { slug: "menu" } });
  }
  return settings;
}

export async function GET() {
  return withPermission("menu:view", async () => {
    const settings = await getOrCreateSettings();
    // The QR always points at the site's existing, permanent /menu page —
    // scanning it never needs to change when dishes, prices, images, or
    // availability change, since that page reads live from the database.
    // `settings.slug` is stored for future multi-location support but
    // isn't wired to routing yet, so we don't build the URL from it.
    return NextResponse.json({ settings, menuUrl: `${SITE_URL}/menu` });
  });
}

export async function PATCH(req: NextRequest) {
  return withPermission("settings:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = qrMenuSettingsSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }

    const existing = await getOrCreateSettings();
    const settings = await prisma.qRMenuSettings.update({ where: { id: existing.id }, data: parsed.data });

    await logAudit(session, {
      action: "Updated QR menu display settings",
      entityType: "QRMenuSettings",
      entityId: settings.id,
      newValue: parsed.data
    });

    return NextResponse.json({ settings });
  });
}
