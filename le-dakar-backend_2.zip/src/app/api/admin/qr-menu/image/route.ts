import { NextRequest, NextResponse } from "next/server";
import QRCode from "qrcode";
import { withPermission } from "@/lib/rbac-guard";
import { SITE_URL } from "@/lib/constants";

export const runtime = "nodejs";

// Generates the QR code image on demand — nothing to regenerate or keep in
// sync when the menu changes, since the code just encodes the permanent
// /menu URL and that page always reads the current database. Query params
// let the print-ready download differ from the on-screen preview without
// two code paths.
export async function GET(req: NextRequest) {
  return withPermission("menu:view", async () => {
    const { searchParams } = new URL(req.url);
    const size = Math.min(Math.max(Number(searchParams.get("size")) || 512, 128), 2048);
    const download = searchParams.get("download") === "1";
    const format = searchParams.get("format") === "svg" ? "svg" : "png";
    const targetUrl = `${SITE_URL}/menu`;

    if (format === "svg") {
      const svg = await QRCode.toString(targetUrl, { type: "svg", margin: 1, width: size, color: { dark: "#2E1B12", light: "#FBF3E7" } });
      return new NextResponse(svg, {
        headers: {
          "Content-Type": "image/svg+xml",
          ...(download ? { "Content-Disposition": 'attachment; filename="le-dakar-menu-qr.svg"' } : {})
        }
      });
    }

    const png = await QRCode.toBuffer(targetUrl, {
      type: "png",
      margin: 1,
      width: size,
      color: { dark: "#2E1B12", light: "#FBF3E7" }
    });

    return new NextResponse(new Uint8Array(png), {
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "public, max-age=3600",
        ...(download ? { "Content-Disposition": 'attachment; filename="le-dakar-menu-qr.png"' } : {})
      }
    });
  });
}
