import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { kitchenActionSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";
import { emitOrderEvent } from "@/lib/events";
import type { OrderStatus } from "@prisma/client";

const ACTION_TO_STATUS: Record<"START" | "READY" | "COMPLETE", OrderStatus> = {
  START: "PREPARING",
  READY: "READY",
  COMPLETE: "COMPLETED"
};

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("kitchen:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = kitchenActionSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "A valid action (START/READY/COMPLETE) is required." }, { status: 400 });
    }

    const nextStatus = ACTION_TO_STATUS[parsed.data.action];
    const order = await prisma.order.update({
      where: { id: params.id },
      data: { status: nextStatus }
    });

    await logAudit(session, {
      action: `Kitchen marked Order ${order.orderNumber} as ${nextStatus}`,
      entityType: "Order",
      entityId: order.id,
      newValue: { status: nextStatus }
    });

    emitOrderEvent({ type: "order.updated", orderId: order.id, status: order.status });

    return NextResponse.json({ order });
  });
}
