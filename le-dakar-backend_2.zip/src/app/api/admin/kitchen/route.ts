import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";

// Orders the kitchen actually needs to see: paid and in the cooking
// pipeline. PENDING (unpaid) and terminal states are excluded on purpose.
const KITCHEN_STATUSES = ["PAID", "CONFIRMED", "PREPARING", "READY"] as const;

export async function GET() {
  return withPermission("kitchen:view", async () => {
    const orders = await prisma.order.findMany({
      where: { status: { in: [...KITCHEN_STATUSES] } },
      orderBy: { createdAt: "asc" }, // oldest first — first in, first cooked
      include: { items: { include: { modifiers: true } } }
    });
    return NextResponse.json({ orders });
  });
}
