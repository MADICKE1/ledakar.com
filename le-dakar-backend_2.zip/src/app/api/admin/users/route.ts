import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { adminUserUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

// Staff account management is OWNER-only (see ROLE_PERMISSIONS — only OWNER
// has "users:manage"). A manager who could create OWNER accounts would be a
// privilege-escalation hole, so this is deliberately not delegable.

export async function GET() {
  return withPermission("users:manage", async () => {
    const admins = await prisma.admin.findMany({
      select: { id: true, email: true, name: true, role: true, active: true, createdAt: true },
      orderBy: { createdAt: "asc" }
    });
    return NextResponse.json({ admins });
  });
}

export async function POST(req: NextRequest) {
  return withPermission("users:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = adminUserUpsertSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    if (!parsed.data.password) {
      return NextResponse.json({ error: "A password is required to create a staff account." }, { status: 400 });
    }

    const existing = await prisma.admin.findUnique({ where: { email: parsed.data.email } });
    if (existing) {
      return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(parsed.data.password, 10);
    const admin = await prisma.admin.create({
      data: {
        email: parsed.data.email,
        name: parsed.data.name,
        role: parsed.data.role,
        passwordHash,
        active: parsed.data.active ?? true
      },
      select: { id: true, email: true, name: true, role: true, active: true, createdAt: true }
    });

    await logAudit(session, {
      action: `Created staff account "${admin.name}" (${admin.email}) with role ${admin.role}`,
      entityType: "Admin",
      entityId: admin.id,
      newValue: { email: admin.email, role: admin.role }
    });

    return NextResponse.json({ admin }, { status: 201 });
  });
}
