import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { adminUserUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("users:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = adminUserUpsertSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input." }, { status: 400 });
    }

    // A lone OWNER can't demote or deactivate themselves out of the account
    // — that would permanently lock everyone out of Settings/Staff.
    if (session.adminId === params.id && (parsed.data.role || parsed.data.active === false)) {
      const ownerCount = await prisma.admin.count({ where: { role: "OWNER", active: true } });
      if (ownerCount <= 1 && (parsed.data.role !== "OWNER" || parsed.data.active === false)) {
        return NextResponse.json(
          { error: "You are the only active owner — promote another owner before changing this." },
          { status: 409 }
        );
      }
    }

    const { password, ...rest } = parsed.data;
    const data: Record<string, unknown> = { ...rest };
    if (password) {
      data.passwordHash = await bcrypt.hash(password, 10);
    }

    const before = await prisma.admin.findUnique({ where: { id: params.id } });
    const admin = await prisma.admin.update({
      where: { id: params.id },
      data,
      select: { id: true, email: true, name: true, role: true, active: true, createdAt: true }
    });

    if (before && rest.role && before.role !== rest.role) {
      await logAudit(session, {
        action: `Changed ${admin.name}'s role from ${before.role} to ${admin.role}`,
        entityType: "Admin",
        entityId: admin.id,
        oldValue: { role: before.role },
        newValue: { role: admin.role }
      });
    }
    if (before && rest.active !== undefined && before.active !== rest.active) {
      await logAudit(session, {
        action: `${rest.active ? "Reactivated" : "Deactivated"} staff account ${admin.name}`,
        entityType: "Admin",
        entityId: admin.id
      });
    }

    return NextResponse.json({ admin });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("users:manage", async (session) => {
    if (session.adminId === params.id) {
      return NextResponse.json({ error: "You can't delete your own account." }, { status: 400 });
    }
    const admin = await prisma.admin.findUnique({ where: { id: params.id } });
    await prisma.admin.delete({ where: { id: params.id } });

    if (admin) {
      await logAudit(session, {
        action: `Removed staff account ${admin.name} (${admin.email})`,
        entityType: "Admin",
        entityId: admin.id
      });
    }
    return NextResponse.json({ ok: true });
  });
}
