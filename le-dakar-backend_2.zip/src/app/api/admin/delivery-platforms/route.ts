import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { deliveryPlatformSchema } from "@/lib/validations";
import { getDeliveryPlatforms } from "@/lib/settings";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function GET() {
  return withPermission("settings:manage", async () => {
    const platforms = await getDeliveryPlatforms();
    return NextResponse.json({ platforms });
  });
}

export async function PATCH(req: NextRequest) {
  return withPermission("settings:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = deliveryPlatformSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }

    const platform = await prisma.deliveryPlatform.upsert({
      where: { name: parsed.data.name },
      update: { url: parsed.data.url, enabled: parsed.data.enabled },
      create: { name: parsed.data.name, url: parsed.data.url, enabled: parsed.data.enabled }
    });

    await logAudit(session, {
      action: `Updated ${parsed.data.name} delivery link (${parsed.data.enabled ? "shown" : "hidden"} publicly)`,
      entityType: "DeliveryPlatform",
      entityId: platform.id
    });

    return NextResponse.json({ platform });
  });
}
