import { NextResponse } from "next/server";
import { getAdminSession } from "@/lib/auth";
import { permissionsForRole } from "@/lib/rbac";
import type { AdminRole } from "@prisma/client";

export async function GET() {
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return NextResponse.json({
    adminId: session.adminId,
    email: session.email,
    role: session.role,
    permissions: permissionsForRole(session.role as AdminRole)
  });
}
