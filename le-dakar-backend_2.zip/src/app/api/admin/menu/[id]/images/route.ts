import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { galleryImageSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

// Attaches an already-uploaded image (see /api/admin/images/upload) to a
// menu item's gallery. Kept separate from the upload step so the same
// uploaded file can be pointed at the primary imageUrl OR added here — the
// upload and "what it's used for" are different concerns.
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("images:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = galleryImageSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }

    const item = await prisma.menuItem.findUnique({ where: { id: params.id } });
    if (!item) {
      return NextResponse.json({ error: "Menu item not found." }, { status: 404 });
    }

    const count = await prisma.productImage.count({ where: { menuItemId: params.id } });
    const image = await prisma.productImage.create({
      data: { ...parsed.data, menuItemId: params.id, sortOrder: count }
    });

    await logAudit(session, {
      action: `Added a gallery image to "${item.name}"`,
      entityType: "ProductImage",
      entityId: image.id,
      newValue: { url: image.url }
    });

    return NextResponse.json({ image }, { status: 201 });
  });
}
