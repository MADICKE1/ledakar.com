import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";
import { deleteImage } from "@/lib/images";

export const runtime = "nodejs"; // deleteImage may touch the local filesystem or call the Cloudinary SDK

export async function DELETE(_req: NextRequest, { params }: { params: { id: string; imageId: string } }) {
  return withPermission("images:manage", async (session) => {
    const image = await prisma.productImage.findUnique({ where: { id: params.imageId } });
    if (!image || image.menuItemId !== params.id) {
      return NextResponse.json({ error: "Image not found." }, { status: 404 });
    }

    await prisma.productImage.delete({ where: { id: params.imageId } });
    await deleteImage(image);

    const item = await prisma.menuItem.findUnique({ where: { id: params.id } });
    await logAudit(session, {
      action: `Removed a gallery image from "${item?.name ?? params.id}"`,
      entityType: "ProductImage",
      entityId: params.imageId
    });

    return NextResponse.json({ ok: true });
  });
}
