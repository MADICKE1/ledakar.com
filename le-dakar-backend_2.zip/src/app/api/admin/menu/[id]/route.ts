import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { menuItemUpsertSchema } from "@/lib/validations";
import { getAdminSession } from "@/lib/auth";
import { hasPermission, type Permission } from "@/lib/rbac";
import { logAudit, describeChange } from "@/lib/audit";

/**
 * Field-level RBAC: a PATCH to a menu item can touch several different
 * permission domains at once (price, availability, description, image,
 * featured flag, category/structure). Every field present in the request
 * body must be something this role is allowed to change, or the whole
 * request is rejected — partial application of a partially-authorized edit
 * would be more confusing than just rejecting it outright.
 */
function permissionsRequiredFor(fields: string[]): Permission[] {
  const required = new Set<Permission>();
  for (const field of fields) {
    if (field === "price") required.add("pricing:manage");
    else if (field === "status") required.add("availability:manage");
    else if (field === "imageUrl") required.add("images:manage");
    else if (field === "description" || field === "allergenNote" || field === "allergens" || field === "ingredients" || field === "dietaryTags")
      required.add("descriptions:manage");
    else if (field === "isFeatured") required.add("featured:manage");
    else required.add("menu:manage"); // name, slug, categoryId, sortOrder, preparationTimeMins, ...
  }
  return Array.from(required);
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = menuItemUpsertSchema.partial().safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input." }, { status: 400 });
  }
  const { id, ...data } = parsed.data;

  const needed = permissionsRequiredFor(Object.keys(data));
  const missing = needed.filter((p) => !hasPermission(session.role as never, p));
  if (missing.length > 0) {
    return NextResponse.json(
      { error: `Forbidden — your role cannot change: ${missing.join(", ")}` },
      { status: 403 }
    );
  }

  const before = await prisma.menuItem.findUnique({ where: { id: params.id } });
  if (!before) {
    return NextResponse.json({ error: "Menu item not found." }, { status: 404 });
  }

  const item = await prisma.menuItem.update({ where: { id: params.id }, data });

  // One readable audit line per meaningfully-changed field.
  if (data.price !== undefined && Number(before.price) !== data.price) {
    await logAudit(session, {
      action: describeChange(`"${item.name}"`, "price", Number(before.price), data.price),
      entityType: "MenuItem",
      entityId: item.id,
      oldValue: { price: Number(before.price) },
      newValue: { price: data.price }
    });
  }
  if (data.status !== undefined && before.status !== data.status) {
    await logAudit(session, {
      action: `Changed "${item.name}" availability from ${before.status} to ${data.status}`,
      entityType: "MenuItem",
      entityId: item.id,
      oldValue: { status: before.status },
      newValue: { status: data.status }
    });
  }
  if (data.imageUrl !== undefined && before.imageUrl !== data.imageUrl) {
    await logAudit(session, {
      action: `Changed "${item.name}" image`,
      entityType: "MenuItem",
      entityId: item.id,
      oldValue: { imageUrl: before.imageUrl },
      newValue: { imageUrl: data.imageUrl }
    });
  }

  return NextResponse.json({ item });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getAdminSession();
  if (!session || !hasPermission(session.role as never, "menu:manage")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const item = await prisma.menuItem.findUnique({ where: { id: params.id } });
  await prisma.menuItem.delete({ where: { id: params.id } });

  if (item) {
    await logAudit(session, {
      action: `Deleted menu item "${item.name}"`,
      entityType: "MenuItem",
      entityId: item.id,
      oldValue: { name: item.name, price: Number(item.price) }
    });
  }

  return NextResponse.json({ ok: true });
}
