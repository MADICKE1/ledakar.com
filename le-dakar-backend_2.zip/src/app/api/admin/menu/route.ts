import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { menuItemUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function GET() {
  return withPermission("menu:view", async () => {
    const items = await prisma.menuItem.findMany({
      orderBy: [{ categoryId: "asc" }, { sortOrder: "asc" }],
      include: {
        category: true,
        images: { orderBy: { sortOrder: "asc" } },
        modifierGroups: { include: { modifiers: true }, orderBy: { sortOrder: "asc" } },
        platformProducts: true
      }
    });
    return NextResponse.json({ items });
  });
}

function slugify(name: string) {
  return name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export async function POST(req: NextRequest) {
  // Creating a new dish is a full menu-management action, not something
  // MARKETING (descriptions/images/featured only) can do on its own.
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = menuItemUpsertSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    const { id, slug, ...data } = parsed.data;

    let finalSlug = slug || slugify(data.name);
    let suffix = 2;
    while (await prisma.menuItem.findUnique({ where: { slug: finalSlug } })) {
      finalSlug = `${slug || slugify(data.name)}-${suffix++}`;
    }

    const item = await prisma.menuItem.create({
      data: {
        ...data,
        slug: finalSlug,
        isFeatured: data.isFeatured ?? false,
        sortOrder: data.sortOrder ?? 0
      }
    });

    await logAudit(session, {
      action: `Created menu item "${item.name}" ($${Number(item.price).toFixed(2)})`,
      entityType: "MenuItem",
      entityId: item.id,
      newValue: { name: item.name, price: Number(item.price), categoryId: item.categoryId }
    });

    return NextResponse.json({ item }, { status: 201 });
  });
}
