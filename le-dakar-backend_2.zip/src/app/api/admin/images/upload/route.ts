import { NextRequest, NextResponse } from "next/server";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";
import { ImageValidationError, isCloudinaryConfigured, uploadImage } from "@/lib/images";
import { rateLimit, clientIp } from "@/lib/rate-limit";

export const runtime = "nodejs";

const ALLOWED_FOLDERS = new Set(["menu", "gallery", "logo"]);

// Generic image upload used by the menu-item image field and the gallery.
// Cloudinary when CLOUDINARY_* env vars are set (see src/lib/images.ts),
// local public/uploads/ otherwise. Never invents credentials — it just
// checks whether the real ones are configured and picks the code path.
export async function POST(req: NextRequest) {
  return withPermission("images:manage", async (session) => {
    const limit = rateLimit(`image-upload:${clientIp(req)}`, 20, 60_000);
    if (!limit.ok) {
      return NextResponse.json(
        { error: "Too many uploads — please wait a moment and try again." },
        { status: 429, headers: { "Retry-After": String(Math.ceil(limit.retryAfterMs / 1000)) } }
      );
    }

    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    const folderInput = (form?.get("folder") as string | null) || "menu";
    const folder = ALLOWED_FOLDERS.has(folderInput) ? folderInput : "menu";

    if (!file || typeof file === "string") {
      return NextResponse.json({ error: "No file provided." }, { status: 400 });
    }

    try {
      const buffer = Buffer.from(await file.arrayBuffer());
      const uploaded = await uploadImage(buffer, {
        filename: file.name || "upload",
        mimeType: file.type || "application/octet-stream",
        folder
      });

      await logAudit(session, {
        action: `Uploaded an image (${uploaded.provider}${uploaded.provider === "local" ? " — dev fallback, not durable in production" : ""})`,
        entityType: "ProductImage",
        newValue: { url: uploaded.url, provider: uploaded.provider }
      });

      return NextResponse.json({
        ...uploaded,
        cloudinaryConfigured: isCloudinaryConfigured()
      });
    } catch (err) {
      if (err instanceof ImageValidationError) {
        return NextResponse.json({ error: err.message }, { status: 422 });
      }
      const message = err instanceof Error ? err.message : "Upload failed.";
      return NextResponse.json({ error: message }, { status: 500 });
    }
  });
}
