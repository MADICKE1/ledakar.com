import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { couponUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("coupons:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = couponUpsertSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input." }, { status: 400 });
    }
    const { id, expiresAt, ...data } = parsed.data;
    const coupon = await prisma.coupon.update({
      where: { id: params.id },
      data: {
        ...data,
        ...(data.code ? { code: data.code.toUpperCase() } : {}),
        ...(expiresAt !== undefined ? { expiresAt: expiresAt ? new Date(expiresAt) : null } : {})
      }
    });

    await logAudit(session, {
      action: `Updated coupon "${coupon.code}"`,
      entityType: "Coupon",
      entityId: coupon.id,
      newValue: data
    });

    return NextResponse.json({ coupon });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("coupons:manage", async (session) => {
    const coupon = await prisma.coupon.findUnique({ where: { id: params.id } });
    await prisma.coupon.delete({ where: { id: params.id } });

    if (coupon) {
      await logAudit(session, {
        action: `Deleted coupon "${coupon.code}"`,
        entityType: "Coupon",
        entityId: coupon.id
      });
    }

    return NextResponse.json({ ok: true });
  });
}
