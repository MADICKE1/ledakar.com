import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { couponUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function GET() {
  return withPermission("coupons:manage", async () => {
    const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: "desc" } });
    return NextResponse.json({ coupons });
  });
}

export async function POST(req: NextRequest) {
  return withPermission("coupons:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = couponUpsertSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    const { id, expiresAt, ...data } = parsed.data;
    try {
      const coupon = await prisma.coupon.create({
        data: {
          ...data,
          code: data.code.toUpperCase(),
          minOrderAmount: data.minOrderAmount ?? 0,
          expiresAt: expiresAt ? new Date(expiresAt) : null
        }
      });

      await logAudit(session, {
        action: `Created coupon "${coupon.code}"`,
        entityType: "Coupon",
        entityId: coupon.id,
        newValue: { code: coupon.code }
      });

      return NextResponse.json({ coupon }, { status: 201 });
    } catch (err: any) {
      if (err?.code === "P2002") {
        return NextResponse.json({ error: "A coupon with this code already exists." }, { status: 409 });
      }
      throw err;
    }
  });
}
