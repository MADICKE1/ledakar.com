import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { modifierGroupUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = modifierGroupUpsertSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }
    const { id, ...data } = parsed.data;
    const group = await prisma.modifierGroup.create({ data });

    const item = await prisma.menuItem.findUnique({ where: { id: data.menuItemId } });
    await logAudit(session, {
      action: `Added modifier group "${group.name}" to "${item?.name ?? data.menuItemId}"`,
      entityType: "ModifierGroup",
      entityId: group.id
    });

    return NextResponse.json({ group }, { status: 201 });
  });
}
