import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { modifierGroupUpsertSchema } from "@/lib/validations";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("menu:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = modifierGroupUpsertSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input." }, { status: 400 });
    }
    const { id, ...data } = parsed.data;
    const group = await prisma.modifierGroup.update({ where: { id: params.id }, data });
    await logAudit(session, {
      action: `Updated modifier group "${group.name}"`,
      entityType: "ModifierGroup",
      entityId: group.id
    });
    return NextResponse.json({ group });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return withPermission("menu:manage", async (session) => {
    const group = await prisma.modifierGroup.findUnique({ where: { id: params.id } });
    await prisma.modifierGroup.delete({ where: { id: params.id } });
    if (group) {
      await logAudit(session, {
        action: `Deleted modifier group "${group.name}"`,
        entityType: "ModifierGroup",
        entityId: group.id
      });
    }
    return NextResponse.json({ ok: true });
  });
}
