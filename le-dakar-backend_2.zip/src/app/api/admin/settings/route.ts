import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { restaurantSettingsSchema } from "@/lib/validations";
import { getRestaurantSettings } from "@/lib/settings";
import { withPermission } from "@/lib/rbac-guard";
import { logAudit } from "@/lib/audit";

export async function GET() {
  return withPermission("settings:manage", async () => {
    const settings = await getRestaurantSettings();
    return NextResponse.json({ settings });
  });
}

export async function PATCH(req: NextRequest) {
  return withPermission("settings:manage", async (session) => {
    const body = await req.json().catch(() => null);
    const parsed = restaurantSettingsSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    }

    const existing = await getRestaurantSettings();
    const settings = await prisma.restaurantSettings.update({
      where: { id: existing.id },
      data: parsed.data
    });

    await logAudit(session, {
      action: "Updated restaurant settings",
      entityType: "RestaurantSettings",
      entityId: settings.id,
      newValue: parsed.data
    });

    return NextResponse.json({ settings });
  });
}
