import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { sendOrderConfirmationEmail } from "@/lib/email";
import { emitOrderEvent } from "@/lib/events";

// Stripe webhooks must see the raw request body to verify the signature, so
// this route must NOT run through any JSON body-parsing middleware.
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const signature = req.headers.get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    return NextResponse.json({ error: "Webhook not configured." }, { status: 400 });
  }

  const rawBody = await req.text();

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    console.error("[stripe webhook] signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  // Idempotency ledger, shared with the delivery-platform webhooks (see
  // src/app/api/webhooks/{uber-eats,doordash,grubhub}/route.ts). Stripe can
  // and does redeliver the same event; the unique (source, externalId)
  // constraint makes a second delivery a safe no-op instead of double-
  // fulfilling an order or double-incrementing a coupon's usedCount.
  try {
    await prisma.webhookEvent.create({
      data: { source: "stripe", externalId: event.id, eventType: event.type }
    });
  } catch {
    // Unique constraint violation = we've already processed this event id.
    return NextResponse.json({ received: true, duplicate: true });
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      const orderId = session.metadata?.orderId;
      if (!orderId) break;

      const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: { items: true }
      });
      if (!order) break;

      // Only fulfill once — webhooks can be retried/duplicated by Stripe.
      if (order.status === "PENDING") {
        await prisma.$transaction([
          prisma.order.update({ where: { id: orderId }, data: { status: "CONFIRMED" } }),
          prisma.payment.updateMany({
            where: { orderId, stripeCheckoutSessionId: session.id },
            data: {
              status: "SUCCEEDED",
              stripePaymentIntentId:
                typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id
            }
          }),
          ...(order.couponCode
            ? [
                prisma.coupon.update({
                  where: { code: order.couponCode },
                  data: { usedCount: { increment: 1 } }
                })
              ]
            : [])
        ]);

        await sendOrderConfirmationEmail({
          to: order.email,
          orderNumber: order.orderNumber,
          customerName: order.firstName,
          items: order.items.map((i: (typeof order.items)[number]) => ({
            name: i.nameSnapshot,
            quantity: i.quantity,
            price: Number(i.priceSnapshot)
          })),
          total: Number(order.total),
          type: order.type
        });

        emitOrderEvent({ type: "order.updated", orderId: order.id, status: "CONFIRMED" });
      }
      break;
    }

    case "checkout.session.expired": {
      const session = event.data.object as Stripe.Checkout.Session;
      const orderId = session.metadata?.orderId;
      if (orderId) {
        await prisma.order
          .updateMany({ where: { id: orderId, status: "PENDING" }, data: { status: "CANCELLED" } })
          .catch(() => {});
      }
      break;
    }

    case "payment_intent.payment_failed": {
      const intent = event.data.object as Stripe.PaymentIntent;
      await prisma.payment
        .updateMany({
          where: { stripePaymentIntentId: intent.id },
          data: { status: "FAILED" }
        })
        .catch(() => {});
      break;
    }

    default:
      break;
  }

  return NextResponse.json({ received: true });
}
