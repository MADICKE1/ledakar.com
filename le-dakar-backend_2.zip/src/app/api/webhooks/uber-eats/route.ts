import { NextRequest } from "next/server";
import { handleDeliveryWebhook } from "@/lib/integrations/handle-webhook";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  return handleDeliveryWebhook(req, "UBER_EATS");
}
