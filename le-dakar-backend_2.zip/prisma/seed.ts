/**
 * Seed script for LE DAKAR.
 *
 * Menu categories and items are transcribed directly from the restaurant's
 * printed menu photo. Prices are taken verbatim where legible. A small
 * number of items on the source menu did not show a clear, unambiguous
 * price (mostly individual à la carte side items and two appetizer
 * eggrolls) — those are seeded with `priceUnclear: true` and a price of
 * 0.00 so nothing is invented; the admin dashboard lets the owner fill in
 * the real price before the item is shown as orderable.
 */
import { PrismaClient, MenuItemStatus, DeliveryPlatformName, SalesChannel } from "@prisma/client";
import bcrypt from "bcryptjs";
import crypto from "crypto";

const prisma = new PrismaClient();

function slugify(name: string) {
  return name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "") // strip accents (Bouyé -> bouye, etc.)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

type SeedItem = {
  name: string;
  description?: string;
  price: number;
  priceUnclear?: boolean;
  isFeatured?: boolean;
};

type SeedCategory = {
  name: string;
  slug: string;
  description?: string;
  items: SeedItem[];
};

const MENU: SeedCategory[] = [
  {
    name: "Breakfast",
    slug: "breakfast",
    items: [
      { name: "Chawarma Beef", price: 12 },
      { name: "Chawarma Chicken", price: 12 },
      { name: "Taccos Chicken", price: 13 },
      { name: "Taccos Beef", price: 13 }
    ]
  },
  {
    name: "Lunch",
    slug: "lunch",
    description: "Exotic rice and lamb dishes served with white rice",
    items: [
      { name: "Thiebou Djeun", description: "Exotic red fish and Djolof rice, with eggplant, cabbage and carrots", price: 20, isFeatured: true },
      { name: "Thiebou Yapp", description: "Lamb and exotic Jolof rice with eggs, vegetables and onion sauce on the side", price: 20, isFeatured: true },
      { name: "Suppu Kandja", description: "Okra sauce, fish stew with okra palm oil served with white rice", price: 20 },
      { name: "Thiou Poisson", description: "Fish stewed in a rich tomato sauce with vegetables and onions, served with white rice", price: 20 },
      { name: "Lamb Maffe", description: "Peanut butter stew — lamb marinated and cooked in a creamy rich peanut butter sauce, served with white rice", price: 20, isFeatured: true },
      { name: "Thiebou Kethiokhe", description: "Rice and fish or dry fish and beans in a rich tomato sauce", price: 20 },
      { name: "Thiebou Gimar", description: "Chicken with exotic Jolof rice, onion sauce on the side", price: 20 },
      { name: "Sulukhu", price: 20 },
      { name: "Chicken Yassa", description: "Chicken marinated in lemon and onion sauce, served with white rice", price: 20, isFeatured: true },
      { name: "Domada Yapp", description: "Lamb stewed in a tomato and vegetable sauce, served with white rice", price: 20 },
      { name: "Mbakhale", description: "Lamb, rice, stewed with onion sauce", price: 20 },
      { name: "Dakhine", price: 20 },
      { name: "Cebon", description: "Mix with seafood — fish cooked with rice and served with white rice", price: 25 }
    ]
  },
  {
    name: "Special Dinner",
    slug: "special-dinner",
    items: [
      { name: "Red Snapper", price: 35 },
      { name: "Red Snapper (Fore)", description: "Oven-grilled snapper, served with 1 side order", price: 30 },
      { name: "Poulet Pane", price: 30 },
      { name: "Poulet Coco", price: 30 },
      { name: "Mechoui", description: "Braised lamb shank, very tender, served with 1 side order", price: 45 }
    ]
  },
  {
    name: "Appetizers",
    slug: "appetizers",
    items: [
      { name: "4 Pcs Nems", price: 12 },
      { name: "4 Pcs Fatayat", price: 12 },
      { name: "Eggroll Stuffed w/ Meat, Shrimp & Vegetable", price: 0, priceUnclear: true },
      { name: "Eggroll Stuffed w/ Meat & Vegetable", price: 0, priceUnclear: true }
    ]
  },
  {
    name: "Dinner Entrées",
    slug: "dinner-entrees",
    items: [
      { name: "Soup (Small)", description: "Mixed lamb, oxtail, cow feet with potatoes and carrots", price: 23 },
      { name: "Soup (Large)", description: "Mixed lamb, oxtail, cow feet with potatoes and carrots", price: 25 },
      { name: "Debe Senegal (Nostalgie)", description: "Grilled griddle lamb chops, served with 1 side order", price: 23 },
      { name: "Macaroni", description: "Stew, lamb, potato and onions", price: 23 },
      { name: "Rice", description: "Stew, lamb, potato and onions", price: 23 },
      { name: "Beans Lamb Stew", description: "Stew, lamb, potato, tomato sauce and onions", price: 23 },
      { name: "Debe Guinar", description: "Grilled chicken, served with 1 side order", price: 23 },
      { name: "Mechoui (Entrée)", price: 23 },
      { name: "Brochette Poulet", description: "Chicken kebab, served with 1 side order", price: 23 },
      { name: "Grill Pintade", description: "Grilled guinea fowl, served with 1 side order", price: 23 },
      { name: "Half Grill Chicken", description: "Grilled chicken, served with 1 side order", price: 23, isFeatured: true },
      { name: "Fried Fish (Poisson Frite)", description: "Fried fish served with onion sauce, salad, 1 side order", price: 25, isFeatured: true },
      { name: "Grilled Fish (Poisson Braisé)", description: "Grilled fish served with onion sauce, salad, 1 side order", price: 25, isFeatured: true },
      { name: "Petit Poids", description: "Green beans stew, meat, green peas and bread", price: 23 },
      { name: "Thieray", description: "Senegalese couscous — steamed local couscous with marinated lamb, vegetables and a creamy peanut or tomato sauce", price: 23 }
    ]
  },
  {
    name: "Fast Food",
    slug: "fast-food",
    items: [
      { name: "Shawarma", description: "Beef or chicken sandwich with pita bread", price: 12 },
      { name: "Taccos", description: "Chicken or beef", price: 13 }
    ]
  },
  {
    name: "Desserts",
    slug: "desserts",
    items: [
      { name: "Ngualakh", description: "Fine couscous mixed with peanut butter and pure vanilla", price: 5 },
      { name: "Thiakry", description: "Fine couscous with sour cream and pure vanilla", price: 5 }
    ]
  },
  {
    name: "Beverages",
    slug: "beverages",
    items: [
      { name: "Bouyé", description: "Baobab fruit juice", price: 5 },
      { name: "Bissap Juice", description: "Sorrel (hibiscus) juice", price: 5 },
      { name: "Fruit Cocktail", price: 5 },
      { name: "Tamarind Juice", price: 5 },
      { name: "Ginger Juice", price: 5 },
      { name: "Soda", price: 2 },
      { name: "Spring Water", price: 1 }
    ]
  },
  {
    name: "Side Orders",
    slug: "side-orders",
    items: [
      { name: "French Fries", price: 0, priceUnclear: true },
      { name: "Alloco", price: 0, priceUnclear: true },
      { name: "Couscous (Side)", price: 0, priceUnclear: true },
      { name: "Vermicelli", price: 0, priceUnclear: true },
      { name: "White Rice", price: 0, priceUnclear: true },
      { name: "Salad", price: 0, priceUnclear: true },
      { name: "Potato Salad", price: 0, priceUnclear: true },
      { name: "Djolof Rice", price: 7 },
      { name: "Attiéké", price: 5 }
    ]
  }
];

async function main() {
  console.log("Seeding LE DAKAR database...");

  // --- Restaurant settings (singleton) -------------------------------------
  // Address & phone are transcribed directly from the menu photo. Hours,
  // delivery-platform links, social links, and review link are intentionally
  // left blank — the brief requires we never invent these. The owner fills
  // them in from /admin/settings.
  const existingSettings = await prisma.restaurantSettings.findFirst();
  if (!existingSettings) {
    await prisma.restaurantSettings.create({
      data: {
        name: "LE DAKAR",
        tagline: "Authentic Senegalese & African Cuisine in New York",
        addressLine1: "2778 3rd Avenue",
        city: "Bronx",
        state: "NY",
        zip: "10455",
        phone: "347-431-3400",
        email: null,
        hours: null,
        pickupEnabled: true,
        deliveryEnabled: false,
        minOrderAmount: 0,
        deliveryFee: 0
      }
    });
    console.log("Created restaurant settings.");
  }

  // --- Delivery platforms (disabled until owner adds real URLs) -----------
  for (const name of [
    DeliveryPlatformName.UBER_EATS,
    DeliveryPlatformName.DOORDASH,
    DeliveryPlatformName.GRUBHUB
  ]) {
    await prisma.deliveryPlatform.upsert({
      where: { name },
      update: {},
      create: { name, url: null, enabled: false }
    });
  }
  console.log("Ensured delivery platform rows exist (disabled, no URL).");

  // --- Menu ------------------------------------------------------------------
  const usedSlugs = new Set<string>();
  for (let c = 0; c < MENU.length; c++) {
    const cat = MENU[c];
    const category = await prisma.menuCategory.upsert({
      where: { slug: cat.slug },
      update: { name: cat.name, description: cat.description, sortOrder: c },
      create: {
        name: cat.name,
        slug: cat.slug,
        description: cat.description,
        sortOrder: c
      }
    });

    for (let i = 0; i < cat.items.length; i++) {
      const item = cat.items[i];

      let slug = slugify(item.name);
      if (usedSlugs.has(slug)) slug = `${slug}-${cat.slug}`;
      usedSlugs.add(slug);

      const existing = await prisma.menuItem.findFirst({
        where: { categoryId: category.id, name: item.name }
      });
      if (existing) {
        await prisma.menuItem.update({
          where: { id: existing.id },
          data: {
            slug: existing.slug || slug,
            description: item.description,
            price: item.price,
            priceUnclear: !!item.priceUnclear,
            isFeatured: !!item.isFeatured,
            sortOrder: i,
            status: item.priceUnclear ? MenuItemStatus.HIDDEN : MenuItemStatus.AVAILABLE
          }
        });
      } else {
        await prisma.menuItem.create({
          data: {
            categoryId: category.id,
            name: item.name,
            slug,
            description: item.description,
            price: item.price,
            priceUnclear: !!item.priceUnclear,
            isFeatured: !!item.isFeatured,
            sortOrder: i,
            // Items with an unclear source price are hidden from customers
            // by default until the owner confirms a real price in /admin/menu.
            status: item.priceUnclear ? MenuItemStatus.HIDDEN : MenuItemStatus.AVAILABLE
          }
        });
      }
    }
    console.log(`Seeded category "${cat.name}" (${cat.items.length} items).`);
  }

  // --- QR digital menu settings (singleton) -----------------------------------
  const existingQr = await prisma.qRMenuSettings.findFirst();
  if (!existingQr) {
    await prisma.qRMenuSettings.create({ data: { slug: "menu" } });
    console.log('Created QR menu settings (slug: "menu").');
  }

  // --- Delivery platform integration credentials ------------------------------
  // Sandbox/disconnected by default — no credentials are invented here. The
  // owner connects each platform from /admin/integrations once real API
  // access is granted; until then every provider runs in MOCK mode and the
  // app keeps working normally (see src/lib/integrations/*).
  const platformEnvVars: Record<Exclude<SalesChannel, "WEBSITE">, string> = {
    UBER_EATS: "UBER_EATS_CLIENT_SECRET",
    DOORDASH: "DOORDASH_CLIENT_SECRET",
    GRUBHUB: "GRUBHUB_CLIENT_SECRET"
  };
  for (const platform of [SalesChannel.UBER_EATS, SalesChannel.DOORDASH, SalesChannel.GRUBHUB]) {
    await prisma.integrationCredential.upsert({
      where: { platform },
      update: {},
      create: {
        platform,
        connected: false,
        sandboxMode: true,
        clientSecretEnvVar: platformEnvVars[platform]
      }
    });
  }
  console.log("Ensured integration credential rows exist (disconnected, sandbox mode).");

  // --- Default admin user ----------------------------------------------------
  // No hardcoded default password: if SEED_ADMIN_PASSWORD isn't set, this
  // generates a random one and prints it ONCE to this console output. It is
  // never written to a file, README, or committed anywhere — the operator
  // running this script is the only one who sees it, and only here.
  const adminEmail = process.env.SEED_ADMIN_EMAIL || "admin@ledakarnyc.com";
  const generatedPassword = crypto.randomBytes(12).toString("base64url"); // ~16 chars, URL-safe
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || generatedPassword;
  const existingAdmin = await prisma.admin.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 10);
    await prisma.admin.create({
      data: {
        email: adminEmail,
        passwordHash,
        name: "LE DAKAR Owner",
        role: "OWNER"
      }
    });
    if (process.env.SEED_ADMIN_PASSWORD) {
      console.log(`Created default admin: ${adminEmail} (password set from SEED_ADMIN_PASSWORD).`);
    } else {
      console.log("=".repeat(70));
      console.log(`Created default admin: ${adminEmail}`);
      console.log(`One-time generated password: ${adminPassword}`);
      console.log("This is printed ONLY here, right now — it is not saved anywhere.");
      console.log("Log in at /admin, then change it immediately (Users page).");
      console.log("=".repeat(70));
    }
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
